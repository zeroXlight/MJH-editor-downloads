﻿# Native recycle-list predicate, shared by preview and actual WeekRoundEnd.
# Player setting = maximum allowed cracks (0..7). Native compares >=, so encode max+1.
# Accept old stored settings 0..7 and new 1..8; reinstall rewrites the selected setting.
# All writes are prepared in memory; unsupported layouts abort before disk writes.
function Update-CarryOut([byte[]]$Data, $Switches, [string]$CodePath) {
    $resourceDir=Split-Path $CodePath -Parent
    . (Join-Path $resourceDir 'game_build.ps1')
    if((Get-ShadowGameBuild $Data).Family -eq 'classic') {
        $keys=@('balance.outenhance','balance.outheirloom','balance.outmartial','balance.outheaven','balance.outmaterial','balance.outgold','balance.outcrack')
        [byte[]]$cfg=New-Object byte[] 12
        $on=$false
        for($i=0;$i -lt 7;$i++) {if($Switches[$keys[$i]]) {$cfg[$i]=1;$on=$true}}
        $threshold=2
        if($Switches.ContainsKey('balance.outcrackcount')) {$threshold=[int]$Switches['balance.outcrackcount']}
        if($threshold -lt 0 -or $threshold -gt 7) {throw 'Crack threshold must be 0..7'}
        [BitConverter]::GetBytes([int]($threshold+1)).CopyTo($cfg,8)
        . (Join-Path $resourceDir 'patch_classic_section.ps1')
        $layoutPath=Get-ShadowNativeLayoutPath $Data $resourceDir 'carryout_layout.json'
        try {return ,(Update-ClassicSection $Data $on $layoutPath $cfg)}
        catch {
            # Only the exact previous published layout may be removed before upgrading.
            $previousPath=Join-Path (Split-Path $layoutPath -Parent) 'carryout_layout_pre_attrfix.json'
            if(-not (Test-Path -LiteralPath $previousPath)) {throw}
            try {$clean=Update-ClassicSection $Data $false $previousPath}
            catch {throw 'Carry-out layout is neither current nor the verified previous version'}
            return ,(Update-ClassicSection $clean $on $layoutPath $cfg)
        }
    }
    [byte[]]$b=$Data.Clone()
    function HexAt([int]$o,[int]$n) { return [BitConverter]::ToString($b,$o,$n).Replace('-','') }
    function Put32([int]$o,[uint32]$v) { [BitConverter]::GetBytes($v).CopyTo($b,$o) }
    $codeHex=([IO.File]::ReadAllText($CodePath)).Trim()
    if ($codeHex -notmatch '^[0-9A-F]+$' -or $codeHex.Length % 2) { throw 'Invalid carry-out code' }
    [byte[]]$code=New-Object byte[] ($codeHex.Length/2)
    for($i=0;$i -lt $code.Length;$i++) { $code[$i]=[Convert]::ToByte($codeHex.Substring($i*2,2),16) }
    if($code.Length -ge 0x800) { throw 'Carry-out code too large' }
    $keys=@('balance.outenhance','balance.outheirloom','balance.outmartial','balance.outheaven','balance.outmaterial','balance.outgold','balance.outcrack')
    [byte[]]$cfg=New-Object byte[] 12
    $on=$false
    for($i=0;$i -lt 7;$i++) { if($Switches[$keys[$i]]) {$cfg[$i]=1;$on=$true} }
    $threshold=2
    if($Switches.ContainsKey('balance.outcrackcount')) {$threshold=[int]$Switches['balance.outcrackcount']}
    if($threshold -lt 0 -or $threshold -gt 7) { throw 'Crack threshold must be 0..7' }
    [BitConverter]::GetBytes([int]($threshold+1)).CopyTo($cfg,8)
    $pe=[BitConverter]::ToInt32($b,0x3c)
    if($pe -ne 0x100 -or (HexAt $pe 4) -ne '50450000' -or (HexAt ($pe+4) 2) -ne '6486') {throw 'Unsupported carry-out PE'}
    $opt=$pe+24
    $table=$opt+[BitConverter]::ToUInt16($b,$pe+20)
    $section=$table+7*40
    $count=[BitConverter]::ToUInt16($b,$pe+6)
    $raw=0x1ad2a00
    $rva=0x1b40000
    $hook=0x4827cd
    $orig='488B4C2458'
    [byte[]]$jump=0xe9,0,0,0,0
    [BitConverter]::GetBytes([int]($rva-0x4833cd-5)).CopyTo($jump,1)
    $jumpHex=[BitConverter]::ToString($jump).Replace('-','')
    # Verify the native getter layout used by this predicate.
    foreach($guard in @(
        @((0x30a880-0xc00),'48894C2408488B4424088B8050010000C3'),
        @((0x30a960-0xc00),'48894C2408488B4424088B8098010000C3'),
        @((0x6ec380-0xc00),'48894C2408488B4424088B402CC3'),
        @((0x2c0b50-0xc00),'48894C2408488B4424088B4018C3'))) {
        if((HexAt $guard[0] ($guard[1].Length/2)) -ne $guard[1]) {throw 'Unsupported native carry-out getter'}
    }
    $exists=($count -eq 8 -and (HexAt $section 8) -eq '2E64796F75740000')
    if($exists) {
        if([BitConverter]::ToUInt32($b,$section+12) -ne $rva -or [BitConverter]::ToUInt32($b,$section+20) -ne $raw -or $b.Length -ne ($raw+0x1000) -or (HexAt $hook 5) -ne $jumpHex) {throw 'Unknown installed carry-out layout'}
        [byte[]]$expected=New-Object byte[] 0x1000
        $code.CopyTo($expected,0)
        # Config is the only mutable part. Validate it before accepting old settings.
        for($i=0;$i -lt 7;$i++) {if($b[$raw+0x800+$i] -gt 1) {throw 'Unknown carry-out options'}}
        if($b[$raw+0x807] -ne 0 -or [BitConverter]::ToInt32($b,$raw+0x808) -lt 0 -or [BitConverter]::ToInt32($b,$raw+0x808) -gt 8) {throw 'Unknown carry-out crack setting'}
        [Array]::Copy($b,$raw+0x800,$expected,0x800,12)
        if((HexAt $raw 0x1000) -ne [BitConverter]::ToString($expected).Replace('-','')) {
            [byte[]]$previousVector=$expected.Clone()
            $vectorPattern='4881C190000000'
            for($j=0;$j -lt $code.Length-6;$j++) {
                if(([BitConverter]::ToString($previousVector,$j,7).Replace('-','')) -eq $vectorPattern) {$previousVector[$j+3]=0xB8}
            }
            if((HexAt $raw 0x1000) -ne [BitConverter]::ToString($previousVector).Replace('-','')) {
            # Upgrade only the exact published predicate; preserve config and reject external edits.
            $legacyPath=Join-Path (Split-Path -Parent $CodePath) 'carryout_code_legacy.hex'
            if(-not (Test-Path -LiteralPath $legacyPath)) {throw 'Carry-out section has unexpected bytes'}
            $legacyHex=([IO.File]::ReadAllText($legacyPath)).Trim()
            if($legacyHex -notmatch '^[0-9A-F]+$' -or $legacyHex.Length % 2 -or $legacyHex.Length -ge 0x1000) {throw 'Invalid legacy carry-out code'}
            [byte[]]$legacyExpected=New-Object byte[] 0x1000
            for($i=0;$i -lt $legacyHex.Length/2;$i++) {$legacyExpected[$i]=[Convert]::ToByte($legacyHex.Substring($i*2,2),16)}
            [Array]::Copy($b,$raw+0x800,$legacyExpected,0x800,12)
            if((HexAt $raw 0x1000) -ne [BitConverter]::ToString($legacyExpected).Replace('-','')) {
                # Exact 804-byte local test revision (rank 7/9 only), before rank 8 was requested.
                $variantSHA=[Security.Cryptography.SHA256]::Create()
                $variantHash=[BitConverter]::ToString($variantSHA.ComputeHash($b,$raw,804)).Replace('-','')
                $variantSHA.Dispose()
                if($variantHash -ne '118589AA946C55B3CDBBE0EAFEE7DD6779F5BD37CDA654DB6C06D82EFDF13E2A') {throw 'Carry-out section has unexpected bytes'}
                [byte[]]$variantExpected=New-Object byte[] 0x1000
                [Array]::Copy($b,$raw,$variantExpected,0,804)
                [Array]::Copy($b,$raw+0x800,$variantExpected,0x800,12)
                if((HexAt $raw 0x1000) -ne [BitConverter]::ToString($variantExpected).Replace('-','')) {throw 'Carry-out section has unexpected bytes'}
            }
            }
            [Array]::Clear($b,$raw,0x800)
            $code.CopyTo($b,$raw)
        }
    } elseif($count -ne 7 -or $b.Length -ne $raw -or (HexAt $hook 5) -ne $orig -or (HexAt $section 40) -ne ('00'*40) -or [BitConverter]::ToUInt32($b,$opt+56) -ne $rva) {
        throw 'Unsupported DLL layout for carry-out patch'
    }
    if(-not $on) {
        if($exists) {
            [Array]::Clear($b,$section,40)
            [BitConverter]::GetBytes([uint16]7).CopyTo($b,$pe+6)
            Put32 ($opt+56) $rva
            [byte[]]$original=0x48,0x8b,0x4c,0x24,0x58
            $original.CopyTo($b,$hook)
            [Array]::Resize([ref]$b,$raw)
        }
        return ,$b
    }
    if(-not $exists) {
        [byte[]]$expanded=New-Object byte[] ($raw+0x1000)
        $b.CopyTo($expanded,0);$b=$expanded
        [Text.Encoding]::ASCII.GetBytes('.dyout').CopyTo($b,$section)
        Put32 ($section+8) 0x1000; Put32 ($section+12) $rva
        Put32 ($section+16) 0x1000; Put32 ($section+20) $raw
        Put32 ($section+36) 0x60000020
        [BitConverter]::GetBytes([uint16]8).CopyTo($b,$pe+6)
        Put32 ($opt+56) ($rva+0x1000)
        $code.CopyTo($b,$raw)
        $jump.CopyTo($b,$hook)
    }
    $cfg.CopyTo($b,$raw+0x800)
    return ,$b
}
