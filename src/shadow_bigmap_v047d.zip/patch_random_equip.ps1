﻿function Update-RandomEquip([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir,[bool]$NoLimit=$false) {
    if(-not ('ShadowRandomEquip' -as [type])){Add-Type -Path (Join-Path $ResourceDir 'random_equip_native.cs')}
    . (Join-Path $ResourceDir 'game_build.ps1')
    $meta=Get-Content -LiteralPath (Get-ShadowNativeLayoutPath $Data $ResourceDir 'random_equip_layout.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $alternate=Get-Content -LiteralPath (Get-ShadowNativeLayoutPath $Data $ResourceDir 'random_equip_layout_nolimit.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if($NoLimit){$tmp=$meta;$meta=$alternate;$alternate=$tmp}
    function RandomEquip-Bytes([string]$Hex){
        if($Hex -notmatch '^(?:[0-9a-fA-F]{2})+$'){throw 'Invalid random equipment hex'}
        [byte[]]$b=New-Object byte[] ($Hex.Length/2)
        for($i=0;$i -lt $b.Length;$i++){$b[$i]=[Convert]::ToByte($Hex.Substring(2*$i,2),16)}
        return ,$b
    }
    [int[]]$offsets=@($meta.relocations | ForEach-Object {$_[0]});[int[]]$targets=@($meta.relocations | ForEach-Object {$_[1]});[int[]]$local=@($meta.relocations | ForEach-Object {$_[2]})
    [int[]]$patchRvas=@($meta.patches | ForEach-Object {$_.rva})
    $originals=New-Object 'System.Collections.Generic.List[byte[]]';$patched=New-Object 'System.Collections.Generic.List[byte[]]'
    foreach($p in $meta.patches){$originals.Add((RandomEquip-Bytes $p.original));$patched.Add((RandomEquip-Bytes $p.patched))}
    [int[]]$guardRvas=@($meta.guards | ForEach-Object {$_.rva});[int[]]$sizes=@($meta.guards | ForEach-Object {$_.size});[string[]]$hashes=@($meta.guards | ForEach-Object {$_.sha256})
    [int[]]$hooks=@($meta.hooks | ForEach-Object {$_.rva});[int[]]$entries=@($meta.hooks | ForEach-Object {$_.entry})
    $originalHooks=New-Object 'System.Collections.Generic.List[byte[]]'
    foreach($h in $meta.hooks){$originalHooks.Add((RandomEquip-Bytes $h.original))}
    [int[]]$begins=@($meta.entries | ForEach-Object {$_[0]});[int[]]$ends=@($meta.entries | ForEach-Object {$_[1]})
    [int[]]$frames=@($meta.entries | ForEach-Object {if($_.Count -gt 2){$_[2]}else{0x88}})
    $disabledHook=0x7a4971
    if($meta.PSObject.Properties['disabledHook']) {$disabledHook=[int]$meta.disabledHook}
    return ,[ShadowRandomEquip]::Update($Data,$Enabled,(RandomEquip-Bytes $meta.code),(RandomEquip-Bytes $alternate.code),$offsets,$targets,$local,$hooks,$originalHooks.ToArray(),$entries,$begins,$ends,$frames,(RandomEquip-Bytes $meta.unwindCode),$patchRvas,$originals.ToArray(),$patched.ToArray(),$guardRvas,$sizes,$hashes,$disabledHook)
}

function Update-RandomEquipShops([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir){
    if(-not ('ShadowRandomEquip' -as [type])){Add-Type -Path (Join-Path $ResourceDir 'random_equip_native.cs')}
    return ,[ShadowRandomEquip]::Shops($Data,$Enabled)
}
