﻿# Reversible Item table definitions for save-confirmed martial collections.
$script:FragmentExtraPath=Join-Path $PSScriptRoot 'fragment_extra_items.json'
function Get-FragmentExtras {
    return @(([IO.File]::ReadAllText($script:FragmentExtraPath,[Text.Encoding]::UTF8) | ConvertFrom-Json))
}
function Convert-FragmentExtraHex([string]$Hex) {
    [byte[]]$b=New-Object byte[] ($Hex.Length/2)
    for($i=0;$i -lt $b.Length;$i++) {$b[$i]=[Convert]::ToByte($Hex.Substring($i*2,2),16)}
    return ,$b
}
function Add-FragmentExtraVar($Out,[long]$Value) {
    do {$v=[byte]($Value -band 127);$Value=$Value -shr 7;if($Value) {$v=$v -bor 128};$Out.Add($v)} while($Value)
}
function Update-FragmentItemTable([byte[]]$Data,[bool]$Enabled) {
    $recipes=@{};$synthetic=@{};$seen=@{}
    foreach($r in (Get-FragmentExtras)) {
        $id=[long]$r.ItemID
        if($recipes.ContainsKey($id)) {throw 'Duplicate extra fragment item ID'}
        $recipes[$id]=$r;if(-not $r.Original) {$synthetic[$id]=$true}
    }
    $out=New-Object 'System.Collections.Generic.List[byte]';$cursor=0
    foreach($f in (Read-FragmentFields $Data 0 $Data.Length)) {
        $copy=$true
        # Keep synthetic definitions on disable so saved NPC fragments stay valid.
        if($f.F -eq 2 -and $f.W -eq 2) {
            $p=$f.Start;$key=Read-FragmentVar $Data ([ref]$p) $f.End
            if($key -ne 8) {throw 'Item row must begin with BaseID'}
            $id=Read-FragmentVar $Data ([ref]$p) $f.End
            if($recipes.ContainsKey($id)) {
                if($seen.ContainsKey($id)) {throw 'Duplicate existing extra fragment item'}
                $seen[$id]=$true;$r=$recipes[$id]
                $hex=[BitConverter]::ToString($Data,$f.Start,$f.End-$f.Start).Replace('-','')
                if($hex -ne $r.Original -and $hex -ne $r.Patched -and $hex -ne $r.Disabled) {throw ('Extra fragment item changed by another mod: '+$id)}
                $wanted=if($Enabled) {$r.Patched} elseif($r.Original) {$r.Original} else {$r.Disabled}
                if($wanted) {
                    [byte[]]$row=Convert-FragmentExtraHex $wanted
                    $out.Add(18);Add-FragmentExtraVar $out $row.Length;$out.AddRange($row)
                }
                $copy=$false
            }
        }
        if($copy) {$out.AddRange([byte[]]$Data[$cursor..($f.End-1)])}
        $cursor=$f.End
    }
    foreach($id in ($recipes.Keys | Sort-Object)) {
        if($seen.ContainsKey($id)) {continue}
        $r=$recipes[$id]
        if($r.Original) {throw ('Missing original extra fragment item: '+$id)}
        if($Enabled) {
            $out.Add(8);Add-FragmentExtraVar $out $id
            [byte[]]$row=Convert-FragmentExtraHex $r.Patched
            $out.Add(18);Add-FragmentExtraVar $out $row.Length;$out.AddRange($row)
        }
    }
    return ,$out.ToArray()
}
