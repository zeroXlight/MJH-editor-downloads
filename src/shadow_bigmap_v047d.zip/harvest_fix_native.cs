using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;
public static class ShadowHarvestFix {
 static uint R(byte[] b,int o){return BitConverter.ToUInt32(b,o);}
 static void W(byte[] b,int o,uint v){Buffer.BlockCopy(BitConverter.GetBytes(v),0,b,o,4);}
 static int Align(int n,int a){return checked((n+a-1)/a*a);}
 static byte[] Slice(byte[] b,int o,int n){byte[] v=new byte[n];Buffer.BlockCopy(b,o,v,0,n);return v;}
 static bool Same(byte[] a,byte[] b){if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true;}
 static string Hash(byte[] b){using(SHA256 h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(b)).Replace("-","").ToLowerInvariant();}
 static void Check(bool ok,string msg){if(!ok)throw new InvalidDataException("Harvest fix: "+msg);}
 static int Rva(byte[] b,int r){int pe=(int)R(b,0x3c),t=pe+24+BitConverter.ToUInt16(b,pe+20),n=BitConverter.ToUInt16(b,pe+6);for(int i=0;i<n;i++){int h=t+i*40,v=(int)R(b,h+12),size=Math.Max((int)R(b,h+8),(int)R(b,h+16));if(r>=v&&r<v+size)return (int)R(b,h+20)+r-v;}throw new InvalidDataException("Harvest unmapped RVA");}
 static byte[] Code(byte[] template,int baseRva,int[] offsets,int[] targets,int[] local){byte[] code=(byte[])template.Clone();for(int i=0;i<offsets.Length;i++)W(code,offsets[i],unchecked((uint)(targets[i]+(local[i]!=0?baseRva:0)-baseRva-offsets[i]-4)));return code;}
 static byte[] Jump(int from,int to){byte[] b={0xe8,0,0,0,0};W(b,1,unchecked((uint)(to-from-5)));return b;}
 public static byte[] Update(byte[] input,bool enabled,byte[] code,int[] relocOffsets,int[] relocTargets,int[] relocLocal,int[] hooks,byte[][] originalHooks,int[] hookEntries,int[] begins,int[] ends,byte[] unwindCode,int[] patchRvas,byte[][] originals,byte[][] patched,int[] guardRvas,int[] guardSizes,string[] guardHashes){
  byte[] b=(byte[])input.Clone();int pe=(int)R(b,0x3c),opt=pe+24;
  Check(R(b,pe)==0x4550&&BitConverter.ToUInt16(b,pe+4)==0x8664&&BitConverter.ToUInt16(b,opt)==0x20b,"unsupported PE");
  int table=opt+BitConverter.ToUInt16(b,pe+20),count=BitConverter.ToUInt16(b,pe+6),last=table+(count-1)*40;
  for(int i=0;i<count-1;i++)Check(Encoding.ASCII.GetString(b,table+i*40,8).TrimEnd('\0')!=".dyadv","section is not last; remove it before other injected patches");
  bool installed=Encoding.ASCII.GetString(b,last,8).TrimEnd('\0')==".dyadv";
  if(!installed&&!enabled)return b;
  if(installed){
   int raw=(int)R(b,last+20),baseRva=(int)R(b,last+12);
   for(int i=0;i<hooks.Length;i++)Check(Same(Slice(b,Rva(b,hooks[i]),5),Jump(hooks[i],baseRva+hookEntries[i])),"unknown installed hook");
   Check(Same(Slice(b,raw,code.Length),Code(code,baseRva,relocOffsets,relocTargets,relocLocal)),"unknown installed code");
   Check(Encoding.ASCII.GetString(b,raw+0xa00,8)=="HARVEST1","invalid metadata");
   int oldLen=(int)R(b,raw+0xa08);uint oldImage=R(b,raw+0xa0c),oldEx=R(b,raw+0xa10),oldExSize=R(b,raw+0xa14),oldChecksum=R(b,raw+0xa1c);
   Check(R(b,raw+0xa18)==count-1&&oldLen<=raw&&oldLen>=R(b,last-40+20)+R(b,last-40+16),"invalid parent");
   Check(b.Length==raw+R(b,last+16)&&R(b,opt+136)==baseRva+0x1000&&R(b,opt+140)==oldExSize+12*begins.Length,"invalid installed layout");
   Check(Same(Slice(b,raw+0x1000,(int)oldExSize),Slice(b,Rva(b,(int)oldEx),(int)oldExSize)),"parent unwind changed");
   for(int i=0;i<begins.Length;i++){int e=raw+0x1000+(int)oldExSize+i*12;Check(R(b,e)==baseRva+begins[i]&&R(b,e+4)==baseRva+ends[i]&&R(b,e+8)==baseRva+0x980,"shim unwind changed");} Check(Same(Slice(b,raw+0x980,unwindCode.Length),unwindCode),"unwind code changed");
   for(int i=0;i<hooks.Length;i++)Buffer.BlockCopy(originalHooks[i],0,b,Rva(b,hooks[i]),5);Array.Clear(b,last,40);Buffer.BlockCopy(BitConverter.GetBytes((ushort)(count-1)),0,b,pe+6,2);W(b,opt+56,oldImage);W(b,opt+136,oldEx);W(b,opt+140,oldExSize);W(b,opt+64,oldChecksum);Array.Resize(ref b,oldLen);count--;last-=40;
  }
  for(int i=0;i<hooks.Length;i++)Check(Same(Slice(b,Rva(b,hooks[i]),5),originalHooks[i]),"unknown original hook");
  for(int i=0;i<patchRvas.Length;i++){
   Check(originals[i].Length==patched[i].Length,"patch size mismatch");int o=Rva(b,patchRvas[i]);byte[] current=Slice(b,o,originals[i].Length);
   Check(Same(current,originals[i])||Same(current,patched[i]),"unknown reward bytes");Buffer.BlockCopy(originals[i],0,b,o,originals[i].Length);
  }
  if(!enabled)return b;
  for(int i=0;i<guardRvas.Length;i++)Check(Hash(Slice(b,Rva(b,guardRvas[i]),guardSizes[i]))==guardHashes[i],"native function changed "+guardRvas[i].ToString("X"));
  int header=table+count*40;Check(header+40<=R(b,opt+60)&&Same(Slice(b,header,40),new byte[40]),"no free section header");
  int oldLength=b.Length,sa=(int)R(b,opt+32),fa=(int)R(b,opt+36);Check(oldLength==R(b,last+20)+R(b,last+16),"unexpected overlay");
  int newBase=Align(Math.Max((int)R(b,opt+56),(int)(R(b,last+12)+R(b,last+8))),sa),newRaw=Align(oldLength,fa);
  uint image=R(b,opt+56),ex=R(b,opt+136),exSize=R(b,opt+140),checksum=R(b,opt+64);Check(exSize>0&&exSize%12==0,"invalid unwind table");
  byte[] pdata=Slice(b,Rva(b,(int)ex),(int)exSize);Check(R(pdata,pdata.Length-12)<newBase,"unwind table is not sorted");
  int vsize=0x1000+(int)exSize+12*begins.Length,rawSize=Align(vsize,fa);byte[] output=new byte[newRaw+rawSize];Buffer.BlockCopy(b,0,output,0,b.Length);
  byte[] newCode=Code(code,newBase,relocOffsets,relocTargets,relocLocal);Buffer.BlockCopy(newCode,0,output,newRaw,newCode.Length);
  Buffer.BlockCopy(Encoding.ASCII.GetBytes("HARVEST1"),0,output,newRaw+0xa00,8);W(output,newRaw+0xa08,(uint)oldLength);W(output,newRaw+0xa0c,image);W(output,newRaw+0xa10,ex);W(output,newRaw+0xa14,exSize);W(output,newRaw+0xa18,(uint)count);W(output,newRaw+0xa1c,checksum);
  Buffer.BlockCopy(pdata,0,output,newRaw+0x1000,pdata.Length);int end=newRaw+0x1000+pdata.Length;for(int i=0;i<begins.Length;i++){W(output,end+i*12,(uint)(newBase+begins[i]));W(output,end+i*12+4,(uint)(newBase+ends[i]));W(output,end+i*12+8,(uint)(newBase+0x980));} Buffer.BlockCopy(unwindCode,0,output,newRaw+0x980,unwindCode.Length);
  Buffer.BlockCopy(Encoding.ASCII.GetBytes(".dyadv"),0,output,header,6);W(output,header+8,(uint)vsize);W(output,header+12,(uint)newBase);W(output,header+16,(uint)rawSize);W(output,header+20,(uint)newRaw);W(output,header+36,0x60000020);
  Buffer.BlockCopy(BitConverter.GetBytes((ushort)(count+1)),0,output,pe+6,2);W(output,opt+56,(uint)Align(newBase+vsize,sa));W(output,opt+136,(uint)(newBase+0x1000));W(output,opt+140,checked(exSize+(uint)(12*begins.Length)));W(output,opt+64,0);
  for(int i=0;i<hooks.Length;i++)Buffer.BlockCopy(Jump(hooks[i],newBase+hookEntries[i]),0,output,Rva(output,hooks[i]),5);
  for(int i=0;i<patchRvas.Length;i++)Buffer.BlockCopy(patched[i],0,output,Rva(output,patchRvas[i]),patched[i].Length);
  return output;
 }
}
