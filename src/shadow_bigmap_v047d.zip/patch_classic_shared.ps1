﻿function Update-ClassicShared([byte[]]$Data,$Switches,[string]$ResourceDir) {
    . (Join-Path $ResourceDir 'game_build.ps1')
    if((Get-ShadowGameBuild $Data).Family -ne 'classic') {throw 'Classic shared code requires classic game build'}
    $layout=Get-Content -LiteralPath (Get-ShadowNativeLayoutPath $Data $ResourceDir 'shared_caves_layout.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if(-not ('ShadowClassicShared' -as [type])) {Add-Type -Path (Join-Path $ResourceDir 'classic_shared_native.cs')}
    function Shared-Bytes([string]$hex) {
        if($hex -notmatch '^(?:[0-9a-f]{2})+$') {throw 'Invalid classic shared hex'}
        [byte[]]$b=New-Object byte[] ($hex.Length/2)
        for($i=0;$i -lt $b.Length;$i++) {$b[$i]=[Convert]::ToByte($hex.Substring(2*$i,2),16)}
        return ,$b
    }
    [byte[]]$code=Shared-Bytes $layout.code
    $sha=[Security.Cryptography.SHA256]::Create()
    try {if([BitConverter]::ToString($sha.ComputeHash($code)).Replace('-','').ToLowerInvariant() -ne $layout.code_sha256) {throw 'Classic shared code checksum differs'}} finally {$sha.Dispose()}
    $flags=0
    foreach($p in $layout.features.PSObject.Properties) {if($Switches[$p.Name]) {$flags=$flags -bor [int]$p.Value}}
    [int[]]$offsets=@($layout.patches | ForEach-Object {[int]$_.offset})
    [int[]]$bits=@($layout.patches | ForEach-Object {[int]$_.bit})
    $originals=New-Object 'System.Collections.Generic.List[byte[]]'
    $patched=New-Object 'System.Collections.Generic.List[byte[]]'
    foreach($p in $layout.patches) {$originals.Add((Shared-Bytes $p.original));$patched.Add((Shared-Bytes $p.patched))}
    [int[]]$guards=@($layout.guards | ForEach-Object {[int]$_.offset})
    [int[]]$sizes=@($layout.guards | ForEach-Object {[int]$_.size})
    [string[]]$hashes=@($layout.guards | ForEach-Object {$_.sha256})
    [int[]]$pdataOffsets=@($layout.pdata_edits | ForEach-Object {[int]$_.offset})
    $pdataOriginals=New-Object 'System.Collections.Generic.List[byte[]]'
    $pdataPatched=New-Object 'System.Collections.Generic.List[byte[]]'
    foreach($p in $layout.pdata_edits) {$pdataOriginals.Add((Shared-Bytes $p.original));$pdataPatched.Add((Shared-Bytes $p.patched))}
    return ,[ShadowClassicShared]::Update($Data,$flags,$code,[int]$layout.code_rva,[int]$layout.code_raw,[int]$layout.root_length,
        (Shared-Bytes $layout.original_last_section),$offsets,$originals.ToArray(),$patched.ToArray(),$bits,$guards,$sizes,$hashes,$pdataOffsets,$pdataOriginals.ToArray(),$pdataPatched.ToArray())
}
