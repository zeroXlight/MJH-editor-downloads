﻿# Shared protobuf helpers come from patch_fragment.ps1.
function Update-ClanTalentTable([byte[]]$Data,[string]$Name,[bool]$Enabled,[string]$ResourceDir,[string]$PlanName='clan_talent_tables.json') {
    $plan=[IO.File]::ReadAllText((Join-Path $ResourceDir $PlanName),[Text.Encoding]::UTF8) | ConvertFrom-Json
    $recipes=@{};$seen=@{};$keys=@{};$rowKeys=@{}
    foreach($r in $plan.$Name) {$recipes[[long]$r.ID]=$r}
    $out=New-Object 'System.Collections.Generic.List[byte]';$cursor=0
    foreach($f in (Read-FragmentFields $Data 0 $Data.Length)) {
        $copy=$true
        if($f.F -eq 1 -and $f.W -eq 0) {
            $id=[long]$f.V
            if($keys.ContainsKey($id)) {throw 'Duplicate clan talent table key'}
            $keys[$id]=$true
            if($recipes.ContainsKey($id)) {
                $r=$recipes[$id]
                if(-not $Enabled -and -not $r.Original -and -not $r.Keep) {$copy=$false}
            }
        }
        if($f.F -eq 2 -and $f.W -eq 2) {
            $p=$f.Start
            if((Read-FragmentVar $Data ([ref]$p) $f.End) -ne 8) {throw 'Clan talent row must start with BaseID'}
            $id=Read-FragmentVar $Data ([ref]$p) $f.End
            if($rowKeys.ContainsKey($id)) {throw 'Duplicate clan talent row'}
            $rowKeys[$id]=$true
            if($recipes.ContainsKey($id)) {
                $seen[$id]=$true;$r=$recipes[$id]
                $hex=[BitConverter]::ToString($Data,$f.Start,$f.End-$f.Start).Replace('-','')
                $known=($hex -eq $r.Original -or $hex -eq $r.Patched)
                if($r.PSObject.Properties['Legacy'] -and $hex -in @($r.Legacy)) {$known=$true}
                if(-not $known) {throw ('Unknown clan talent row: '+$Name+':'+$id)}
                $wanted=if($Enabled -or $r.Keep) {$r.Patched} else {$r.Original}
                if($wanted) {
                    [byte[]]$row=Convert-FragmentExtraHex $wanted
                    $out.Add(18);Add-FragmentExtraVar $out $row.Length;$out.AddRange($row)
                }
                $copy=$false
            }
        }
        if($copy) {$out.AddRange([byte[]]$Data[$cursor..($f.End-1)])}
        $cursor=$f.End
    }
    if($keys.Count -ne $rowKeys.Count) {throw 'Clan talent table key/row mismatch'}
    foreach($id in $rowKeys.Keys) {if(-not $keys.ContainsKey($id)) {throw 'Clan talent table missing key'}}
    foreach($id in ($recipes.Keys | Sort-Object)) {
        if($seen.ContainsKey($id)) {continue}
        $r=$recipes[$id]
        if($r.Original) {throw ('Missing original clan talent row: '+$Name+':'+$id)}
        if($Enabled -or $r.Keep) {
            $out.Add(8);Add-FragmentExtraVar $out $id
            [byte[]]$row=Convert-FragmentExtraHex $r.Patched
            $out.Add(18);Add-FragmentExtraVar $out $row.Length;$out.AddRange($row)
        }
    }
    return ,$out.ToArray()
}

function Update-ClanWishPool([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    . (Join-Path $ResourceDir 'game_build.ps1')
    if((Get-ShadowGameBuild $Data).Family -eq 'classic') {
        . (Join-Path $ResourceDir 'patch_equal_layout.ps1')
        return ,(Update-ShadowEqualLayout $Data $Enabled (Get-ShadowNativeLayoutPath $Data $ResourceDir 'clan_wish_pool_layout.json'))
    }
    $offset=0x595F10;$size=0xF54
    if($Data.Length -lt ($offset+$size)) {throw 'Unsupported clan wish DLL'}
    $codes=@()
    foreach($name in @('clan_wish_pool_original.hex','clan_wish_pool.hex','clan_wish_pool_legacy.hex')) {
        $hex=[IO.File]::ReadAllText((Join-Path $ResourceDir $name)).Trim()
        if($hex -notmatch '^[0-9A-F]+$' -or $hex.Length -ne 2*$size) {throw 'Invalid clan wish resource'}
        $codes+=,(Convert-FragmentExtraHex $hex)
    }
    $expected=@('F5DF8E38E4884014932C35E792752B2993CE198E390B625BD328C6D046200301','5AB43532C81693FE13B6900651EBB9292F0F650B9A808A581D284826029EA18C','4AB2F54AA1BC2EC7B28A4579B12D1106C84876E0B2EFBAE72EB7EDB269978460')
    $sha=[Security.Cryptography.SHA256]::Create()
    try {
        for($i=0;$i -lt 3;$i++) {
            if([BitConverter]::ToString($sha.ComputeHash($codes[$i])).Replace('-','') -ne $expected[$i]) {throw 'Clan wish resource hash differs'}
        }
    } finally {$sha.Dispose()}
    $current=[BitConverter]::ToString($Data,$offset,$size).Replace('-','')
    if($current -ne [BitConverter]::ToString($codes[0]).Replace('-','') -and $current -ne [BitConverter]::ToString($codes[1]).Replace('-','') -and $current -ne [BitConverter]::ToString($codes[2]).Replace('-','')) {throw 'Unknown wish reward function'}
    [byte[]]$out=$Data.Clone();$index=0;if($Enabled) {$index=1}
    $codes[$index].CopyTo($out,$offset)
    return ,$out
}
