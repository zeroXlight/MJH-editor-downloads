﻿# Official Martial JSON upsert; restore only our exact byte range.
function Resolve-MartialJsonResourceDir([byte[]]$Data,[string]$ResourceDir) {
    $profileMatches=@()
    foreach($dir in @($ResourceDir,(Join-Path $ResourceDir 'profiles\classic_26315803'))) {
        $layoutPath=Join-Path $dir 'martial_json_upsert_layout.json'
        if(-not (Test-Path -LiteralPath $layoutPath)) {continue}
        $layout=Get-Content -LiteralPath $layoutPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $offset=[int]$layout.offset;$size=[int]$layout.size
        if($offset -lt 0 -or $size -le 0 -or $offset+$size -gt $Data.Length) {continue}
        $current=[BitConverter]::ToString($Data,$offset,$size).Replace('-','')
        foreach($name in @('martial_json_upsert_original.hex','martial_json_upsert.hex')) {
            $hex=[IO.File]::ReadAllText((Join-Path $dir $name)).Trim()
            if($current -eq $hex) {$profileMatches+=,$dir;break}
        }
    }
    if($profileMatches.Count -ne 1) {throw 'Unknown or ambiguous ClientDll martial profile; refused'}
    return $profileMatches[0]
}

function Update-MartialJsonFix([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    $ResourceDir=Resolve-MartialJsonResourceDir $Data $ResourceDir
    $layout=Get-Content -LiteralPath (Join-Path $ResourceDir 'martial_json_upsert_layout.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if($Data.Length -lt 256 -or $Data[0] -ne 0x4d -or $Data[1] -ne 0x5a) {throw 'Invalid ClientDll PE'}
    $pe=[BitConverter]::ToInt32($Data,0x3c)
    if($pe -lt 0 -or $pe+26 -gt $Data.Length -or [BitConverter]::ToUInt32($Data,$pe) -ne 0x4550 -or [BitConverter]::ToUInt16($Data,$pe+4) -ne 0x8664) {throw 'Unsupported ClientDll PE'}
    $sha=[Security.Cryptography.SHA256]::Create()
    try {
        $codes=@{}
        foreach($kind in @('original','patched')) {
            $file=if($kind -eq 'original') {'martial_json_upsert_original.hex'} else {'martial_json_upsert.hex'}
            $hex=[IO.File]::ReadAllText((Join-Path $ResourceDir $file)).Trim()
            if($hex -notmatch '^[0-9A-F]+$' -or $hex.Length -ne 2*$layout.size) {throw 'Invalid martial JSON patch resource'}
            [byte[]]$code=New-Object byte[] ([int]$layout.size)
            for($i=0;$i -lt $code.Length;$i++) {$code[$i]=[Convert]::ToByte($hex.Substring($i*2,2),16)}
            if([BitConverter]::ToString($sha.ComputeHash($code)).Replace('-','').ToLowerInvariant() -ne $layout.$kind) {throw 'Martial JSON resource checksum differs'}
            $codes[$kind]=$code
        }
        foreach($guard in @($layout.guards)) {
            if([int]$guard.offset -lt 0 -or [int]$guard.offset+[int]$guard.size -gt $Data.Length) {throw 'Unsupported ClientDll layout'}
            if([BitConverter]::ToString($sha.ComputeHash($Data,[int]$guard.offset,[int]$guard.size)).Replace('-','').ToLowerInvariant() -ne $guard.sha256) {throw 'Unknown ClientDll martial loader; refused'}
        }
        $offset=[int]$layout.offset;$size=[int]$layout.size
        if($offset -lt 0 -or $offset+$size -gt $Data.Length) {throw 'Unsupported ClientDll martial offset'}
        $current=[BitConverter]::ToString($Data,$offset,$size)
        if($current -ne [BitConverter]::ToString($codes.original) -and $current -ne [BitConverter]::ToString($codes.patched)) {throw 'Unknown ClientDll martial upsert code; refused'}
        [byte[]]$result=$Data.Clone()
        $desired=if($Enabled) {$codes.patched} else {$codes.original}
        $desired.CopyTo($result,$offset)
        return ,$result
    } finally {$sha.Dispose()}
}
function Invoke-MartialJsonFix([string]$Dir,[bool]$Enabled,[string]$ResourceDir,[string]$BackupDir) {
    $path=Join-Path $Dir 'DreamRivakes_Data\Plugins\ClientDll.dll'
    [byte[]]$before=[IO.File]::ReadAllBytes($path)
    $ResourceDir=Resolve-MartialJsonResourceDir $before $ResourceDir
    [byte[]]$after=Update-MartialJsonFix $before $Enabled $ResourceDir
    $backup=Join-Path $BackupDir 'ClientDll.martialjson.orig'
    if($Enabled -and -not (Test-Path -LiteralPath $backup)) {
        [byte[]]$clean=Update-MartialJsonFix $before $false $ResourceDir
        [void][IO.Directory]::CreateDirectory($BackupDir)
        [IO.File]::WriteAllBytes($backup,$clean)
    }
    # Compare only 151 bytes; don't enumerate the whole DLL in PowerShell.
    $layout=Get-Content -LiteralPath (Join-Path $ResourceDir 'martial_json_upsert_layout.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if([BitConverter]::ToString($before,[int]$layout.offset,[int]$layout.size) -ne [BitConverter]::ToString($after,[int]$layout.offset,[int]$layout.size)) {
        [IO.File]::WriteAllBytes($path,$after)
        $sha=[Security.Cryptography.SHA256]::Create()
        try {if([BitConverter]::ToString($sha.ComputeHash([IO.File]::ReadAllBytes($path))) -ne [BitConverter]::ToString($sha.ComputeHash($after))) {throw 'ClientDll write verification failed'}} finally {$sha.Dispose()}
    }
}
function Sync-CustomMartials([string]$Dir,[string]$ResourceDir) {
    $source=Join-Path $Dir 'mod\暗影mod\自定义武学'
    if(-not (Test-Path -LiteralPath $source)) {return}
    $schema=Get-Content -LiteralPath (Join-Path $ResourceDir 'custom_martial_schema.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $docs=New-Object 'System.Collections.Generic.List[object]';$ids=@{}
    foreach($file in @(Get-ChildItem -LiteralPath $source -File -Filter '*.json' | Sort-Object Name)) {
        if($file.Name -notmatch '^(Martial|MartialItem|Language)_([A-Za-z0-9_-]+)\.json$') {throw ('自定义武学文件名不支持：'+$file.Name)}
        $kind=$Matches[1];$suffix=$Matches[2]
        $doc=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach($prop in $doc.PSObject.Properties) {if($prop.Name -notin @('Items','Keys','TableHash')) {throw ('未知顶层字段：'+$prop.Name)}}
        if($null -eq $doc.PSObject.Properties['Items'] -or $doc.Items -isnot [Array]) {throw ('Items必须是数组：'+$file.Name)}
        if($null -ne $doc.PSObject.Properties['Keys'] -and $doc.Keys -isnot [Array]) {throw 'Keys必须是数组'}
        $rowIDs=@()
        foreach($row in $doc.Items) {
            if($row -isnot [pscustomobject]) {throw 'Items行必须是对象'}
            foreach($prop in $row.PSObject.Properties) {
                $field=$schema.$kind.PSObject.Properties[$prop.Name]
                if($null -eq $field) {throw ('未知字段：'+$file.Name+' / '+$prop.Name)}
                if($field.Value.type -eq 'message') {throw ('暂不支持嵌套字段：'+$prop.Name)}
                if($field.Value.list -and $prop.Value -isnot [Array]) {throw ('字段必须是数组：'+$prop.Name)}
                if(-not $field.Value.list -and $prop.Value -is [Array]) {throw ('字段不能是数组：'+$prop.Name)}
                foreach($value in @($prop.Value)) {
                    if($field.Value.type -eq 'string') {if($value -isnot [string]) {throw ('字段必须是文本：'+$prop.Name)}}
                    elseif($value -is [bool] -or $value -isnot [ValueType] -or $value -lt -2147483648 -or $value -gt 2147483647 -or $value -ne [Math]::Floor([double]$value)) {throw ('字段必须是32位整数：'+$prop.Name)}
                }
            }
            if($null -eq $row.PSObject.Properties['BaseID'] -or $row.BaseID -le 0) {throw '缺少有效BaseID'}
            $key=$kind+':'+$row.BaseID;if($ids.ContainsKey($key)) {throw ('重复配置ID：'+$key)};$ids[$key]=$true
            if($kind -eq 'Martial') {
                foreach($required in @('NameID','Rank','DepartEnum','GrowProIDs','MartMovIDs','UnlockLvls','UnlockClauses')) {if($null -eq $row.PSObject.Properties[$required]) {throw ('武学必须写完整行，缺少：'+$required)}}
                if($row.Rank -lt 1 -or $row.Rank -gt 7 -or @($row.UnlockLvls).Count -ne @($row.UnlockClauses).Count) {throw '武学品质或解锁数组无效'}
            }
            $rowIDs+= $row.BaseID
        }
        if($null -ne $doc.PSObject.Properties['Keys']) {
            if(@($doc.Keys).Count -ne $rowIDs.Count) {throw 'Keys与Items数量不一致'}
            for($i=0;$i -lt $rowIDs.Count;$i++) {if($doc.Keys[$i] -is [bool] -or $doc.Keys[$i] -isnot [ValueType] -or $doc.Keys[$i] -ne $rowIDs[$i]) {throw 'Keys必须逐项对应Items.BaseID'}}
        }
        $docs.Add(@{Name=$kind+'_ShadowMartial_'+$suffix+'.json';Source=$file.FullName})
    }
    # Validate everything before touching the official directory.
    $target=Join-Path $Dir 'ModProject\GameProject\Mod_MJH\Json';[void][IO.Directory]::CreateDirectory($target)
    $wanted=@{};foreach($doc in $docs) {$wanted[$doc.Name]=$true}
    foreach($file in @(Get-ChildItem -LiteralPath $target -File -Filter '*_ShadowMartial_*.json')) {
        if($file.Name -match '^(Martial|MartialItem|Language)_ShadowMartial_[A-Za-z0-9_-]+\.json$' -and -not $wanted.ContainsKey($file.Name)) {Remove-Item -LiteralPath $file.FullName -Force}
    }
    foreach($doc in $docs) {Copy-Item -LiteralPath $doc.Source -Destination (Join-Path $target $doc.Name) -Force}
}
