﻿function Update-StaticMaxEnhance([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    . (Join-Path $ResourceDir 'game_build.ps1')
    if((Get-ShadowGameBuild $Data).Family -eq 'classic') {
        . (Join-Path $ResourceDir 'patch_equal_layout.ps1')
        return ,(Update-ShadowEqualLayout $Data $Enabled (Get-ShadowNativeLayoutPath $Data $ResourceDir 'staticmax_enhance_layout.json'))
    }
    $offset=0x4dcb50;$size=343
    if($Data.Length -lt 0x4dd73d -or [BitConverter]::ToInt32($Data,0x3c) -ne 0x100) {throw 'Unsupported equipment enhancement DLL'}
    function Read-SMEHex([string]$Name) {
        $hex=[IO.File]::ReadAllText((Join-Path $ResourceDir $Name)).Trim()
        if($hex -notmatch '^[0-9A-F]+$' -or $hex.Length -ne $size*2) {throw 'Invalid equipment enhancement code'}
        [byte[]]$bytes=New-Object byte[] $size
        for($i=0;$i -lt $size;$i++) {$bytes[$i]=[Convert]::ToByte($hex.Substring($i*2,2),16)}
        return ,$bytes
    }
    $original=Read-SMEHex 'staticmax_enhance_original.hex'
    $patched=Read-SMEHex 'staticmax_enhance.hex'
    $sha=[Security.Cryptography.SHA256]::Create()
    try {
        $originalHash=[BitConverter]::ToString($sha.ComputeHash($original)).Replace('-','')
        if($originalHash -ne '8C83F4E3CDB2B2BA052F959880C49B0F5B254FA6ED0F64D76F50F0895D58A551') {throw 'Original equipment enhancement code differs'}
        if([BitConverter]::ToString($sha.ComputeHash($patched)).Replace('-','') -ne 'F5A63264E4DF3B7D2B0E028F4B6FDC27935B641E660CAAC02D99192446BB367A') {throw 'Equipment enhancement patch code differs'}
        if([BitConverter]::ToString($sha.ComputeHash($Data,0x4dc960,477)).Replace('-','') -ne '7EDF13E465BCF3CF7258D7BA4BF1C8F01F5ADD3C5B60252F36DA7E2A9B3B50C5') {throw 'Unsupported equipment attribute range API'}
        $current=[BitConverter]::ToString($Data,$offset,$size)
        if($current -ne [BitConverter]::ToString($original) -and $current -ne [BitConverter]::ToString($patched)) {throw 'Unknown equipment enhancement function; refused'}
        [byte[]]$out=$Data.Clone()
        if($Enabled) {$patched.CopyTo($out,$offset)} else {$original.CopyTo($out,$offset)}
        return ,$out
    } finally {$sha.Dispose()}
}
