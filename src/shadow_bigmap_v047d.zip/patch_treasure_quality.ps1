﻿function Set-TreasureQualityInGame([string]$Dir,[string]$BackupDir,[bool]$Enabled) {
    $path=Join-Path $Dir 'TableData\Drop.bytes'
    $backup=Join-Path $BackupDir 'Drop.bytes.treasure_quality.orig'
    if(-not (Test-Path -LiteralPath $path)){throw 'Missing treasure Drop.bytes'}
    if(-not (Test-Path -LiteralPath $backup)) {
        if(-not $Enabled){return}
        $woodOriginal=Join-Path $BackupDir 'Drop.bytes.treasure_wood.orig'
        if(Test-Path -LiteralPath $woodOriginal){Copy-Item -LiteralPath $woodOriginal -Destination $backup}
        else {Copy-Item -LiteralPath $path -Destination $backup}
    }
    if(-not ('ShadowTreasureQuality' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'treasure_quality_table.cs')}
    [byte[]]$data=[ShadowTreasureQuality]::Update([IO.File]::ReadAllBytes($path),[IO.File]::ReadAllBytes($backup),$Enabled)
    [IO.File]::WriteAllBytes($path,$data)
}
