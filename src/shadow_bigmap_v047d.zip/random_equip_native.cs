using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;
public static class ShadowRandomEquip {
 static uint R(byte[] b,int p){return BitConverter.ToUInt32(b,p);}
 static void W(byte[] b,int p,uint v){Buffer.BlockCopy(BitConverter.GetBytes(v),0,b,p,4);}
 static int Align(int n,int a){return checked((n+a-1)/a*a);}
 static byte[] Slice(byte[] b,int p,int n){byte[] x=new byte[n];Buffer.BlockCopy(b,p,x,0,n);return x;}
 static bool Same(byte[] a,byte[] b){if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true;}
 static void Check(bool b,string s){if(!b)throw new InvalidDataException("Random equipment: "+s);}
 static string Hash(byte[] b){using(SHA256 h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(b)).Replace("-","").ToLowerInvariant();}
 static int Rva(byte[] b,int r){int p=(int)R(b,0x3c),t=p+24+BitConverter.ToUInt16(b,p+20),n=BitConverter.ToUInt16(b,p+6);for(int i=0;i<n;i++){int h=t+i*40,v=(int)R(b,h+12),s=Math.Max((int)R(b,h+8),(int)R(b,h+16));if(r>=v&&r<v+s)return (int)R(b,h+20)+r-v;}throw new InvalidDataException("Random equipment unmapped RVA");}
 static byte[] Code(byte[] c,int baseRva,int[] offsets,int[] targets,int[] local){byte[] b=(byte[])c.Clone();for(int i=0;i<offsets.Length;i++)W(b,offsets[i],unchecked((uint)(targets[i]+(local[i]!=0?baseRva:0)-baseRva-offsets[i]-4)));return b;}
 static byte[] Jump(int from,int to){byte[] b={0xe8,0,0,0,0};W(b,1,unchecked((uint)(to-from-5)));return b;}
 // Exact previous release: item/maze scopes jumped over the minimum-rank check.
 // Restore only that known branch when recognizing old code, never arbitrary edits.
 static byte[] PreviousSourceGate(byte[] current){
  byte[] old=(byte[])current.Clone();byte[] pattern={0x41,0x83,0x7a,0x0c,0x02,0x90,0x90,0x90,0x90,0x90,0x90,0x48,0x8b,0x4c,0x24,0x58};
  int found=0;
  for(int i=0;i<=old.Length-pattern.Length;i++){
   bool same=true;for(int j=0;same&&j<pattern.Length;j++)same=old[i+j]==pattern[j];
   if(same){byte[] branch={0x0f,0x82,0x13,0x00,0x00,0x00};Buffer.BlockCopy(branch,0,old,i+5,6);found++;}
  }
  Check(found==1,"unexpected source rank gate layout");return old;
 }
 public static byte[] Update(byte[] input,bool enabled,byte[] code,byte[] alternateCode,int[] offsets,int[] targets,int[] local,int[] hooks,byte[][] originalHooks,int[] hookEntries,int[] begins,int[] ends,int[] frames,byte[] unwind,int[] patchRvas,byte[][] originals,byte[][] patched,int[] guards,int[] sizes,string[] hashes,int disabledHook){
  byte[] b=(byte[])input.Clone();int pe=(int)R(b,0x3c),opt=pe+24;
  Check(R(b,pe)==0x4550&&BitConverter.ToUInt16(b,pe+4)==0x8664&&BitConverter.ToUInt16(b,opt)==0x20b,"unsupported PE");
  int table=opt+BitConverter.ToUInt16(b,pe+20),count=BitConverter.ToUInt16(b,pe+6),last=table+(count-1)*40;
  // Task grants are disabled. The forge hook remains a stable installation anchor.
  int anchor=1;int h0=Rva(b,hooks[anchor]);bool installed=!Same(Slice(b,h0,5),originalHooks[anchor]);
  if(installed){
   Check(b[h0]==0xe8,"unknown hook opcode");int baseRva=hooks[anchor]+5+BitConverter.ToInt32(b,h0+1)-hookEntries[anchor];
   int raw=Rva(b,baseRva),meta=raw+0x5a00;
   Check(meta+96<=b.Length&&Encoding.ASCII.GetString(b,meta,8)=="RANDEQ01","unrecognized patch; do not overwrite");
   Check(R(b,meta+8)==1&&R(b,meta+12)==count,"invalid metadata");
   int oldLen=(int)R(b,meta+16);uint oldImage=R(b,meta+20),oldEx=R(b,meta+24),oldExSize=R(b,meta+28),oldChecksum=R(b,meta+32);
   Check(baseRva>=R(b,last+12)&&raw>=R(b,last+20)&&oldLen<=raw&&b.Length==R(b,last+20)+R(b,last+16),"patch must be the last extension");
   Check(Same(Slice(b,raw,code.Length),Code(code,baseRva,offsets,targets,local))||Same(Slice(b,raw,alternateCode.Length),Code(alternateCode,baseRva,offsets,targets,local))||Same(Slice(b,raw,code.Length),PreviousSourceGate(Code(code,baseRva,offsets,targets,local)))||Same(Slice(b,raw,alternateCode.Length),PreviousSourceGate(Code(alternateCode,baseRva,offsets,targets,local))),"unknown installed code");
   Check(R(b,opt+136)==baseRva+0x6000&&R(b,opt+140)==oldExSize+12*begins.Length,"unwind directory changed");
   Check(Same(Slice(b,raw+0x6000,(int)oldExSize),Slice(b,Rva(b,(int)oldEx),(int)oldExSize)),"original unwind changed");
   byte[] expectedUnwind=(byte[])unwind.Clone();W(expectedUnwind,8,R(expectedUnwind,8)+(uint)baseRva);
   Check(Same(Slice(b,raw+0x5980,expectedUnwind.Length),expectedUnwind),"installed unwind changed");
   Buffer.BlockCopy(BitConverter.GetBytes((ushort)(0x218/8)),0,expectedUnwind,6,2);Check(Same(Slice(b,raw+0x5990,expectedUnwind.Length),expectedUnwind),"forge unwind changed");
   for(int i=0;i<begins.Length;i++){int e=raw+0x6000+(int)oldExSize+i*12;Check(R(b,e)==baseRva+begins[i]&&R(b,e+4)==baseRva+ends[i]&&R(b,e+8)==baseRva+(frames[i]==0x218?0x5990:0x5980),"installed runtime entry changed");}
   for(int i=0;i<hooks.Length;i++){int o=Rva(b,hooks[i]);Check(Same(Slice(b,o,5),Jump(hooks[i],baseRva+hookEntries[i]))||(hooks[i]==disabledHook&&Same(Slice(b,o,5),originalHooks[i])),"installed hook changed");Buffer.BlockCopy(originalHooks[i],0,b,o,5);}
   for(int i=0;i<patchRvas.Length;i++){int o=Rva(b,patchRvas[i]);Check(Same(Slice(b,o,patched[i].Length),patched[i]),"installed patch changed");Buffer.BlockCopy(originals[i],0,b,o,originals[i].Length);}
   Buffer.BlockCopy(b,meta+40,b,last,40);W(b,opt+56,oldImage);W(b,opt+136,oldEx);W(b,opt+140,oldExSize);W(b,opt+64,oldChecksum);Array.Resize(ref b,oldLen);
  }
  if(!enabled)return b;
  for(int i=0;i<hooks.Length;i++)Check(Same(Slice(b,Rva(b,hooks[i]),5),originalHooks[i]),"original hook changed");
  for(int i=0;i<patchRvas.Length;i++)Check(Same(Slice(b,Rva(b,patchRvas[i]),originals[i].Length),originals[i]),"original bytes changed");
  for(int i=0;i<guards.Length;i++)Check(Hash(Slice(b,Rva(b,guards[i]),sizes[i]))==hashes[i],"native function changed "+guards[i].ToString("X"));
  int oldLength=b.Length,fa=(int)R(b,opt+36),sa=(int)R(b,opt+32);Check(oldLength==R(b,last+20)+R(b,last+16),"unexpected overlay");
  uint ex=R(b,opt+136),exSize=R(b,opt+140);Check(exSize>0&&exSize%12==0,"invalid unwind table");byte[] pdata=Slice(b,Rva(b,(int)ex),(int)exSize);
  int relative=Align(Math.Max((int)R(b,last+8),(int)R(b,last+16)),0x1000),baseR=(int)R(b,last+12)+relative,rawR=(int)R(b,last+20)+relative;
  Check(R(pdata,pdata.Length-12)<baseR,"unsorted unwind table");
  int used=relative+0x6000+pdata.Length+12*begins.Length,rawSize=Align(used,fa);byte[] output=new byte[(int)R(b,last+20)+rawSize];Buffer.BlockCopy(b,0,output,0,b.Length);
  byte[] relocated=Code(code,baseR,offsets,targets,local);Buffer.BlockCopy(relocated,0,output,rawR,relocated.Length);
  int m=rawR+0x5a00;Buffer.BlockCopy(Encoding.ASCII.GetBytes("RANDEQ01"),0,output,m,8);W(output,m+8,1);W(output,m+12,(uint)count);W(output,m+16,(uint)oldLength);W(output,m+20,R(b,opt+56));W(output,m+24,ex);W(output,m+28,exSize);W(output,m+32,R(b,opt+64));Buffer.BlockCopy(b,last,output,m+40,40);
  byte[] u=(byte[])unwind.Clone();W(u,8,R(u,8)+(uint)baseR);Buffer.BlockCopy(u,0,output,rawR+0x5980,u.Length);byte[] forge=(byte[])u.Clone();Buffer.BlockCopy(BitConverter.GetBytes((ushort)(0x218/8)),0,forge,6,2);Buffer.BlockCopy(forge,0,output,rawR+0x5990,forge.Length);
  Buffer.BlockCopy(pdata,0,output,rawR+0x6000,pdata.Length);for(int i=0;i<begins.Length;i++){int e=rawR+0x6000+pdata.Length+i*12;W(output,e,(uint)(baseR+begins[i]));W(output,e+4,(uint)(baseR+ends[i]));W(output,e+8,(uint)(baseR+(frames[i]==0x218?0x5990:0x5980)));}
  W(output,last+8,(uint)used);W(output,last+16,(uint)rawSize);W(output,last+36,(R(b,last+36)|0xe0000020)&~0x02000000u);W(output,opt+56,(uint)Align((int)R(b,last+12)+used,sa));W(output,opt+136,(uint)(baseR+0x6000));W(output,opt+140,exSize+(uint)(12*begins.Length));W(output,opt+64,0);
  // Retain layout/code validation for known v0.44 installations, but do not hook task grants.
  for(int i=0;i<hooks.Length;i++){if(hooks[i]==disabledHook)continue;Buffer.BlockCopy(Jump(hooks[i],baseR+hookEntries[i]),0,output,Rva(output,hooks[i]),5);}
  for(int i=0;i<patchRvas.Length;i++)Buffer.BlockCopy(patched[i],0,output,Rva(output,patchRvas[i]),patched[i].Length);
  return output;
 }
 static ulong Var(byte[] b,ref int p){ulong v=0;int s=0;while(p<b.Length&&s<64){byte x=b[p++];v|=(ulong)(x&127)<<s;if(x<128)return v;s+=7;}throw new InvalidDataException("Invalid Shop varint");}
 static void V(List<byte> b,ulong v){while(v>=128){b.Add((byte)((v&127)|128));v>>=7;}b.Add((byte)v);}
 static void Int(List<byte> b,int k,ulong v){V(b,(ulong)(k<<3));V(b,v);}
 static void Blob(List<byte> b,int k,byte[] v){V(b,(ulong)(k<<3|2));V(b,(ulong)v.Length);b.AddRange(v);}
 static bool Own(ulong id){return id==990004||id==990020||id==990019;}
 static byte[] Row(ulong id){ulong business=id==990004?4UL:id==990020?20UL:19UL;ulong city=id==990004?27UL:25UL;List<byte> b=new List<byte>();Int(b,1,id);Int(b,2,business);Blob(b,3,Encoding.UTF8.GetBytes("随机装备"));ulong[] values={417716,1,1,1,88888,0,city,0,0,0,0};for(int i=0;i<values.Length;i++)Int(b,4+i,values[i]);return b.ToArray();}
 public static byte[] Shops(byte[] input,bool enabled){List<byte> b=new List<byte>();int p=0;HashSet<ulong> keys=new HashSet<ulong>(),rows=new HashSet<ulong>();while(p<input.Length){int start=p;ulong tag=Var(input,ref p),v=0;byte[] row=null;int w=(int)(tag&7),field=(int)(tag>>3);if(w==0)v=Var(input,ref p);else if(w==2){int n=checked((int)Var(input,ref p));Check(n>=0&&p+n<=input.Length,"invalid Shop blob");row=Slice(input,p,n);p+=n;}else if(w==1)p+=8;else if(w==5)p+=4;else throw new InvalidDataException("Invalid Shop wire type");bool remove=false;if(field==1&&w==0&&Own(v)){Check(keys.Add(v),"duplicate Shop key");remove=true;}if(field==2&&w==2){int q=0;Check(Var(row,ref q)==8,"Shop BaseID missing");ulong id=Var(row,ref q);if(Own(id)){Check(rows.Add(id)&&Same(row,Row(id)),"custom Shop ID collision");remove=true;}}if(!remove)b.AddRange(Slice(input,start,p-start));}Check(keys.SetEquals(rows),"custom Shop keys/rows mismatch");if(enabled)foreach(ulong id in new ulong[]{990004,990020,990019}){Int(b,1,id);Blob(b,2,Row(id));}return b.ToArray();}
}
