﻿# Scoped account collection reset. Strip before all existing trailing sections.
function Update-ChongyangReset([byte[]]$Data,$Switches,[string]$CodePath) {
    [byte[]]$b=$Data.Clone()
    function CYH([int]$o,[int]$n) { [BitConverter]::ToString($b,$o,$n).Replace('-','') }
    function CYP([int]$o,[uint32]$v) { [BitConverter]::GetBytes($v).CopyTo($b,$o) }
    $hex=[IO.File]::ReadAllText($CodePath).Trim()
    if($hex -notmatch '^[0-9A-F]+$' -or $hex.Length%2 -or $hex.Length -gt 512) {throw 'Invalid Chongyang reset code'}
    [byte[]]$code=New-Object byte[] ($hex.Length/2)
    for($i=0;$i -lt $code.Length;$i++) {$code[$i]=[Convert]::ToByte($hex.Substring($i*2,2),16)}
    $pe=[BitConverter]::ToInt32($b,0x3c);$opt=$pe+24
    if($pe -ne 0x100 -or (CYH $pe 6) -ne '504500006486') {throw 'Unsupported Chongyang reset PE'}
    $table=$opt+[BitConverter]::ToUInt16($b,$pe+20);$count=[BitConverter]::ToUInt16($b,$pe+6)
    $sites=@(0x631105,0x6323d6)
    $orig=@();$patched=@()
    foreach($site in $sites) {
        [byte[]]$a=0xe8,0,0,0,0;[BitConverter]::GetBytes([int](0x2bea40-$site-5)).CopyTo($a,1);$orig+=,$a
        [byte[]]$a=0xe8,0,0,0,0;[BitConverter]::GetBytes([int](0x1b45000-$site-5)).CopyTo($a,1);$patched+=,$a
    }
    $last=$table+($count-1)*40
    if((CYH $last 8) -eq '2E64796379720000') {
        $raw=[BitConverter]::ToUInt32($b,$last+20);$rva=[BitConverter]::ToUInt32($b,$last+12)
        $span=0x1b46000-$rva;$offset=0x1b45000-$rva
        if($rva -notin @(0x1b40000,0x1b41000,0x1b43000,0x1b45000) -or $b.Length -ne $raw+$span -or [BitConverter]::ToUInt32($b,$opt+56) -ne 0x1b46000) {throw 'Unknown Chongyang reset section'}
        [byte[]]$header=New-Object byte[] 40;[Text.Encoding]::ASCII.GetBytes('.dycyr').CopyTo($header,0)
        foreach($v in @(@(8,$span),@(12,$rva),@(16,$span),@(20,$raw),@(36,0x60000020))) {[BitConverter]::GetBytes([uint32]$v[1]).CopyTo($header,$v[0])}
        [byte[]]$expected=New-Object byte[] $span;$code.CopyTo($expected,$offset)
        if((CYH $last 40) -ne [BitConverter]::ToString($header).Replace('-','') -or (CYH $raw $span) -ne [BitConverter]::ToString($expected).Replace('-','')) {throw 'Unknown Chongyang reset payload'}
        for($i=0;$i -lt $sites.Count;$i++) {
            if((CYH ($sites[$i]-0xc00) 5) -ne [BitConverter]::ToString($patched[$i]).Replace('-','')) {throw 'Unknown Chongyang reset hook'}
            $orig[$i].CopyTo($b,($sites[$i]-0xc00))
        }
        [Array]::Clear($b,$last,40);$count--;[BitConverter]::GetBytes([uint16]$count).CopyTo($b,$pe+6)
        $prev=$table+($count-1)*40;$end=[BitConverter]::ToUInt32($b,$prev+12)+[BitConverter]::ToUInt32($b,$prev+8)
        CYP ($opt+56) ([uint32]([math]::Ceiling($end/0x1000)*0x1000))
        [Array]::Resize([ref]$b,[int]$raw)
    }
    # 仅兼容清理已发布0.38的旧补丁，不再安装重阳神剑功能。
    return ,$b
}
