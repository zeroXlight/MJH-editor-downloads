using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;

// Own a small, reversible suffix of the original relocation section. No new
// section header is consumed. Discardable is explicitly cleared for live code.
public static class ShadowClassicShared {
 static uint R(byte[] b,int p){return BitConverter.ToUInt32(b,p);}
 static void W(byte[] b,int p,uint v){Buffer.BlockCopy(BitConverter.GetBytes(v),0,b,p,4);}
 static void C(bool ok,string message){if(!ok)throw new InvalidDataException("Classic shared: "+message);}
 static int A(int value,int align){return checked((value+align-1)/align*align);}
 static byte[] S(byte[] b,int p,int n){byte[] o=new byte[n];Buffer.BlockCopy(b,p,o,0,n);return o;}
 static bool Eq(byte[] a,byte[] b){if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true;}
 static byte[] Header(byte[] original,int codeRva,int codeRaw,int fileAlign){
  byte[] h=(byte[])original.Clone();
  W(h,8,checked((uint)(codeRva+0x1000-(int)R(h,12))));
  W(h,16,checked((uint)A(codeRaw+0x1000-(int)R(h,20),fileAlign)));
  W(h,36,(R(h,36)&~0x02000000u)|0x60000020u);
  return h;
 }
 static byte[] Suffix(int root,int raw,byte[] code,int flags,uint checksum){
  byte[] b=new byte[raw+0x1000-root];
  Buffer.BlockCopy(code,0,b,raw-root,code.Length);
  int meta=raw-root+0xc00;
  Buffer.BlockCopy(Encoding.ASCII.GetBytes("DYCORE01"),0,b,meta,8);
  W(b,meta+8,(uint)flags);W(b,meta+12,checksum);
  return b;
 }
 public static byte[] Update(byte[] input,int flags,byte[] code,int codeRva,int codeRaw,int root,
  byte[] originalHeader,int[] offsets,byte[][] originals,byte[][] patched,int[] bits,
  int[] guards,int[] sizes,string[] hashes,int[] pdataOffsets,byte[][] pdataOriginals,byte[][] pdataPatched) {
  C(flags>=0&&flags<=7&&code.Length>0&&code.Length<=0x500,"invalid flags/code");
  C(originalHeader.Length==40&&offsets.Length==originals.Length&&offsets.Length==patched.Length&&offsets.Length==bits.Length,"invalid patch metadata");
  C(input.Length>=root&&root>0x400,"truncated parent");
  int pe=(int)R(input,0x3c),opt=pe+24;
  C(R(input,pe)==0x4550&&BitConverter.ToUInt16(input,pe+4)==0x8664&&BitConverter.ToUInt16(input,opt)==0x20b,"unsupported PE");
  int count=BitConverter.ToUInt16(input,pe+6),table=opt+BitConverter.ToUInt16(input,pe+20),last=table+(count-1)*40;
  C(count==7&&Encoding.ASCII.GetString(originalHeader,0,6)==".reloc","strip child sections before shared update");
  C(root==R(originalHeader,20)+R(originalHeader,16),"invalid original parent length");
  C(codeRva-(int)R(originalHeader,12)==codeRaw-(int)R(originalHeader,20)&&codeRaw>=root,"inconsistent code mapping");
  int sa=(int)R(input,opt+32),fa=(int)R(input,opt+36);
  C(sa==0x1000&&fa==0x200,"unsupported alignment");
  uint oldImage=(uint)A((int)R(originalHeader,12)+Math.Max((int)R(originalHeader,8),(int)R(originalHeader,16)),sa);
  byte[] installedHeader=Header(originalHeader,codeRva,codeRaw,fa);
  bool installed=input.Length!=root;
  int previousFlags=0;uint checksum=R(input,opt+64);
  if(installed){
   C(input.Length==codeRaw+0x1000,"unknown suffix/child section");
   int meta=codeRaw+0xc00;
   C(Encoding.ASCII.GetString(input,meta,8)=="DYCORE01","unknown suffix owner");
   previousFlags=(int)R(input,meta+8);checksum=R(input,meta+12);
   C(previousFlags>0&&previousFlags<=7,"invalid stored switches");
   C(Eq(S(input,root,input.Length-root),Suffix(root,codeRaw,code,previousFlags,checksum)),"shared code or metadata modified");
   C(Eq(S(input,last,40),installedHeader)&&R(input,opt+56)==A(codeRva+0x1000,sa)&&R(input,opt+64)==0,"installed section header changed");
  } else {
   C(Eq(S(input,last,40),originalHeader)&&R(input,opt+56)==oldImage,"unknown original section layout");
  }
  byte[] normalized=(byte[])input.Clone();
  C(pdataOffsets.Length==pdataOriginals.Length&&pdataOffsets.Length==pdataPatched.Length,"invalid unwind metadata");
  for(int i=0;i<pdataOffsets.Length;i++){
   int off=pdataOffsets[i];byte[] before=pdataOriginals[i],after=pdataPatched[i];
   C(before.Length==after.Length&&off>=0&&off+before.Length<=root,"invalid unwind range");
   C(Eq(S(input,off,before.Length),installed?after:before),"unwind table changed");
   Buffer.BlockCopy(before,0,normalized,off,before.Length);
  }
  for(int i=0;i<offsets.Length;i++){
   C(originals[i].Length==patched[i].Length&&offsets[i]>=0&&offsets[i]+originals[i].Length<=root,"invalid native site");
   byte[] expected=(previousFlags&bits[i])!=0?patched[i]:originals[i];
   C(Eq(S(input,offsets[i],expected.Length),expected),"native hook and stored flags disagree");
   Buffer.BlockCopy(originals[i],0,normalized,offsets[i],originals[i].Length);
  }
  using(SHA256 sha=SHA256.Create())for(int i=0;i<guards.Length;i++){
   C(guards[i]>=0&&sizes[i]>0&&guards[i]+sizes[i]<=root,"invalid function guard");
   C(BitConverter.ToString(sha.ComputeHash(normalized,guards[i],sizes[i])).Replace("-","").ToLowerInvariant()==hashes[i],"unknown original function");
  }
  byte[] output=new byte[flags==0?root:codeRaw+0x1000];
  Buffer.BlockCopy(normalized,0,output,0,root);
  Buffer.BlockCopy(flags==0?originalHeader:installedHeader,0,output,last,40);
  W(output,opt+56,flags==0?oldImage:(uint)A(codeRva+0x1000,sa));W(output,opt+64,flags==0?checksum:0);
  if(flags!=0){
   for(int i=0;i<pdataOffsets.Length;i++)Buffer.BlockCopy(pdataPatched[i],0,output,pdataOffsets[i],pdataPatched[i].Length);
   byte[] suffix=Suffix(root,codeRaw,code,flags,checksum);Buffer.BlockCopy(suffix,0,output,root,suffix.Length);
   for(int i=0;i<offsets.Length;i++)if((flags&bits[i])!=0)Buffer.BlockCopy(patched[i],0,output,offsets[i],patched[i].Length);
  }
  return output;
 }
}
