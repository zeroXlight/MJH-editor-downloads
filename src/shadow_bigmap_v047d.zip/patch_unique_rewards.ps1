﻿function Update-UniqueRewards([byte[]]$Data,[string]$OriginalPath,[bool]$Enabled) {
    if(-not ('ShadowUniqueRewards' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'unique_rewards_table.cs')}
    return ,[ShadowUniqueRewards]::Update($Data,[IO.File]::ReadAllBytes($OriginalPath),$Enabled)
}
function Set-UniqueRewardsInGame([string]$Dir,[string]$BackupDir,[bool]$Enabled) {
    $path=Join-Path $Dir 'TableData\StoryDiffDrop.bytes';$backup=Join-Path $BackupDir 'StoryDiffDrop.bytes.orig'
    if(-not (Test-Path -LiteralPath $path)){throw 'Missing unique rewards table'}
    if(-not (Test-Path -LiteralPath $backup)) {
        if(-not $Enabled){return}
        Copy-Item -LiteralPath $path -Destination $backup
    }
    [byte[]]$data=Update-UniqueRewards ([IO.File]::ReadAllBytes($path)) $backup $Enabled
    [IO.File]::WriteAllBytes($path,$data)
}
