using System;
using System.IO;
using System.Collections.Generic;
public static class ShadowTreasureQuality {
 class F {public int Key,Wire,Start,ValueStart,End;public ulong Value;}
 static ulong Var(byte[] b,ref int pos,int end){ulong n=0;int s=0;while(pos<end&&s<64){byte x=b[pos++];n|=(ulong)(x&127)<<s;if(x<128)return n;s+=7;}throw new InvalidDataException("Invalid treasure drop varint");}
 static List<F> Fields(byte[] b){int pos=0;var list=new List<F>();while(pos<b.Length){var f=new F();f.Start=pos;ulong t=Var(b,ref pos,b.Length);f.Key=(int)(t>>3);f.Wire=(int)(t&7);f.ValueStart=pos;if(f.Key==0)throw new InvalidDataException("Invalid field");switch(f.Wire){case 0:f.Value=Var(b,ref pos,b.Length);break;case 1:pos+=8;break;case 2:int len=checked((int)Var(b,ref pos,b.Length));f.ValueStart=pos;pos=checked(pos+len);break;case 5:pos+=4;break;default:throw new InvalidDataException("Invalid wire type");}if(pos>b.Length)throw new InvalidDataException("Field crosses boundary");f.End=pos;list.Add(f);}return list;}
 static byte[] Slice(byte[] b,int p,int n){var x=new byte[n];Buffer.BlockCopy(b,p,x,0,n);return x;}
 static void V(List<byte> b,ulong v){while(v>=128){b.Add((byte)((v&127)|128));v>>=7;}b.Add((byte)v);}


 static ulong N(byte[] row,int key,ulong fallback){ulong v=fallback;bool seen=false;foreach(var f in Fields(row))if(f.Key==key&&f.Wire==0){if(seen)throw new InvalidDataException("Duplicate treasure field "+key);seen=true;v=f.Value;}return v;}
 static bool Target(ulong group){return group>=7511&&group<=7604&&group%10>=1&&group%10<=4;}
 static bool Quality(byte[] child){ulong lo=N(child,6,0),hi=N(child,7,0);return lo>=1&&lo<=hi&&hi<=7;}
 static byte[] EditChild(byte[] child,byte[] before,bool enabled){
  ulong oldLo=N(before,6,0),oldHi=N(before,7,0);ulong newLo=oldHi==7?Math.Min(7UL,oldLo+1):oldLo;ulong newHi=oldHi<7?oldHi+1:7;
  ulong curLo=N(child,6,0),curHi=N(child,7,0);
  if(!((curLo==oldLo&&curHi==oldHi)||(curLo==newLo&&curHi==newHi)))throw new InvalidDataException("Treasure quality changed by unknown source");
  ulong lo=enabled?newLo:oldLo,hi=enabled?newHi:oldHi;var output=new List<byte>();
  foreach(var f in Fields(child)){if((f.Key==6||f.Key==7)&&f.Wire==0){V(output,(ulong)(f.Key<<3));V(output,f.Key==6?lo:hi);}else output.AddRange(Slice(child,f.Start,f.End-f.Start));}
  return output.ToArray();
 }
 static byte[] Edit(byte[] row,byte[] baseline,bool enabled){
  if(!Target(N(row,2,8008)))return row;
  var before=new List<byte[]>();if(baseline!=null)foreach(var f in Fields(baseline))if(f.Key==6&&f.Wire==2){var c=Slice(baseline,f.ValueStart,f.End-f.ValueStart);if(Quality(c))before.Add(c);}
  var output=new List<byte>();int at=0;
  foreach(var f in Fields(row)){
   if(f.Key==6&&f.Wire==2){var c=Slice(row,f.ValueStart,f.End-f.ValueStart);if(Quality(c)){
    if(at>=before.Count)throw new InvalidDataException("Missing original treasure quality candidate: "+N(row,1,0));
    var orig=before[at++];
    // Range-only edits: a known sequence of quality-bearing candidates. Wood-only
    // entries have no quality range, so removing/reinserting them cannot shift this sequence.
    c=EditChild(c,orig,enabled);
   }V(output,50);V(output,(ulong)c.Length);output.AddRange(c);}
   else output.AddRange(Slice(row,f.Start,f.End-f.Start));
  }
  if(at!=before.Count)throw new InvalidDataException("Treasure quality candidate structure changed: "+N(row,1,0));
  return output.ToArray();
 }
 public static byte[] Update(byte[] input,byte[] baseline,bool enabled){
  var originals=new Dictionary<ulong,byte[]>();foreach(var f in Fields(baseline))if(f.Key==2&&f.Wire==2){var row=Slice(baseline,f.ValueStart,f.End-f.ValueStart);ulong id=N(row,1,0);if(originals.ContainsKey(id))throw new InvalidDataException("Duplicate original drop row");originals[id]=row;}
  var seen=new HashSet<ulong>();var output=new List<byte>();
  foreach(var f in Fields(input)){
   if(f.Key==2&&f.Wire==2){var row=Slice(input,f.ValueStart,f.End-f.ValueStart);ulong id=N(row,1,0);if(!seen.Add(id))throw new InvalidDataException("Duplicate input drop row");byte[] before;originals.TryGetValue(id,out before);var changed=Edit(row,before,enabled);V(output,18);V(output,(ulong)changed.Length);output.AddRange(changed);}
   else output.AddRange(Slice(input,f.Start,f.End-f.Start));
  }return output.ToArray();
 }
}
