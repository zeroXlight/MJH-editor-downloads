﻿param(
    [string]$Path = '',
    [string]$Output = '',
    [switch]$CountOnly,
    [switch]$Quiet
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# =====================================================================
#  梦江湖 MOD · 「装备白字属性完美」补丁器（零依赖，仅用 Windows 自带 PowerShell）
#
#  要什么效果
#  ---------------------------------------------------------------
#  装备的**固定属性（白字）随机永远取最高值** —— 每次生成的装备，基础属性
#  直接就是原版区间的上限，不用再反复刷。
#
#  表在哪、结构是什么
#  ---------------------------------------------------------------
#  `TableData/ItemBaseStatic.bytes` —— 装备基础属性区间表（原生/服务端读的表，
#  改 .bytes 才生效）。
#  逐字节核对结果（与 `references/_lua_full/ItemBaseStatic.lua` 完全对齐）：
#      顶层： field 1 = 每行的列头（连续 8 个）
#            field 2 = 每行的行数据（子消息）× 8
#            field 3 = 表自带的 md5 串（**不动它**）
#      行内： field 1 = BaseID        field 2 = AttrType
#            field 4 = RandomSize    field 5 = RandomBase（重复 × 10 = 10 个品质档）
#      RandomBase 子消息：
#            field 1 = MinBaseValue   field 2 = MaxBaseValue
#            field 3 = MinExtraValue  field 4 = MaxExtraValue
#      （每行第 1 档是**全 0 的空子消息**，保持原样不动）
#
#  做法：1 := 2、3 := 4（下限抬到上限）
#  ---------------------------------------------------------------
#    * 原版取值 = 在 [Min,Max] 区间里随机；把下限抬到上限即恒取上限。
#      **区间上限（field 2 / field 4）一个字都不动**，所以只是去掉随机下探，
#      不改变数值上限，也不动属性种类/条数/蓝条/掉落。
#    * 只重编码 RandomBase 子消息里的 field 1 / 3；其余字段（含顶层列、行内
#      BaseID/AttrType/RandomSize、表 md5）**逐字节原样搬运** —— 这是本补丁安全的前提。
#    * protobuf 里缺省的标量就是 0：原版没写 field 1/3（=0）且上限也是 0 时，
#      补丁后同样不写，避免凭空多出字段。
#
#  设计要点
#  ---------------------------------------------------------------
#    * 幂等：已经是满值的表再跑一次不会有任何字节变化。
#    * 自校验：改写后重新解析一遍，必须"每个非零区间都 min==max"才允许落盘；
#      行数变化、解析异常一律放弃写入。
#    * 可被 install.ps1 复用（`Get-StaticMaxState` / `Apply-StaticMax`），
#      也可单独命令行运行。
#      ★ 被 dot-source 时务必显式传参（`. <本文件> -Path ''`），否则 PowerShell
#        会拿调用方作用域里的同名变量当参数值。
#
#  单独命令行用法
#     powershell -ExecutionPolicy Bypass -File patch_item_static_max.ps1 -Path <ItemBaseStatic.bytes> [-Output <新文件>] [-CountOnly]
#     不给 -Output 时输出到 <输入>.max-test，**默认不覆盖原文件**。
# =====================================================================

$SCRIPT:SM_ROW_FIELD = 2      # 顶层：行数据
$SCRIPT:SM_RB_FIELD = 5       # 行内：RandomBase（重复子消息）

function Read-VarintSM {
    param([byte[]]$Buf, [ref]$Pos)
    [long]$n = 0
    [int]$s = 0
    while ($true) {
        if ($Pos.Value -ge $Buf.Length) { throw 'varint 读到文件末尾' }
        [int]$b = [int]$Buf[$Pos.Value]
        $Pos.Value = $Pos.Value + 1
        $n = $n -bor ([long]($b -band 0x7F) -shl $s)
        if (($b -band 0x80) -eq 0) { return $n }
        $s = $s + 7
        if ($s -gt 63) { throw 'varint 过长(>10 字节)，文件可能不是该表' }
    }
}

function Add-VarintSM {
    param([System.Collections.Generic.List[byte]]$Out, [long]$N)
    if ($N -lt 0) { throw 'varint 不接受负数' }
    while ($true) {
        [int]$b = [int]($N -band 0x7F)
        $N = $N -shr 7
        if ($N -ne 0) { $Out.Add([byte]($b -bor 0x80)) }
        else { $Out.Add([byte]$b); break }
    }
}

# 读完当前字段的值，$Pos 停在字段末尾
function Skip-ValueSM {
    param([byte[]]$Buf, [ref]$Pos, [int]$WireType, [int]$At)
    switch ($WireType) {
        0 { [void](Read-VarintSM $Buf $Pos) }
        1 { $Pos.Value = $Pos.Value + 8 }
        2 { [long]$ln = Read-VarintSM $Buf $Pos; $Pos.Value = $Pos.Value + [int]$ln }
        5 { $Pos.Value = $Pos.Value + 4 }
        default { throw ("偏移 {0} 处出现非法 wiretype {1}，文件可能不是该表" -f $At, $WireType) }
    }
}

# 解析 [$Start,$End)，返回字段区间清单（不复制字节）
function Get-SmSpans {
    param([byte[]]$Buf, [int]$Start, [int]$End)
    $list = New-Object 'System.Collections.Generic.List[object]'
    [int]$i = $Start
    while ($i -lt $End) {
        [int]$fs = $i
        [long]$key = Read-VarintSM $Buf ([ref]$i)
        [int]$f = [int]($key -shr 3)
        [int]$wt = [int]($key -band 7)
        [int]$vs = $i                      # key 之后 = 值 / 长度前缀的位置
        Skip-ValueSM $Buf ([ref]$i) $wt $fs
        if ($i -gt $End) { throw ("偏移 {0} 处字段越过了所属记录边界" -f $fs) }
        $list.Add([pscustomobject]@{ Field = $f; WireType = $wt; Start = $fs; End = $i; VStart = $vs })
    }
    return , $list
}

function Get-SmRowCount {
    param([byte[]]$Data)
    [int]$n = 0
    [int]$i = 0
    while ($i -lt $Data.Length) {
        [int]$fs = $i
        [long]$key = Read-VarintSM $Data ([ref]$i)
        [int]$f = [int]($key -shr 3)
        [int]$wt = [int]($key -band 7)
        if ($f -eq $SCRIPT:SM_ROW_FIELD -and $wt -eq 2) {
            [long]$ln = Read-VarintSM $Data ([ref]$i)
            $i = $i + [int]$ln
            $n = $n + 1
        }
        else { Skip-ValueSM $Data ([ref]$i) $wt $fs }
    }
    return $n
}

# 取每一行的行数据字节（顶层 field 2）
function Get-SmRows {
    param([byte[]]$Data)
    $rows = New-Object System.Collections.ArrayList
    foreach ($s in (Get-SmSpans $Data 0 $Data.Length)) {
        if ($s.Field -eq $SCRIPT:SM_ROW_FIELD -and $s.WireType -eq 2) {
            [int]$p = $s.VStart
            [long]$ln = Read-VarintSM $Data ([ref]$p)
            $body = New-Object byte[] $ln
            [Array]::Copy($Data, $p, $body, 0, [int]$ln)
            [void]$rows.Add($body)
        }
    }
    return , $rows.ToArray()
}

# 取一行里所有 RandomBase 子消息（行内 field 5）
function Get-SmRandomBases {
    param([byte[]]$Row)
    $out = New-Object System.Collections.ArrayList
    foreach ($s in (Get-SmSpans $Row 0 $Row.Length)) {
        if ($s.Field -eq $SCRIPT:SM_RB_FIELD -and $s.WireType -eq 2) {
            [int]$p = $s.VStart
            [long]$ln = Read-VarintSM $Row ([ref]$p)
            $body = New-Object byte[] $ln
            [Array]::Copy($Row, $p, $body, 0, [int]$ln)
            [void]$out.Add($body)
        }
    }
    return , $out.ToArray()
}

# 读一个 RandomBase 子消息的 1..4 字段值（缺省 = 0）
function Read-SmRandomBase {
    param([byte[]]$Msg)
    $vals = @{}
    foreach ($s in (Get-SmSpans $Msg 0 $Msg.Length)) {
        if ($s.Field -lt 1 -or $s.Field -gt 4) { continue }
        if ($s.WireType -ne 0) { throw ("RandomBase 的 field {0} 不是 varint，文件结构异常" -f $s.Field) }
        if ($vals.ContainsKey($s.Field)) { throw ("RandomBase 的 field {0} 重复，文件结构异常" -f $s.Field) }
        [int]$p = $s.VStart
        $vals[$s.Field] = [long](Read-VarintSM $Msg ([ref]$p))
    }
    return $vals
}

# 按字段号升序写出 RandomBase 的 1..4：
#   field 1 / 3（下限）→ 抬到对应的上限值（2 / 4）
#   field 2 / 4（上限）→ 原值原样写回
#   返回 $true = 写了；$false = 该字段本来就没有、值又是 0（保持 protobuf 的"缺省"）
#   ★ 四个字段都走这个函数，是因为它们在输出里要**按字段号升序**重排 ——
#     少判一个就会把上限字段当成目标字段去改写。
function Add-SmMaxField {
    param([System.Collections.Generic.List[byte]]$Out, [int]$Field, $Values)
    if ($Field -eq 1 -or $Field -eq 3) {
        $src = if ($Field -eq 1) { 2 } else { 4 }
        [long]$max = 0
        if ($Values.ContainsKey($src)) { $max = [long]$Values[$src] }
        if ($max -eq 0 -and (-not $Values.ContainsKey($Field))) { return $false }
        Add-VarintSM $Out ([long]($Field -shl 3))
        Add-VarintSM $Out $max
        return $true
    }
    if ($Values.ContainsKey($Field)) {
        Add-VarintSM $Out ([long]($Field -shl 3))
        Add-VarintSM $Out ([long]$Values[$Field])
        return $true
    }
    return $false
}

# 递归改写：Level 0 = 整表（行 = field 2）、Level 1 = 行（RandomBase = field 5）、
#          Level 2 = RandomBase（1:=2、3:=4）
function Convert-StaticMaxMessage {
    param([byte[]]$Data, [int]$Level)
    $out = New-Object 'System.Collections.Generic.List[byte]'
    $spans = Get-SmSpans $Data 0 $Data.Length

    if ($Level -eq 2) {
        $vals = Read-SmRandomBase $Data
        $seen = @{}
        foreach ($s in $spans) {
            if ($s.Field -ge 1 -and $s.Field -le 4) { continue }   # 目标字段统一按字段号升序重写
            # 写非目标字段之前，先把字段号更小、还没写出的目标字段补齐（保持升序）
            foreach ($t in 1, 2, 3, 4) {
                if ($t -lt $s.Field -and -not $seen.ContainsKey($t)) {
                    [void](Add-SmMaxField $out $t $vals)
                    $seen[$t] = $true
                }
            }
            for ([int]$k = $s.Start; $k -lt $s.End; $k++) { $out.Add($Data[$k]) }
        }
        foreach ($t in 1, 2, 3, 4) {
            if (-not $seen.ContainsKey($t)) { [void](Add-SmMaxField $out $t $vals) }
        }
    }
    else {
        [int]$nestedField = if ($Level -eq 0) { $SCRIPT:SM_ROW_FIELD } else { $SCRIPT:SM_RB_FIELD }
        foreach ($s in $spans) {
            if ($s.Field -eq $nestedField -and $s.WireType -eq 2) {
                [int]$p = $s.VStart
                [long]$ln = Read-VarintSM $Data ([ref]$p)
                $body = New-Object byte[] $ln
                [Array]::Copy($Data, $p, $body, 0, [int]$ln)
                $patched = Convert-StaticMaxMessage $body ($Level + 1)
                Add-VarintSM $out ([long](($nestedField -shl 3) -bor 2))
                Add-VarintSM $out ([long]$patched.Length)
                $out.AddRange([byte[]]$patched)
            }
            else {
                for ([int]$k = $s.Start; $k -lt $s.End; $k++) { $out.Add($Data[$k]) }
            }
        }
    }
    return , $out.ToArray()
}

# 状态：
#   'original' 所有非零区间都还没满值（min < max）
#   'patched'  所有非零区间都已满值（min == max）
#   'mixed'    一部分满值
#   'unknown'  解析不了（不是这张表 / 结构异常）
# ★ 判据只看**非零区间**：每行第 1 档是全 0 占位（min==max==0 恒成立），
#   把它算进来会让原版表被判成 mixed。
function Get-StaticMaxState {
    param([byte[]]$Data)
    [int]$total = 0
    [int]$full = 0
    try {
        if ((Get-SmRowCount $Data) -eq 0) { throw '表里没有行数据' }
        foreach ($row in (Get-SmRows $Data)) {
            foreach ($m in (Get-SmRandomBases $row)) {
                $v = Read-SmRandomBase $m
                [long]$mn = 0; [long]$mx = 0; [long]$en = 0; [long]$ex = 0
                if ($v.ContainsKey(1)) { $mn = [long]$v[1] }
                if ($v.ContainsKey(2)) { $mx = [long]$v[2] }
                if ($v.ContainsKey(3)) { $en = [long]$v[3] }
                if ($v.ContainsKey(4)) { $ex = [long]$v[4] }
                if (($mn -bor $mx -bor $en -bor $ex) -eq 0) { continue }   # 全 0 占位档
                $total = $total + 1
                if ($mn -eq $mx -and $en -eq $ex) { $full = $full + 1 }
            }
        }
    }
    catch {
        return @{ State = 'unknown'; Total = 0; Full = 0; Note = $_.Exception.Message }
    }
    if ($total -eq 0) { return @{ State = 'unknown'; Total = 0; Full = 0; Note = '没有任何非零区间' } }
    if ($full -eq 0) { return @{ State = 'original'; Total = $total; Full = $full; Note = '' } }
    if ($full -eq $total) { return @{ State = 'patched'; Total = $total; Full = $full; Note = '' } }
    return @{ State = 'mixed'; Total = $total; Full = $full; Note = '部分区间已满值' }
}

# 执行改写：返回 @{ Bytes = <新字节>; Changed = <改了几个区间>; Total = <非零区间总数> }
function Apply-StaticMax {
    param([byte[]]$Data)
    $rowsBefore = Get-SmRowCount $Data
    if ($rowsBefore -eq 0) { throw '空表或不支持的表，已放弃' }

    $stBefore = Get-StaticMaxState $Data
    if ($stBefore.State -eq 'unknown') { throw ('表结构不认识（' + $stBefore.Note + '），已放弃') }

    $patched = Convert-StaticMaxMessage $Data 0

    # 自校验 ①：行数不变
    if ((Get-SmRowCount $patched) -ne $rowsBefore) { throw '自校验失败：补丁后行数变了，已放弃写入' }
    # 自校验 ②：重新解析一遍，所有非零区间都必须 min==max
    $stAfter = Get-StaticMaxState $patched
    if ($stAfter.State -ne 'patched') {
        throw ('自校验失败：仍有 {0}/{1} 个区间不是满值，已放弃写入' -f ($stAfter.Total - $stAfter.Full), $stAfter.Total)
    }
    # 自校验 ③：幂等 —— 再算一遍必须逐字节相同
    $again = Convert-StaticMaxMessage $patched 0
    [bool]$eq = ($again.Length -eq $patched.Length)
    if ($eq) {
        for ([int]$k = 0; $k -lt $patched.Length; $k++) {
            if ($again[$k] -ne $patched[$k]) { $eq = $false; break }
        }
    }
    if (-not $eq) { throw '自校验失败：补丁不幂等，已放弃写入' }

    return @{ Bytes = $patched; Changed = ($stAfter.Total - $stBefore.Full); Total = $stAfter.Total }
}

# ---------------------------------------------------------------- 命令行入口
#   ★ 被 install.ps1 dot-source 时务必显式传 -Path ''，否则会从调用方同名变量取值。
if ($Path -ne '') {
    if (-not (Test-Path -LiteralPath $Path)) { throw ("找不到文件: {0}" -f $Path) }
    if (-not ([IO.Path]::GetFileName($Path).StartsWith('ItemBaseStatic.bytes'))) {
        throw '输入必须是 ItemBaseStatic.bytes（装备基础属性表）'
    }
    $data = [System.IO.File]::ReadAllBytes((Resolve-Path -LiteralPath $Path).Path)
    $st = Get-StaticMaxState $data

    if (-not $Quiet) {
        Write-Host ("文件      : {0}" -f $Path)
        Write-Host ("大小      : {0} 字节" -f $data.Length)
        Write-Host ("行数      : {0}" -f (Get-SmRowCount $data))
        Write-Host ("状态      : {0}（已满值 {1}/{2} 个区间）" -f $st.State, $st.Full, $st.Total)
    }
    if ($st.State -eq 'unknown') { throw ('表结构不认识（' + $st.Note + '），已放弃') }

    if ($CountOnly) {
        Write-Output ("COUNT={0}" -f $st.Total)
        exit 0
    }
    if ($st.State -eq 'patched') {
        if (-not $Quiet) { Write-Host '已经是满值状态，无需修改。' }
        Write-Output 'CHANGED=0'
        exit 0
    }

    $res = Apply-StaticMax $data
    $target = if ($Output -ne '') { $Output } else { $Path + '.max-test' }
    [System.IO.File]::WriteAllBytes([IO.Path]::GetFullPath($target), $res.Bytes)
    if (-not $Quiet) {
        Write-Host ("已把 {0} 个属性区间改为取上限（共 {1} 个非零区间）" -f $res.Changed, $res.Total)
        Write-Host ("大小      : {0} -> {1}" -f $data.Length, $res.Bytes.Length)
        Write-Host ("写入      : {0}" -f $target)
    }
    Write-Output ("CHANGED={0}" -f $res.Changed)
    exit 0
}
