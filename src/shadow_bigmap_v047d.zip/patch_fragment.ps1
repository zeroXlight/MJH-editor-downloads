﻿. (Join-Path $PSScriptRoot 'patch_fragment_items.ps1')
# Random martial fragments: validated table pool, reversible native selector.
function Read-FragmentVar([byte[]]$B,[ref]$P,[int]$End) {
    [long]$v=0;$s=0
    do {
        if($P.Value -ge $End -or $s -gt 63) {throw 'Invalid fragment protobuf varint'}
        $x=[int]$B[$P.Value];$P.Value++;$v=$v -bor ([long]($x -band 127) -shl $s);$s+=7
    } while($x -band 128)
    return $v
}
function Read-FragmentFields([byte[]]$B,[int]$Start,[int]$End) {
    $p=$Start;$result=New-Object 'System.Collections.Generic.List[object]'
    while($p -lt $End) {
        $key=Read-FragmentVar $B ([ref]$p) $End;$f=[int]($key -shr 3);$w=[int]($key -band 7)
        if($f -eq 0) {throw 'Invalid protobuf field'}
        $v=$null;$startValue=$p
        switch($w) {
            0 {$v=Read-FragmentVar $B ([ref]$p) $End}
            1 {$p+=8}
            2 {$len=Read-FragmentVar $B ([ref]$p) $End;$startValue=$p;$p+=[int]$len}
            5 {$p+=4}
            default {throw 'Unsupported protobuf wire type'}
        }
        if($p -gt $End) {throw 'Protobuf record crosses boundary'}
        $result.Add(@{F=$f;W=$w;V=$v;Start=$startValue;End=$p})
    }
    return ,$result
}
function Get-FragmentRows([string]$Path,[int]$FeatureField=0) {
    [byte[]]$b=[IO.File]::ReadAllBytes($Path);$rows=@{}
    foreach($f in (Read-FragmentFields $b 0 $b.Length)) {
        if($f.F -ne 2 -or $f.W -ne 2) {continue}
        $d=@{};$flags=0
        foreach($v in (Read-FragmentFields $b $f.Start $f.End)) {
            if($v.W -eq 0) {
                if($v.F -eq $FeatureField) {$flags=$flags -bor $v.V}
                $d[$v.F]=$v.V
            } elseif($v.F -eq $FeatureField -and $v.W -eq 2) {
                $p=$v.Start
                while($p -lt $v.End) {$flags=$flags -bor (Read-FragmentVar $b ([ref]$p) $v.End)}
            }
        }
        if(-not $d.ContainsKey(1) -or $rows.ContainsKey($d[1])) {throw 'Invalid/duplicate table BaseID'}
        $d['Feature']=$flags;$rows[$d[1]]=$d
    }
    if($rows.Count -eq 0) {throw 'Empty fragment source table'}
    return $rows
}
# Share one parse of Martial/Item between fragment pool and martial cap.
$script:MartialPreparseDir = $PSScriptRoot
if(-not (Get-Variable -Name FragmentSourceCache -Scope Script -ErrorAction SilentlyContinue)) {$script:FragmentSourceCache = $null}
if(-not (Get-Variable -Name SkipMartialPreparse -Scope Script -ErrorAction SilentlyContinue)) {$script:SkipMartialPreparse = $false}
function Get-MartialSourceKey([string]$TableDir) {
    return ((Get-FileHash -LiteralPath (Join-Path $TableDir 'Martial.bytes') -Algorithm SHA256).Hash + ':' +
        (Get-FileHash -LiteralPath (Join-Path $TableDir 'Item.bytes') -Algorithm SHA256).Hash)
}
function Get-MartialRuleKey {
    $hashes = foreach ($name in @('patch_fragment.ps1','patch_uncollectible_cap.ps1','fragment_extra_items.json')) {
        (Get-FileHash -LiteralPath (Join-Path $script:MartialPreparseDir $name) -Algorithm SHA256).Hash
    }
    return ($hashes -join ':')
}
function Get-PreparsedMartialResult([string]$TableDir,[string]$Kind) {
    if ($script:SkipMartialPreparse) { return $null }
    $path = Join-Path $script:MartialPreparseDir 'martial_preparsed.json'
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    # Missing, obsolete or malformed cache always falls back to actual table parsing.
    try {
        $cache = [IO.File]::ReadAllText($path,[Text.Encoding]::UTF8) | ConvertFrom-Json
        if ($cache.Schema -ne 1 -or $cache.Rules -ne (Get-MartialRuleKey)) { return $null }
        $key = Get-MartialSourceKey $TableDir
        foreach ($entry in $cache.Entries) {
            if ($entry.Key -ne $key) { continue }
            $value = $entry.$Kind
            [byte[]]$bytes = [Convert]::FromBase64String($value.Data)
            $sha = [Security.Cryptography.SHA256]::Create()
            try { $hash = [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-','') } finally { $sha.Dispose() }
            $stride = if ($Kind -eq 'Pool') { 8 } else { 4 }
            $max = if ($Kind -eq 'Pool') { 768*8 } else { 1536*4 }
            if ($hash -ne $value.SHA256 -or $bytes.Length -eq 0 -or $bytes.Length % $stride -or $bytes.Length -gt $max) { return $null }
            return ,$bytes
        }
    } catch { return $null }
    return $null
}
function Get-FragmentSourceTables([string]$TableDir) {
    $key = Get-MartialSourceKey $TableDir
    if ($null -eq $script:FragmentSourceCache -or $script:FragmentSourceCache.Key -ne $key) {
        $script:FragmentSourceCache = @{
            Key = $key
            Martials = Get-FragmentRows (Join-Path $TableDir 'Martial.bytes')
            Items = Get-FragmentRows (Join-Path $TableDir 'Item.bytes') 16
        }
    }
    return $script:FragmentSourceCache
}
function Get-FragmentPool([string]$TableDir) {
    $preparsed = Get-PreparsedMartialResult $TableDir Pool
    if ($null -ne $preparsed) { return ,$preparsed }
    $tables=Get-FragmentSourceTables $TableDir
    $martials=$tables.Martials
    $items=$tables.Items
    $extra=@{};foreach($r in (Get-FragmentExtras)) {$extra[[long]$r.MartialID]=[long]$r.ItemID}
    $pool=New-Object 'System.Collections.Generic.List[byte]'
    foreach($id in ($items.Keys | Sort-Object)) {
        $it=$items[$id]
        if($it[10] -ne 16 -or (($it['Feature'] -band 16) -and $it[36] -notin @(12234,13016)) -or -not $it.ContainsKey(36) -or -not $martials.ContainsKey($it[36])) {continue}
        $m=$martials[$it[36]]
        # Missing protobuf integers mean zero. Drop=0, Display=1, AlowEdit=1.
        if(-not ($extra.ContainsKey([long]$it[36]) -and $extra[[long]$it[36]] -eq $id) -and (($m.ContainsKey(8) -and $m[8] -ne 0 -and $it[36] -notin @(12234,13016)) -or $m[18] -ne 1 -or $m[24] -ne 1)) {continue}
        $pool.AddRange([BitConverter]::GetBytes([uint32]$id))
        $pool.AddRange([BitConverter]::GetBytes([uint32]$it[36]))
    }
    if($pool.Count -eq 0 -or $pool.Count -gt 768*8) {throw 'Invalid fragment pool size'}
    return ,$pool.ToArray()
}
function Update-Fragment([byte[]]$Data,$Switches,[string]$CodePath,[byte[]]$Pool=@()) {
    $resourceDir=Split-Path $CodePath -Parent
    . (Join-Path $resourceDir 'game_build.ps1')
    if((Get-ShadowGameBuild $Data).Family -eq 'classic') {
        $enabled=[bool]$Switches['optimize.fragment']
        [byte[]]$payload=@()
        if($enabled) {
            if($Pool.Length -eq 0 -or $Pool.Length%8 -or $Pool.Length -gt 768*8) {throw 'Invalid classic fragment pool'}
            $ids=@{}
            for($i=0;$i -lt $Pool.Length;$i+=8) {
                $id=[BitConverter]::ToUInt32($Pool,$i);$mid=[BitConverter]::ToUInt32($Pool,$i+4)
                if($id -eq 0 -or $mid -eq 0 -or $ids.ContainsKey($id)) {throw 'Invalid/duplicate fragment pool ID'}
                $ids[$id]=$true
            }
            $payload=New-Object byte[] (0x200+$Pool.Length)
            [BitConverter]::GetBytes([uint32]10).CopyTo($payload,0)
            [BitConverter]::GetBytes([uint32]($Pool.Length/8)).CopyTo($payload,4)
            $Pool.CopyTo($payload,0x200)
        }
        . (Join-Path $resourceDir 'patch_classic_section.ps1')
        return ,(Update-ClassicSection $Data $enabled (Get-ShadowNativeLayoutPath $Data $resourceDir 'fragment_layout.json') $payload)
    }
    [byte[]]$b=$Data.Clone()
    function FH([int]$O,[int]$N) {[BitConverter]::ToString($b,$O,$N).Replace('-','')}
    function FP([int]$O,[uint32]$V) {[BitConverter]::GetBytes($V).CopyTo($b,$O)}
    $hex=([IO.File]::ReadAllText($CodePath)).Trim()
    if($hex -notmatch '^[0-9A-F]+$' -or $hex.Length%2) {throw 'Invalid fragment code'}
    [byte[]]$code=New-Object byte[] ($hex.Length/2)
    for($i=0;$i -lt $code.Length;$i++) {$code[$i]=[Convert]::ToByte($hex.Substring($i*2,2),16)}
    if($code.Length -ge 0x800) {throw 'Fragment code too large'}
    if($code.Length -gt 0x600 -and [BitConverter]::ToUInt64($code,0x600) -ne 0) {throw 'Fragment code overlaps config'}
    $pe=[BitConverter]::ToInt32($b,0x3c);$opt=$pe+24
    if($pe -ne 0x100 -or (FH $pe 6) -ne '504500006486') {throw 'Unsupported fragment PE'}
    $table=$opt+[BitConverter]::ToUInt16($b,$pe+20)
    $count=[BitConverter]::ToUInt16($b,$pe+6);$last=$table+($count-1)*40
    $rva=0x1b41000;$hook=0x51e675;$orig='E8F6590000'
    [byte[]]$jump=0xe8,0,0,0,0
    [BitConverter]::GetBytes([int]($rva-0x51f275-5)).CopyTo($jump,1)
    $jumpHex=[BitConverter]::ToString($jump).Replace('-','')
    $npcHook=0x794c89;$npcOrig='E8C265D4FF';$hasNpcSync=$code.Length -gt 0x400
    [byte[]]$npcJump=0xe8,0,0,0,0
    [BitConverter]::GetBytes([int]($rva+0x400-0x795889-5)).CopyTo($npcJump,1)
    $npcJumpHex=[BitConverter]::ToString($npcJump).Replace('-','')
    $mergeHook=0x794b7b;$mergeOrig='E8B0FAE6FF'
    [byte[]]$mergeJump=0xe8,0,0,0,0
    [BitConverter]::GetBytes([int]($rva+0x300-0x79577b-5)).CopyTo($mergeJump,1)
    $mergeJumpHex=[BitConverter]::ToString($mergeJump).Replace('-','')
    $hasMergeSync=$code.Length -gt 0x400 -and $code[0x300] -ne 0
    $replayHook=0x49ae62;$replayOrig='E859E8FAFF';$hasReplay=$code.Length -gt 0x610
    [byte[]]$replayJump=0xe8,0,0,0,0
    [BitConverter]::GetBytes([int]($rva+0x610-0x49ba62-5)).CopyTo($replayJump,1)
    $replayJumpHex=[BitConverter]::ToString($replayJump).Replace('-','')
    $hasRoleSync=$code.Length -gt 0x610 -and $code[0x5f0] -eq 1
    $roleHooks=@(@(0x48737a,0x487f7a,'E8D13E0500',0x400),@(0x4873ff,0x487fff,'E84C3E0500',0x400),@(0x486db2,0x4879b2,'E879D81700',0x300))
    for($ri=0;$ri -lt $roleHooks.Count;$ri++) {
        $rh=$roleHooks[$ri]
        [byte[]]$rj=0xe8,0,0,0,0
        [BitConverter]::GetBytes([int]($rva+$rh[3]-$rh[1]-5)).CopyTo($rj,1)
        $roleHooks[$ri]=$rh+@([BitConverter]::ToString($rj).Replace('-',''))
    }
    $exists=(FH $last 8) -eq '2E64796672616700'
    # Guard every called native API against version drift.
    foreach($g in @(
        @(0x30a860,'48894C2408488B4424088B804C010000C3'),
        @(0x30a880,'48894C2408488B4424088B8050010000C3'),
        @(0x35ce20,'48894C2408488B4424088B8090010000C3'),
        @(0x35cdd0,'48894C2408488B4424088B80B0010000C3'),
        @(0x68ef80,'48894C2408488B4424088B8048010000C3')
    )) {if((FH ($g[0]-0xc00) ($g[1].Length/2)) -ne $g[1]) {throw 'Unsupported native fragment getter'}}
    $sha=[Security.Cryptography.SHA256]::Create()
    foreach($g in @(
        @(0x4c0b00,197,'B281ACBC4A30AD512C7DEA0E127863BAF942A0F3BD2196623F76A80696EC5E8C'),
        @(0xa4bd10,138,'C0822FEED80B6176E01029B0B83B7C82DC5702472F31A74B64098AF00287E9DE'),
        @(0x88af60,128,'592B4A9823AA669B64593875C13ADCBF310CCD38834AD4E8CE242558133A1CFC'),
        @(0x40fdd0,308,'85784A567DFC52216D573D4843F6EAFAF1B894E8E1EA5F9A44B816CA4BB93AE6'),
        @(0x527ca0,46,'9ECA376E7E4B1380827B17FC8450F355017FDD0D548E31EB6FA7881C4CB2E8CE'),
        @(0x631d30,356,'3931F919D091CA14F82419824B8952175BAA3915F9DDD6AAE334FE152C232ACF'),
        @(0x632ff0,88,'85927B018910520568ABF1DE1DA0DDD8ADE7DA4C5AC77C38BE2D77C13B474D8E'),
        @(0x2bea40,14,'FBE60D85C3B8E909F23B7734BFE8864F096C735FF18DB9A0A2C748B8A26E60BA'),
        @(0x524c70,58,'779863DC5864C2CA0BF004C67AE5BA03CBAD22B392146BCCC34436783F2BC313'),
        @(0x30b390,178,'5878218585EA5313D2B2AE7896E40207E9FD0AF4A7EF0BE88AC11923B6AF45F4')
        @(0x605230,80,'13D7E7F76894CEAA1B6BA4FBCBAAF30546263083287A61AE5D2408D4D45981EB'),
        @(0x4dbe50,928,'4A618C83953C0655FFAD6C4A6D50749591D7C5E697AEBE692EC2F383E42FD5DB'),
        @(0x437060,92,'321525885BCFED80008BD2D2E73302BFCE95BCE9AFC5137B49EAFAFCCFBCC48D'),
        @(0x4dbd90,144,'02E1BA0413E202607ABE5DCF762D0D96E24606D18B5975506771FF4FF830440F'),
        @(0x44d600,388,'59B45F4679A4A317DA53E24C6DCA6783C12761D8667840C819B11EEF898A575A'),
        @(0xeaea10,78,'24BA2F8E6F97E3F8DEC9771F775F11294B7DA43BA09EFABBB1BD3C079AC25B6E'),
        @(0x464ff0,167,'D2C88076BEE39BC1D1BD9AB9CD635CC6E0989FD7D0D195A13AD7B20A1D37A264'),
        @(0x44a2c0,975,'185C2F3F54E8FD9ADB48C0133BA1D24223C1D31A341402BAFC135A5620686522'),
        @(0x798970,202,'9AF602CC2CA34DA8475F28AE430A5395E6CF449CF9A31AF2F4E2EEEF476DFC1E')
    )) {
        $digest=[BitConverter]::ToString($sha.ComputeHash($b,($g[0]-0xc00),$g[1])).Replace('-','')
        if($digest -ne $g[2]) {throw ('Unsupported native fragment API: '+$g[0])}
    }
    $sha.Dispose()
    if($exists) {
        $sectionRaw=[BitConverter]::ToUInt32($b,$last+20)
        $sectionRva=[BitConverter]::ToUInt32($b,$last+12)
        $padding=$rva-$sectionRva;$span=0x2000+$padding
        # Accept the exact shipped layout as well as the contiguous fixed layout.
        if($sectionRva -notin @(0x1b40000,0x1b41000) -or ($count -eq 9 -and $padding -ne 0)) {throw 'Unknown fragment section RVA'}
        $raw=$sectionRaw+$padding
        if($count -notin @(8,9) -or $sectionRaw -ne (0x1ad2a00+($count-8)*0x1000) -or $b.Length -ne $sectionRaw+$span -or (FH $hook 5) -ne $jumpHex -or [BitConverter]::ToUInt32($b,$opt+56) -ne 0x1b43000) {throw 'Unknown installed fragment layout'}
        [byte[]]$header=New-Object byte[] 40
        [Text.Encoding]::ASCII.GetBytes('.dyfrag').CopyTo($header,0)
        foreach($v in @(@(8,$span),@(12,$sectionRva),@(16,$span),@(20,$sectionRaw),@(36,0x60000020))) {[BitConverter]::GetBytes([uint32]$v[1]).CopyTo($header,$v[0])}
        if((FH $last 40) -ne [BitConverter]::ToString($header).Replace('-','')) {throw 'Unknown fragment section header'}
        if($padding -gt 0 -and (FH $sectionRaw $padding) -ne ('00'*$padding)) {throw 'Unknown fragment alignment padding'}
        $rate=[BitConverter]::ToUInt32($b,$raw+0x600);$n=[BitConverter]::ToUInt32($b,$raw+0x604)
        if($rate -gt 100 -or $n -eq 0 -or $n -gt 768) {throw 'Invalid installed fragment config'}
        $oldIds=@{}
        for($i=0;$i -lt $n;$i++) {
            $id=[BitConverter]::ToUInt32($b,$raw+0x800+$i*8);$mid=[BitConverter]::ToUInt32($b,$raw+0x804+$i*8)
            if($id -eq 0 -or $mid -eq 0 -or $oldIds.ContainsKey($id)) {throw 'Invalid installed fragment pool ID'}
            $oldIds[$id]=$true
        }
        [byte[]]$expected=New-Object byte[] 0x2000;$code.CopyTo($expected,0)
        # Upgrade only the exact previously shipped 652-byte selector.
        $legacySha=[Security.Cryptography.SHA256]::Create()
        $legacyHash=[BitConverter]::ToString($legacySha.ComputeHash($b,$raw,652)).Replace('-','')
        $sameRankHash=[BitConverter]::ToString($legacySha.ComputeHash($b,$raw,691)).Replace('-','')
        $npcLegacyHash=[BitConverter]::ToString($legacySha.ComputeHash($b,$raw,1305)).Replace('-','')
        [byte[]]$replayLegacyCode=New-Object byte[] 1930
        [Array]::Copy($b,$raw,$replayLegacyCode,0,1930);[Array]::Clear($replayLegacyCode,0x600,8)
        $replayLegacyHash=[BitConverter]::ToString($legacySha.ComputeHash($replayLegacyCode)).Replace('-','')
        $legacySha.Dispose()
        $legacyLength=0
        if($legacyHash -eq 'E02E32574A919BFCD77061503AF5FD241A1F9EABA19652C4A8B020A72B2F12F1') {
            $legacyLength=652
        } elseif($sameRankHash -eq '49B46F811B040FB0A27DA0BAC3B4A99C199D8A6CF990B50DBC5713D43C4A4523' -and (FH $npcHook 5) -eq $npcOrig) {
            $legacyLength=691
        }
        $oldMergedSync=$npcLegacyHash -eq '46C6746DEF42725BB7036785DFDD5A98016E842B0658BF2374E42606566F9DCE' -and (FH $mergeHook 5) -eq $mergeJumpHex -and (FH $replayHook 5) -eq $replayOrig
        $oldNpcSync=($npcLegacyHash -eq 'AF8CFBA36BD1D6DA0CB7CD1B6D4A3893CE8D79F5A48E28AA4CF6DC8B7E793E2F' -and (FH $mergeHook 5) -eq $mergeOrig) -or $oldMergedSync
        if($oldNpcSync) {$legacyLength=1305}
        $oldReplay=$replayLegacyHash -eq '27A26D5DEA3B9B78D0C11C1929C5D894A6CC250328DE58F39288890E5A93D32C'
        $oldRoleSync=$replayLegacyHash -eq 'DC407BFB061EA754F06F091BD978DC42C477F5D37ECC6A73F0B7363D53E55825'
        if($oldReplay -or $oldRoleSync) {$legacyLength=1930}
        if($legacyLength -gt 0) {
            [Array]::Clear($expected,0,0x800)
            [Array]::Copy($b,$raw,$expected,0,$legacyLength)
        }
        $expectedNpcHook=if(($legacyLength -gt 0 -and -not $oldNpcSync -and -not $oldReplay -and -not $oldRoleSync) -or -not $hasNpcSync) {$npcOrig} else {$npcJumpHex}
        $expectedMergeHook=if(($hasMergeSync -and $legacyLength -eq 0) -or $oldMergedSync -or $oldReplay -or $oldRoleSync) {$mergeJumpHex} else {$mergeOrig}
        $expectedReplayHook=if(($hasReplay -and $legacyLength -eq 0) -or $oldReplay -or $oldRoleSync) {$replayJumpHex} else {$replayOrig}
        foreach($rh in $roleHooks) {
            $expectedRole=if(($hasRoleSync -and $legacyLength -eq 0) -or $oldRoleSync) {$rh[4]} else {$rh[2]}
            if((FH $rh[0] 5) -ne $expectedRole) {throw 'Unexpected instantiated role fragment hook'}
        }
        if((FH $replayHook 5) -ne $expectedReplayHook) {throw 'Unexpected NPC fragment replay hook'}
        if((FH $mergeHook 5) -ne $expectedMergeHook) {throw 'Unexpected NPC fragment merge hook'}
        if((FH $npcHook 5) -ne $expectedNpcHook) {throw 'Unexpected NPC fragment notification hook'}
        [Array]::Copy($b,$raw+0x600,$expected,0x600,8)
        [Array]::Copy($b,$raw+0x800,$expected,0x800,$n*8)
        if((FH $raw 0x2000) -ne [BitConverter]::ToString($expected).Replace('-','')) {throw 'Unexpected fragment section bytes'}
        [Array]::Clear($b,$last,40);$count--
        [BitConverter]::GetBytes([uint16]$count).CopyTo($b,$pe+6)
        FP ($opt+56) (0x1b40000+($count-7)*0x1000)
        [byte[]]$original=0xe8,0xf6,0x59,0,0;$original.CopyTo($b,$hook)
        [byte[]]$npcOriginal=0xe8,0xc2,0x65,0xd4,0xff;$npcOriginal.CopyTo($b,$npcHook)
        [byte[]]$mergeOriginal=0xe8,0xb0,0xfa,0xe6,0xff;$mergeOriginal.CopyTo($b,$mergeHook)
        [byte[]]$replayOriginal=0xe8,0x59,0xe8,0xfa,0xff;$replayOriginal.CopyTo($b,$replayHook)
        foreach($rh in $roleHooks) {(Convert-FragmentExtraHex $rh[2]).CopyTo($b,$rh[0])}
        [Array]::Resize([ref]$b,[int]$sectionRaw)
    }
    $raw=0x1ad2a00+($count-7)*0x1000;$section=$table+$count*40
    if($count -notin @(7,8) -or ($count -eq 8 -and (FH ($table+7*40) 8) -ne '2E64796F75740000') -or $b.Length -ne $raw -or (FH $section 40) -ne ('00'*40) -or (FH $hook 5) -ne $orig -or [BitConverter]::ToUInt32($b,$opt+56) -ne (0x1b40000+($count-7)*0x1000)) {throw 'Unsupported parent layout for fragment patch'}
    if(-not $Switches['optimize.fragment']) {return ,$b}
    if((FH $mergeHook 5) -ne $mergeOrig) {throw 'Unsupported NPC fragment merge call'}
    if((FH $replayHook 5) -ne $replayOrig) {throw 'Unsupported NPC fragment replay call'}
    foreach($rh in $roleHooks) {if((FH $rh[0] 5) -ne $rh[2]) {throw 'Unsupported instantiated role fragment call'}}
    if((FH $npcHook 5) -ne $npcOrig) {throw 'Unsupported NPC fragment notification call'}
    $rate=10 # Built-in probability; legacy rate overrides are ignored.
    if($Pool.Length -eq 0 -or $Pool.Length%8 -or $Pool.Length -gt 768*8) {throw 'Invalid fragment settings/pool'}
    $ids=@{}
    for($i=0;$i -lt $Pool.Length;$i+=8) {
        $id=[BitConverter]::ToUInt32($Pool,$i);$mid=[BitConverter]::ToUInt32($Pool,$i+4)
        if($id -eq 0 -or $mid -eq 0 -or $ids.ContainsKey($id)) {throw 'Invalid/duplicate fragment pool ID'}
        $ids[$id]=$true
    }
    # Windows requires contiguous section RVAs. Without .dyout, include a zero
    # page before the fixed code RVA instead of leaving an unmapped section gap.
    $sectionRva=0x1b40000+($count-7)*0x1000
    $sectionRaw=$raw;$padding=$rva-$sectionRva;$span=0x2000+$padding
    [byte[]]$new=New-Object byte[] ($sectionRaw+$span);$b.CopyTo($new,0);$b=$new
    [Text.Encoding]::ASCII.GetBytes('.dyfrag').CopyTo($b,$section)
    FP ($section+8) $span;FP ($section+12) $sectionRva;FP ($section+16) $span;FP ($section+20) $sectionRaw;FP ($section+36) 0x60000020
    [BitConverter]::GetBytes([uint16]($count+1)).CopyTo($b,$pe+6);FP ($opt+56) 0x1b43000
    $raw=$sectionRaw+$padding
    $code.CopyTo($b,$raw);FP ($raw+0x600) $rate;FP ($raw+0x604) ($Pool.Length/8)
    $Pool.CopyTo($b,$raw+0x800);$jump.CopyTo($b,$hook)
    if($hasNpcSync) {$npcJump.CopyTo($b,$npcHook)}
    if($hasMergeSync) {$mergeJump.CopyTo($b,$mergeHook)}
    if($hasReplay) {$replayJump.CopyTo($b,$replayHook)}
    if($hasRoleSync) {foreach($rh in $roleHooks) {(Convert-FragmentExtraHex $rh[4]).CopyTo($b,$rh[0])}}
    return ,$b
}
