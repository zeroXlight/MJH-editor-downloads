﻿# =====================================================================
#  梦江湖 MOD · 「玉鸣子的考验」分支奖励修复补丁器（零依赖，仅用 Windows 自带 PowerShell）
#
#  修的是什么
#  ---------------------------------------------------------------
#  铸剑山庄任务「玉鸣子的考验」(Task 5558) 完成后，按玩家在剧情里的选择
#  会走三条分支之一。这个游戏里同类任务的规矩是：
#      · 铜币 / 经验 = 默认奖励，走哪条分支都有（Task 5558 的 TaskNormalRewards）
#      · 天书残卷   = 只有**选对那条路线**才额外给
#  5558 的额外奖励本该是《列子诸考·空》(801080)，但额外奖励栏是空的。
#
#  根因（已逐字节验证）
#  ---------------------------------------------------------------
#  调用链：Task 5558  TaskBranchRewards = {555801, 555802, 555803}
#            -> TaskReward 555801  RewardArg1 = "5558491"
#            -> TaskReward 555802  RewardArg1 = "5558492"
#            -> TaskReward 555803  RewardArg1 = "5558493"   ★ 只有这条是"选对路线"
#  RewardArg1 是 Drop 表的条目号。Drop 表里查无 5558491 / 5558492 / 5558493
#  ⇒ 掉落为空 ⇒ 奖励栏为空。
#
#  "选对的是哪一条"—— 不猜，看原版自己留下的证据
#  ---------------------------------------------------------------
#  五本残卷是同一套模板做出来的，每个任务段里**只有"选对那条"的 drop 条目
#  真实存在**（编号末位 = 分支序号）：
#        材 5551 段 -> 分支5  Drop 5551005 = 801076《列子诸考·材》
#        仁 5552 段 -> 分支2  Drop 5552002 = 801077《列子诸考·仁》
#        智 5556 段 -> 分支2  Drop 5556002 = 801078《列子诸考·智》
#        忠 5559 段 -> 分支2  Drop 5559002 = 801079《列子诸考·忠》
#        空 5558 段 -> 分支3  Drop 5558003 = 801080《列子诸考·空》 ★ 本次要修的
#  同一段里"没选对"的分支本来就没有 drop 条目（例：5552 段分支1 给的是
#  优秀武学丹 Drop 5552001；5558 段分支1 / 分支2 压根没配任何东西）。
#  5558 段唯一真实存在的 drop 就是 5558003，它属于分支3。
#  ⇒ 只把 5558493 改回 5558003。
#  ⇒ 分支1 / 分支2 **保持原版不动**：原版就没给，本 MOD 不替官方补发 ——
#     MOD 是游戏的一环，乱发奖励跟开挂没区别。
#
#  修法
#  ---------------------------------------------------------------
#  只改一处：TaskReward 555803 的 RewardArg1  "5558493" -> "5558003"
#  两个值都是 7 字节 ASCII —— 文件长度、行内所有偏移完全不变，做的是
#  "原位字节覆盖"，不是重新编码，碰不到任何别的数据。
#
#  安全前提（写盘前的自校验，任何一条不符就拒绝写入）
#  ---------------------------------------------------------------
#    · 5558491 / 5558492 / 5558493 在文件里必须各只出现 1 次
#      （出现多次 = 表结构变了，不猜）
#    · 5558491 / 5558492 必须**原封不动** —— 它们是"另外两条分支没被乱改"的锚点
#    · 替换后文件长度不变
#    · 替换后 5558493 消失、5558003 正好出现 1 次
#    · 逐字节核对：所有变动都必须落在这 7 个字节里
#  幂等：已经是新值就直接返回，不写盘。
#
#  关于旧版（v0.27 测试包）
#  ---------------------------------------------------------------
#  旧版把三条分支都改成了 5558003。现在认定那是错的，会识别出这种状态
#  （5558491/2/3 全没了、5558003 出现 3 次）并返回 legacy —— 不动手瞎改，
#  由安装器先用原版备份还原，再按新方案打。
#
#  可被 dot-source 复用（install.ps1 就是这么用的），也可单独命令行运行：
#     patch_taskreward.ps1 -Path <文件>
#     patch_taskreward.ps1 -Path <文件> -CountOnly
# =====================================================================
param(
    [string]$Path = '',
    [switch]$CountOnly,
    [switch]$Quiet
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ---- 只修分支3：原版唯一配了《列子诸考·空》的那条（证据见文件头）----
$SCRIPT:YMZ_BAD    = '5558493'                   # 原版写在 TaskReward 555803 里的坏值
$SCRIPT:YMZ_GOOD   = '5558003'                   # Drop 表里真实存在的那条 = 801080
$SCRIPT:YMZ_ANCHOR = @('5558491', '5558492')     # 分支1 / 分支2：必须保持原样
$SCRIPT:YMZ_EXPECT = 1                           # 改完之后新值应出现的次数

# ------------------------------------------------------------------ 原语
# 说明：TaskReward.bytes 只有 ~0.1MB，且这些模式串都是纯 ASCII 数字。
# 用 ASCII 解码成字符串再 IndexOf 定位 —— 非 ASCII 字节会被解成 '?'，
# 不可能凑出纯数字模式串，所以索引与字节偏移严格一一对应，不会误命中。
function Find-YmzAll {
    param([string]$Text, [string]$Pat)
    $out = New-Object System.Collections.Generic.List[int]
    if ($Pat -eq '') { return $out }
    [int]$i = $Text.IndexOf($Pat, [System.StringComparison]::Ordinal)
    while ($i -ge 0) {
        $out.Add($i)
        $i = $Text.IndexOf($Pat, $i + 1, [System.StringComparison]::Ordinal)
    }
    return $out
}

# ------------------------------------------------------------------ 状态
function Get-YmzState {
    # 返回 @{ State; BadCount; BadOffsets; GoodCount; AnchorCounts; Length }
    # State: missing 这些编号一个都找不到（多半不是这张表）
    #        orig    原版（分支3 指向坏值，分支1/2 保持原样）
    #        fixed   已修复（分支3 = 5558003，分支1/2 保持原样）
    #        legacy  旧版 v0.27 的补丁：三条分支全被改成 5558003（需先还原）
    #        unknown 出现次数与预期不符（表结构变了 / 别的 MOD 改过）
    param([byte[]]$Data)

    [string]$text = [System.Text.Encoding]::ASCII.GetString($Data)

    # ★ 必须用 @(...) 包住：函数返回 List 时会被管道展开成单个元素/空，
    #   在 StrictMode 2.0 下取 .Count 会直接报错。
    $badHits  = @(Find-YmzAll $text $SCRIPT:YMZ_BAD)
    $goodHits = @(Find-YmzAll $text $SCRIPT:YMZ_GOOD)

    $anchorCounts = New-Object System.Collections.Generic.List[int]
    foreach ($a in $SCRIPT:YMZ_ANCHOR) {
        $anchorCounts.Add(@(Find-YmzAll $text $a).Count)
    }

    $st = @{
        State        = 'unknown'
        BadCount     = $badHits.Count
        BadOffsets   = $badHits
        GoodCount    = $goodHits.Count
        AnchorCounts = $anchorCounts
        Length       = $Data.Length
    }

    # 目标值/坏值出现多次 = 表结构变了，不猜
    if ($badHits.Count -gt 1)  { $st.State = 'unknown'; return $st }
    if ($goodHits.Count -gt $SCRIPT:YMZ_EXPECT) {
        # 唯一允许的"多"：旧版把三条都改了
        if ($badHits.Count -eq 0 -and $goodHits.Count -eq 3) { $st.State = 'legacy' }
        else { $st.State = 'unknown' }
        return $st
    }

    # 两个锚点必须各出现 1 次，否则说明另外两条分支被谁动过
    [bool]$anchorsOk = $true
    foreach ($c in $anchorCounts) { if ($c -ne 1) { $anchorsOk = $false } }
    if (-not $anchorsOk) { $st.State = 'unknown'; return $st }

    if ($badHits.Count -eq 1 -and $goodHits.Count -eq 0) { $st.State = 'orig' }
    elseif ($badHits.Count -eq 0 -and $goodHits.Count -eq $SCRIPT:YMZ_EXPECT) { $st.State = 'fixed' }
    elseif ($badHits.Count -eq 0 -and $goodHits.Count -eq 0) { $st.State = 'missing' }
    else { $st.State = 'unknown' }

    return $st
}

function Get-YmzStateText {
    param([string]$State)
    switch ($State) {
        'missing'  { return '表里找不到这些编号（可能不是这张表）' }
        'orig'     { return '原版（分支3 的奖励是空的）' }
        'fixed'    { return '已修复' }
        'legacy'   { return '装过旧版补丁（三条分支都被改成了 5558003），需先用原版备份还原' }
        default    { return '出现次数与预期不符' }
    }
}

# ------------------------------------------------------------------ 打补丁
function Repair-YumingziReward {
    # 返回 @{ Bytes = <新字节>; Fixed = 改了几处; State = <补丁前的状态> }
    param([byte[]]$Data)

    $st = Get-YmzState $Data
    if ($st.State -eq 'missing') {
        throw 'TaskReward 表里找不到这些分支奖励编号，已放弃写入（游戏版本可能不同）'
    }
    if ($st.State -eq 'unknown') {
        throw 'TaskReward 表里这些编号的出现次数与预期不符，已放弃写入（不猜、不盲改）'
    }
    if ($st.State -eq 'legacy') {
        throw '检测到旧版补丁（三条分支全被改成 5558003），已放弃写入：请先卸载还原成原版再安装'
    }
    if ($st.State -eq 'fixed') {
        return @{ Bytes = $Data; Fixed = 0; State = 'fixed' }
    }

    $out = New-Object byte[] $Data.Length
    [System.Array]::Copy($Data, $out, $Data.Length)

    $patch = [System.Text.Encoding]::ASCII.GetBytes($SCRIPT:YMZ_GOOD)
    $hits = $st.BadOffsets
    if ($hits.Count -ne 1) {
        throw ('自校验失败：''{0}'' 出现 {1} 次，已放弃写入' -f $SCRIPT:YMZ_BAD, $hits.Count)
    }
    [int]$off = [int]$hits[0]
    if ($off + $patch.Length -gt $out.Length) {
        throw '自校验失败：替换位置越过文件末尾，已放弃写入'
    }
    [System.Array]::Copy($patch, 0, $out, $off, $patch.Length)
    [int]$nFixed = 1

    # ---- 自校验 ----
    #  ① 长度不变
    #  ② 坏值消失、新值正好出现 1 次
    #  ③ 两个锚点（分支1 / 分支2）原封不动
    #  ④ 逐字节核对：所有变动都必须落在这一处 7 字节区间内
    if ($out.Length -ne $Data.Length) { throw '自校验失败：文件长度发生变化，已放弃写入' }

    $after = Get-YmzState $out
    if ($after.State -ne 'fixed') {
        throw ('自校验失败：写入后状态为「' + (Get-YmzStateText $after.State) + '」，已放弃写入')
    }

    $diff = New-Object System.Collections.Generic.List[int]
    for ($i = 0; $i -lt $Data.Length; $i++) {
        if ($Data[$i] -ne $out[$i]) { $diff.Add($i) }
    }
    $allowed = New-Object 'System.Collections.Generic.HashSet[int]'
    for ($j = 0; $j -lt $patch.Length; $j++) { [void]$allowed.Add($off + $j) }
    foreach ($p in $diff) {
        if (-not $allowed.Contains($p)) {
            throw ('自校验失败：偏移 ' + $p + ' 处发生了预期之外的改动，已放弃写入')
        }
    }

    return @{ Bytes = $out; Fixed = $nFixed; State = $st.State }
}

# ---------------------------------------------------------------- 命令行入口
if ($Path -ne '') {
    if (-not (Test-Path -LiteralPath $Path)) { throw "找不到文件: $Path" }
    $data = [System.IO.File]::ReadAllBytes($Path)
    $st = Get-YmzState $data

    if (-not $Quiet) {
        Write-Host ("文件      : {0}" -f $Path)
        Write-Host ("大小      : {0} 字节" -f $data.Length)
        Write-Host ("目标      : TaskReward 555803 的 RewardArg1（第 3 条分支 = 选对路线）")
        Write-Host ("状态      : {0}" -f (Get-YmzStateText $st.State))
        Write-Host ("  坏值    : {0} 出现 {1} 次" -f $SCRIPT:YMZ_BAD, $st.BadCount)
        Write-Host ("  新值    : {0} 出现 {1} 次" -f $SCRIPT:YMZ_GOOD, $st.GoodCount)
        Write-Host ("  锚点    : {0} 出现 {1} / {2} 次（应各为 1 —— 另外两条分支不许动）" -f
            ($SCRIPT:YMZ_ANCHOR -join ', '), $st.AnchorCounts[0], $st.AnchorCounts[1])
    }

    if ($CountOnly) {
        $flag = if ($st.State -eq 'fixed') { 1 } else { 0 }
        Write-Output ("FIXED={0}" -f $flag)
        exit 0
    }

    if ($st.State -eq 'fixed') {
        if (-not $Quiet) { Write-Host '已经是修复后的状态，无需修改。' }
        Write-Output 'FIXED=0'
        exit 0
    }

    $res = Repair-YumingziReward $data
    [System.IO.File]::WriteAllBytes($Path, $res.Bytes)
    if (-not $Quiet) {
        Write-Host ("已修复：{0}  ->  {1}（{2} 处，只动第 3 条分支）" -f $SCRIPT:YMZ_BAD, $SCRIPT:YMZ_GOOD, $res.Fixed)
        Write-Host ("大小      : {0} 字节（不变）" -f $res.Bytes.Length)
        Write-Host ("写入      : {0}" -f $Path)
    }
    Write-Output ("FIXED={0}" -f $res.Fixed)
    exit 0
}
