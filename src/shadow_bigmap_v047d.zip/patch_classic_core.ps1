﻿# This module is verified independently. The installer keeps the classic build
# blocked until ALL native modules and cross-feature combinations are ported.
function Update-ClassicCore([byte[]]$Data,$Switches,[string]$ResourceDir,[switch]$BestEffort,$Issues=$null) {
    . (Join-Path $ResourceDir 'game_build.ps1')
    if((Get-ShadowGameBuild $Data).Family -ne 'classic') {throw 'Classic core requires the classic game build'}
    $layout=Get-Content -LiteralPath (Get-ShadowNativeLayoutPath $Data $ResourceDir 'core_patches.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    function Core-Bytes([string]$hex) {
        if($hex -notmatch '^(?:[0-9A-F]{2})+$') {throw 'Invalid classic core hex'}
        [byte[]]$b=New-Object byte[] ($hex.Length/2)
        for($i=0;$i -lt $b.Length;$i++) {$b[$i]=[Convert]::ToByte($hex.Substring(2*$i,2),16)}
        return ,$b
    }
    $blocked=@{}
    [byte[]]$normalized=$Data.Clone()
    foreach($p in $layout.patches) {
        $original=Core-Bytes $p.original;$patched=Core-Bytes $p.patched;$offset=[int]$p.offset
        if($original.Length -ne $patched.Length -or $offset -lt 0 -or $offset+$original.Length -gt $Data.Length) {throw 'Unsupported classic core layout'}
        $current=[BitConverter]::ToString($Data,$offset,$original.Length).Replace('-','')
        if($current -ne $p.original -and $current -ne $p.patched) {
            if(-not $BestEffort){throw ('Unknown classic core site: '+$p.feature)}
            $blocked[[string]$p.feature]=$true;continue
        }
        $original.CopyTo($normalized,$offset)
    }
    $sha=[Security.Cryptography.SHA256]::Create()
    try {
        foreach($g in @($layout.guards | Where-Object {-not $BestEffort})) {
            if([BitConverter]::ToString($sha.ComputeHash($normalized,[int]$g.offset,[int]$g.size)).Replace('-','').ToLowerInvariant() -ne $g.sha256) {throw 'Unknown classic core function; refused'}
        }
    } finally {$sha.Dispose()}
    foreach($key in $blocked.Keys){$Switches[$key]=$false;if($null -ne $Issues){$Issues.Add([pscustomobject]@{Keys=@($key);Reason='目标字节已被其他内容修改，保留原内容';Stage='原生功能'})}}
    [byte[]]$out=$Data.Clone()
    foreach($p in $layout.patches) {
        if($blocked.ContainsKey([string]$p.feature)){continue}
        $wanted=if($Switches[$p.feature]) {$p.patched} else {$p.original}
        (Core-Bytes $wanted).CopyTo($out,[int]$p.offset)
    }
    return ,$out
}
