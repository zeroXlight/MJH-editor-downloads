﻿function Update-DynamicRankGrowth([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    . (Join-Path $ResourceDir 'game_build.ps1')
    if((Get-ShadowGameBuild $Data).Family -eq 'classic') {
        $pe=[BitConverter]::ToInt32($Data,0x3c)
        $exceptionSize=[BitConverter]::ToUInt32($Data,$pe+24+112+3*8+4)
        $name='dynrank_growth_layout.json'
        if($exceptionSize -in @(0x10e978,0x10e9a8)) {$name='dynrank_growth_shared_layout.json'}
        elseif($exceptionSize -notin @(0x10e96c,0x10e99c)) {throw 'Unknown classic rank unwind parent; strip later modules first'}
        . (Join-Path $ResourceDir 'patch_equal_layout.ps1')
        return ,(Update-ShadowEqualLayout $Data $Enabled (Get-ShadowNativeLayoutPath $Data $ResourceDir $name))
    }
    $offset=0x72C030;$size=0x1BAA
    if($Data.Length -lt ($offset+$size)) {throw 'Unsupported dynamic rank growth DLL'}
    $sha=[Security.Cryptography.SHA256]::Create()
    try {
        $codes=@()
        foreach($name in @('dynrank_growth_original.hex','dynrank_growth.hex','dynrank_growth_legacy.hex','dynrank_growth_attack_legacy.hex')) {
            $hex=[IO.File]::ReadAllText((Join-Path $ResourceDir $name)).Trim()
            if($hex -notmatch '^[0-9A-F]+$' -or $hex.Length -ne 2*$size) {throw 'Invalid dynamic rank growth resource'}
            [byte[]]$code=New-Object byte[] $size
            for($i=0;$i -lt $size;$i++) {$code[$i]=[Convert]::ToByte($hex.Substring(2*$i,2),16)}
            $codes+=,$code
        }
        # Legacy blobs are recognized for migration only, never installed.
        $expected=@('EECDBA27A387F98785D485BDE25D5249B4D74C576975486E9D4C97A25858787E','73713BFA0B28E87272FDD8106614EDA7E34920B608D6644DE22490F0BBB0228C','D9AFFE864C0C971046B40DC9D31190250F8D52422A6F6F2C08424C49BD17DCA4','2DEC810F42C2F26ED044D010E0923E53615627543405ACAE4AC3CF8A68521C37')
        for($i=0;$i -lt 4;$i++) {
            if([BitConverter]::ToString($sha.ComputeHash($codes[$i])).Replace('-','') -ne $expected[$i]) {throw 'Dynamic rank growth resource hash differs'}
        }
        $current=[BitConverter]::ToString($sha.ComputeHash($Data,$offset,$size)).Replace('-','')
        $oldRecruitVersion='5EEF7258B2D326F34D5C805732E34662EDC686FC1AFD7194F53C635643ACD750'
        $previousTestVersion='DFB8DB67471C6D557193005DE68535152364B4B7C3D1FABF6AB93F8E154910DF'
        if($current -notin ($expected+@($oldRecruitVersion,$previousTestVersion))) {throw 'Unknown role upgrade function; refused dynamic rank growth patch'}
        $hookOffsets=@(0x7217D2,0x724326)
        $hookOriginal=@('488B442450','0FB6442458')
        $hookCurrent=@('E991AF0000','E951840000')
        $hookPrevious=@('E939AF0000','E9F9830000')
        $hookNames=@('dynrank_growth_addexp.hex','dynrank_growth_addrole.hex')
        $hookCodes=@()
        for($i=0;$i -lt 2;$i++) {
            $hex=[IO.File]::ReadAllText((Join-Path $ResourceDir $hookNames[$i])).Trim()
            if($hex -ne $hookCurrent[$i]){throw 'Dynamic rank outer hook resource differs'}
            [byte[]]$code=New-Object byte[] 5
            for($j=0;$j -lt 5;$j++){$code[$j]=[Convert]::ToByte($hex.Substring(2*$j,2),16)}
            $hookCodes+=,$code
            $wanted=$hookOriginal[$i]
            if($current -eq $expected[1]){$wanted=$hookCurrent[$i]}
            elseif($current -eq $previousTestVersion){$wanted=$hookPrevious[$i]}
            if([BitConverter]::ToString($Data,$hookOffsets[$i],5).Replace('-','') -ne $wanted){throw 'Dynamic rank function and outer hooks differ'}
        }
        $hook=0x46E084
        $hookHex=[BitConverter]::ToString($Data,$hook,5).Replace('-','')
        if($hookHex -notin @('E8B7D62700','E837E72B00')){throw 'Unknown recruitment return call'}
        if($hookHex -ne 'E8B7D62700' -and $current -ne $oldRecruitVersion){throw 'Recruitment helper and hook differ'}
        [byte[]]$out=$Data.Clone()
        $index=0;if($Enabled) {$index=1}
        $codes[$index].CopyTo($out,$offset)
        for($i=0;$i -lt 2;$i++){
            if($Enabled){$hookCodes[$i].CopyTo($out,$hookOffsets[$i])}
            else{
                for($j=0;$j -lt 5;$j++){$out[$hookOffsets[$i]+$j]=[Convert]::ToByte($hookOriginal[$i].Substring(2*$j,2),16)}
            }
        }
        [byte[]]$hookBytes=0xE8,0xB7,0xD6,0x27,0
        $hookBytes.CopyTo($out,$hook)
        return ,$out
    } finally {$sha.Dispose()}
}
