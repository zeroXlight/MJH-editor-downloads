function Update-AoYiOptimization([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    . (Join-Path $ResourceDir 'game_build.ps1')
    $layoutPath=Get-ShadowNativeLayoutPath $Data $ResourceDir 'aoyi_optimization_layout.json'
    $layout=Get-Content -LiteralPath $layoutPath -Raw -Encoding UTF8 | ConvertFrom-Json
    function AoYi-Bytes([string]$Hex) {
        if($Hex -notmatch '^(?:[0-9A-F]{2})+$'){throw 'Invalid AoYi patch bytes'}
        [byte[]]$b=New-Object byte[] ($Hex.Length/2)
        for($i=0;$i -lt $b.Length;$i++){$b[$i]=[Convert]::ToByte($Hex.Substring(2*$i,2),16)}
        return ,$b
    }
    [byte[]]$normalized=$Data.Clone()
    foreach($p in $layout.patches) {
        $original=AoYi-Bytes $p.original;$patched=AoYi-Bytes $p.patched
        $o=[int]$p.offset
        if($original.Length -ne $patched.Length -or $o+$original.Length -gt $Data.Length){throw 'Unsupported AoYi DLL layout'}
        $current=[BitConverter]::ToString($Data,$o,$original.Length).Replace('-','')
        if($current -ne $p.original -and $current -ne $p.patched){throw ('Unknown AoYi code: '+$p.name)}
        $original.CopyTo($normalized,$o)
    }
    $sha=[Security.Cryptography.SHA256]::Create()
    try {
        foreach($g in $layout.guards) {
            if([BitConverter]::ToString($sha.ComputeHash($normalized,[int]$g.offset,[int]$g.size)).Replace('-','') -ne $g.sha256){throw 'Unknown AoYi function layout; refused patch'}
        }
    } finally {$sha.Dispose()}
    [byte[]]$out=$Data.Clone()
    foreach($p in $layout.patches) {
        $hex=if($Enabled){$p.patched}else{$p.original}
        (AoYi-Bytes $hex).CopyTo($out,[int]$p.offset)
    }
    return ,$out
}
