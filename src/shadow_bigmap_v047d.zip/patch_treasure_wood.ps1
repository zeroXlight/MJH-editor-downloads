﻿. (Join-Path $PSScriptRoot 'patch_treasure_quality.ps1')
function Set-TreasureWoodInGame([string]$Dir,[string]$BackupDir,[bool]$Enabled) {
    # Quality is restored before wood candidates change, then reapplied from its own baseline.
    Set-TreasureQualityInGame $Dir $BackupDir $false
    $path=Join-Path $Dir 'TableData\Drop.bytes'
    $backup=Join-Path $BackupDir 'Drop.bytes.treasure_wood.orig'
    if(-not (Test-Path -LiteralPath $path)){throw 'Missing treasure Drop.bytes'}
    if(-not (Test-Path -LiteralPath $backup)) {
        if(-not $Enabled){return}
        Copy-Item -LiteralPath $path -Destination $backup
    }
    if(-not ('ShadowTreasureWood' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'treasure_wood_table.cs')}
    [byte[]]$data=[ShadowTreasureWood]::Update([IO.File]::ReadAllBytes($path),[IO.File]::ReadAllBytes($backup),$Enabled)
    [IO.File]::WriteAllBytes($path,$data)
}
