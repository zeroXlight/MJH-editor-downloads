﻿param([string]$Path='', [switch]$Restore)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'patch_behavior.ps1')
function Update-ConsultProbability([byte[]]$Data, [bool]$Enabled) {
    $old=@(10,20,40,60,80,90,100,100,100)
    $new=@(10,15,25,35,50,65,80,80,80)
    $changes=@(); $seen=@{}; [int]$pos=0
    while ($pos -lt $Data.Length) {
        $key=Get-AdvVarint $Data ([ref]$pos)
        if ($key -ne 18) { Skip-AdvValue $Data ([ref]$pos) ($key -band 7) $pos; continue }
        $length=Get-AdvVarint $Data ([ref]$pos); $end=$pos+$length
        $id=0; $rank=0; $behavior=0; $value=$null; $offset=-1
        while ($pos -lt $end) {
            $k=Get-AdvVarint $Data ([ref]$pos); $field=$k -shr 3
            if (($k -band 7) -eq 0) {
                $start=$pos; $v=Get-AdvVarint $Data ([ref]$pos)
                switch ($field) { 1 {$id=$v} 2 {$rank=$v} 3 {$behavior=$v} 4 {$value=$v; $offset=$start; if ($pos-$start -ne 1) { throw 'Unsupported favor encoding' }} }
            } else { Skip-AdvValue $Data ([ref]$pos) ($k -band 7) $pos }
        }
        if ($pos -ne $end) { throw 'Invalid Probability row length' }
        if ($id -ge 1 -and $id -le 9) {
            if ($seen.ContainsKey($id) -or $rank -ne $id -or $behavior -ne 6 -or $offset -lt 0) { throw 'Unknown Probability row layout' }
            if ($value -ne $old[$id-1] -and $value -ne $new[$id-1]) { throw ('Unknown favor value in row '+$id) }
            $seen[$id]=$true
            $changes+=@{Offset=$offset; Value=$(if ($Enabled) {$new[$id-1]} else {$old[$id-1]})}
        }
    }
    if ($seen.Count -ne 9) { throw 'Missing consult Probability rows' }
    $result=[byte[]]$Data.Clone()
    foreach ($c in $changes) { $result[$c.Offset]=[byte]$c.Value }
    return ,$result
}
if ($Path) {
    $data=[IO.File]::ReadAllBytes($Path)
    $result=Update-ConsultProbability $data (-not $Restore)
    [IO.File]::WriteAllBytes($Path,$result)
}
