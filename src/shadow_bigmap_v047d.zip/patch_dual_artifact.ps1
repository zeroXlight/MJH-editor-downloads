﻿function Update-DualArtifact([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir,[Nullable[bool]]$EquipNoLimit=$null) {
    . (Join-Path $ResourceDir 'game_build.ps1')
    $layoutPath=Get-ShadowNativeLayoutPath $Data $ResourceDir 'dual_artifact_layout.json'
    $ResourceDir=Split-Path $layoutPath -Parent
    $layout=Get-Content -LiteralPath $layoutPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $gateOffset=0x493a96
    if($layout.PSObject.Properties['gate_offset']) {$gateOffset=[int]$layout.gate_offset}
    [byte[]]$normalized=$Data.Clone()
    $changes=New-Object 'System.Collections.Generic.List[object]'
    $sha=[Security.Cryptography.SHA256]::Create()
    $detectedNoLimit=$false
    try {
        for($i=0;$i -lt $layout.patches.Count;$i++) {
            $patch=$layout.patches[$i];$codes=@{}
            $kinds=@('original','patched')
            if($i -eq 1) {
                $kinds+='nolimit'
                if($patch.PSObject.Properties['legacy_patched']) {$kinds+= @('legacy_patched','legacy_nolimit')}
            }
            foreach($kind in $kinds) {
                $hex=[IO.File]::ReadAllText((Join-Path $ResourceDir ('dual_artifact_'+$i+'_'+$kind+'.hex'))).Trim()
                if($hex -notmatch '^[0-9A-F]+$' -or $hex.Length -ne 2*$patch.size) {throw 'Invalid dual-artifact resource'}
                [byte[]]$code=New-Object byte[] ([int]$patch.size)
                for($j=0;$j -lt $code.Length;$j++) {$code[$j]=[Convert]::ToByte($hex.Substring(2*$j,2),16)}
                $hash=[BitConverter]::ToString($sha.ComputeHash($code)).Replace('-','')
                if($hash -ne $patch.$kind) {throw 'Dual-artifact resource checksum differs'}
                $codes[$kind]=$code
            }
            $offset=[int]$patch.offset;$size=[int]$patch.size
            if($offset+$size -gt $Data.Length) {throw 'Unsupported dual-artifact DLL'}
            $current=[BitConverter]::ToString($Data,$offset,$size)
            if($i -eq 1) {
                $gate=$gateOffset-$offset
                [byte[]]$legacyNoLimit=$codes.original.Clone();$legacyNoLimit[$gate]=0xeb
                $detectedNoLimit=($current -eq [BitConverter]::ToString($legacyNoLimit) -or $current -eq [BitConverter]::ToString($codes.nolimit))
                if($codes.ContainsKey('legacy_nolimit') -and $current -eq [BitConverter]::ToString($codes.legacy_nolimit)) {$detectedNoLimit=$true}
            }
            $known=($current -eq [BitConverter]::ToString($codes.original) -or $current -eq [BitConverter]::ToString($codes.patched))
            if($i -eq 1 -and $codes.ContainsKey('legacy_patched') -and $current -eq [BitConverter]::ToString($codes.legacy_patched)) {$known=$true}
            if(-not $known -and -not ($i -eq 1 -and $detectedNoLimit)) {throw 'Unknown dual-artifact code; refused'}
            $codes.original.CopyTo($normalized,$offset)
            $changes.Add(@{Offset=$offset;Codes=$codes})
        }
        foreach($guard in $layout.guards) {
            if([BitConverter]::ToString($sha.ComputeHash($normalized,[int]$guard.offset,[int]$guard.size)).Replace('-','') -ne $guard.sha256) {throw 'Unknown dual-artifact function layout; refused'}
        }
        [byte[]]$out=$Data.Clone()
        $useNoLimit=if($null -eq $EquipNoLimit) {$detectedNoLimit} else {[bool]$EquipNoLimit}
        for($i=0;$i -lt $changes.Count;$i++) {
            $change=$changes[$i]
            [byte[]]$code=if($Enabled) {$change.Codes.patched.Clone()} else {$change.Codes.original.Clone()}
            if($i -eq 1 -and $useNoLimit) {
                if($Enabled) {$code=$change.Codes.nolimit.Clone()} else {$code[$gateOffset-$change.Offset]=0xeb}
            }
            $code.CopyTo($out,$change.Offset)
        }
        return ,$out
    } finally {$sha.Dispose()}
}
