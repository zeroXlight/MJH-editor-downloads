﻿# Equal-size, build-specific patches with complete original-function guards.
function Update-ShadowEqualLayout([byte[]]$Data,[bool]$Enabled,[string]$LayoutPath) {
    if(-not ('ShadowNativeBytes' -as [type])) {Add-Type -Path (Join-Path $PSScriptRoot 'native_bytes.cs')}
    $layout=Get-Content -LiteralPath $LayoutPath -Raw -Encoding UTF8 | ConvertFrom-Json
    function Equal-Bytes([string]$hex) {
        if($hex -notmatch '^(?:[0-9A-F]{2})+$') {throw 'Invalid equal-size native hex'}
        return ,[ShadowNativeBytes]::Hex($hex)
    }
    [byte[]]$normalized=$Data.Clone()
    foreach($p in $layout.patches) {
        $offset=[int]$p.offset;$original=Equal-Bytes $p.original;$patched=Equal-Bytes $p.patched
        if($offset -lt 0 -or $original.Length -ne $patched.Length -or $offset+$original.Length -gt $Data.Length) {throw 'Unsupported equal-size native layout'}
        $current=[BitConverter]::ToString($Data,$offset,$original.Length).Replace('-','')
        if($current -ne $p.original -and $current -ne $p.patched) {throw 'Unknown equal-size native patch region'}
        $original.CopyTo($normalized,$offset)
    }
    $sha=[Security.Cryptography.SHA256]::Create()
    try {
        foreach($g in $layout.guards) {
            if([int]$g.offset -lt 0 -or [int]$g.offset+[int]$g.size -gt $Data.Length) {throw 'Invalid equal-size native guard'}
            if([BitConverter]::ToString($sha.ComputeHash($normalized,[int]$g.offset,[int]$g.size)).Replace('-','') -ne $g.sha256) {throw 'Unknown equal-size native function; refused'}
        }
    } finally {$sha.Dispose()}
    [byte[]]$out=$Data.Clone()
    foreach($p in $layout.patches) {
        $hex=if($Enabled) {$p.patched} else {$p.original}
        (Equal-Bytes $hex).CopyTo($out,[int]$p.offset)
    }
    return ,$out
}
