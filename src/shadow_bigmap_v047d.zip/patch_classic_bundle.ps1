﻿# Prepare every native change in memory. Strip extensions in reverse order
# before changing shared parents. Never load or write a DLL in this module.
function Update-ClassicNativeBundleStrict([byte[]]$Data,$Switches,[string]$ResourceDir,[byte[]]$FragmentPool=@(),[byte[]]$CapIds=@()) {
    foreach($name in @('game_build.ps1','patch_classic_core.ps1','patch_classic_shared.ps1','patch_dynrank_growth.ps1','patch_clan_talents.ps1','patch_dual_artifact.ps1','patch_staticmax_enhance.ps1','patch_recast_optimization.ps1','patch_dynrank_recruit_level.ps1','patch_aoyi_optimization.ps1','patch_carryout.ps1','patch_fragment.ps1','patch_uncollectible_cap.ps1','patch_maze_sweep.ps1','patch_harvest_fix.ps1','patch_random_equip.ps1','patch_wish_candidate_store.ps1')) {. (Join-Path $ResourceDir $name)}
    if((Get-ShadowGameBuild $Data).Family -ne 'classic') {throw 'Classic bundle requires classic native layout'}
    [byte[]]$b=Update-WishCandidateStore $Data $false $ResourceDir
    $b=Update-RandomEquip $b $false $ResourceDir
    $b=Update-HarvestFix $b $false $ResourceDir
    $b=Update-MazeSweep $b $false $ResourceDir
    $b=Update-UncollectibleCap $b @{} (Join-Path $ResourceDir 'uncollectible_cap.hex')
    $b=Update-Fragment $b @{} (Join-Path $ResourceDir 'fragment_code.hex')
    $b=Update-CarryOut $b @{} (Join-Path $ResourceDir 'carryout_code.hex')
    $b=Update-ClanWishPool $b $false $ResourceDir
    $b=Update-DynamicRankRecruitLevel $b $false $ResourceDir
    $b=Update-DynamicRankGrowth $b $false $ResourceDir
    $b=Update-RecastOptimization $b $false $ResourceDir
    $b=Update-StaticMaxEnhance $b $false $ResourceDir
    $b=Update-DualArtifact $b $false $ResourceDir
    $b=Update-AoYiOptimization $b $false $ResourceDir
    $b=Update-ClassicShared $b @{} $ResourceDir
    $b=Update-ClassicCore $b @{} $ResourceDir
    [byte[]]$clean=$b.Clone()
    $b=Update-ClassicCore $b $Switches $ResourceDir
    $b=Update-ClassicShared $b $Switches $ResourceDir
    $b=Update-DynamicRankGrowth $b ([bool]$Switches['optimize.dynrank']) $ResourceDir
    $b=Update-ClanWishPool $b ([bool]$Switches['optimize.wishtalents']) $ResourceDir
    $b=Update-DualArtifact $b ([bool]$Switches['optimize.dualartifact']) $ResourceDir ([bool]$Switches['optimize.equipnolimit'])
    $b=Update-StaticMaxEnhance $b ([bool]$Switches['optimize.staticmax']) $ResourceDir
    $b=Update-RecastOptimization $b ([bool]$Switches['optimize.recast']) $ResourceDir
    $b=Update-DynamicRankRecruitLevel $b ([bool]$Switches['optimize.dynrank']) $ResourceDir
    $b=Update-AoYiOptimization $b ([bool]$Switches['optimize.aoyi']) $ResourceDir
    $b=Update-CarryOut $b $Switches (Join-Path $ResourceDir 'carryout_code.hex')
    $b=Update-Fragment $b $Switches (Join-Path $ResourceDir 'fragment_code.hex') $FragmentPool
    $b=Update-UncollectibleCap $b $Switches (Join-Path $ResourceDir 'uncollectible_cap.hex') $CapIds
    $b=Update-MazeSweep $b ([bool]$Switches['optimize.mazesweep']) $ResourceDir
    $b=Update-HarvestFix $b ([bool]$Switches['fix.harvest']) $ResourceDir
    $b=Update-RandomEquip $b ([bool]$Switches['optimize.randomequip']) $ResourceDir ([bool]$Switches['balance.nolimitgift'])
    $b=Update-WishCandidateStore $b ([bool]$Switches['optimize.wishfill']) $ResourceDir
    return @{Original=$clean;Patched=$b}
}


# Best-effort install: isolate known feature failures; do not rewrite unknown layouts.
function Update-ClassicNativeBundle([byte[]]$Data,$Switches,[string]$ResourceDir,[byte[]]$FragmentPool=@(),[byte[]]$CapIds=@(),[switch]$BestEffort) {
    if(-not $BestEffort){return (Update-ClassicNativeBundleStrict $Data $Switches $ResourceDir $FragmentPool $CapIds)}
    foreach($name in @('game_build.ps1','patch_classic_core.ps1','patch_classic_shared.ps1','patch_dynrank_growth.ps1','patch_clan_talents.ps1','patch_dual_artifact.ps1','patch_staticmax_enhance.ps1','patch_recast_optimization.ps1','patch_dynrank_recruit_level.ps1','patch_aoyi_optimization.ps1','patch_carryout.ps1','patch_fragment.ps1','patch_uncollectible_cap.ps1','patch_maze_sweep.ps1','patch_harvest_fix.ps1','patch_random_equip.ps1','patch_wish_candidate_store.ps1')) {. (Join-Path $ResourceDir $name)}
    $issues=New-Object 'System.Collections.Generic.List[object]'
    $modules=@(
        [pscustomobject]@{Name='Update-WishCandidateStore';Keys=@('optimize.wishfill');Off={param($x) Update-WishCandidateStore $x $false $ResourceDir};On={param($x) Update-WishCandidateStore $x ([bool]$Switches['optimize.wishfill']) $ResourceDir}}
        [pscustomobject]@{Name='Update-RandomEquip';Keys=@('optimize.randomequip');Off={param($x) Update-RandomEquip $x $false $ResourceDir};On={param($x) Update-RandomEquip $x ([bool]$Switches['optimize.randomequip']) $ResourceDir ([bool]$Switches['balance.nolimitgift'])}}
        [pscustomobject]@{Name='Update-HarvestFix';Keys=@('fix.harvest');Off={param($x) Update-HarvestFix $x $false $ResourceDir};On={param($x) Update-HarvestFix $x ([bool]$Switches['fix.harvest']) $ResourceDir}}
        [pscustomobject]@{Name='Update-MazeSweep';Keys=@('optimize.mazesweep');Off={param($x) Update-MazeSweep $x $false $ResourceDir};On={param($x) Update-MazeSweep $x ([bool]$Switches['optimize.mazesweep']) $ResourceDir}}
        [pscustomobject]@{Name='Update-UncollectibleCap';Keys=@('optimize.uncollectiblecap');Off={param($x) Update-UncollectibleCap $x @{} (Join-Path $ResourceDir 'uncollectible_cap.hex')};On={param($x) Update-UncollectibleCap $x $Switches (Join-Path $ResourceDir 'uncollectible_cap.hex') $CapIds}}
        [pscustomobject]@{Name='Update-Fragment';Keys=@('optimize.fragment');Off={param($x) Update-Fragment $x @{} (Join-Path $ResourceDir 'fragment_code.hex')};On={param($x) Update-Fragment $x $Switches (Join-Path $ResourceDir 'fragment_code.hex') $FragmentPool}}
        [pscustomobject]@{Name='Update-CarryOut';Keys=@('balance.outenhance','balance.outheirloom','balance.outmartial','balance.outheaven','balance.outmaterial','balance.outgold','balance.outcrack');Off={param($x) Update-CarryOut $x @{} (Join-Path $ResourceDir 'carryout_code.hex')};On={param($x) Update-CarryOut $x $Switches (Join-Path $ResourceDir 'carryout_code.hex')}}
        [pscustomobject]@{Name='Update-ClanWishPool';Keys=@('optimize.wishtalents');Off={param($x) Update-ClanWishPool $x $false $ResourceDir};On={param($x) Update-ClanWishPool $x ([bool]$Switches['optimize.wishtalents']) $ResourceDir}}
        [pscustomobject]@{Name='Update-DynamicRankRecruitLevel';Keys=@('optimize.dynrank');Off={param($x) Update-DynamicRankRecruitLevel $x $false $ResourceDir};On={param($x) Update-DynamicRankRecruitLevel $x ([bool]$Switches['optimize.dynrank']) $ResourceDir}}
        [pscustomobject]@{Name='Update-DynamicRankGrowth';Keys=@('optimize.dynrank');Off={param($x) Update-DynamicRankGrowth $x $false $ResourceDir};On={param($x) Update-DynamicRankGrowth $x ([bool]$Switches['optimize.dynrank']) $ResourceDir}}
        [pscustomobject]@{Name='Update-RecastOptimization';Keys=@('optimize.recast');Off={param($x) Update-RecastOptimization $x $false $ResourceDir};On={param($x) Update-RecastOptimization $x ([bool]$Switches['optimize.recast']) $ResourceDir}}
        [pscustomobject]@{Name='Update-StaticMaxEnhance';Keys=@('optimize.staticmax');Off={param($x) Update-StaticMaxEnhance $x $false $ResourceDir};On={param($x) Update-StaticMaxEnhance $x ([bool]$Switches['optimize.staticmax']) $ResourceDir}}
        [pscustomobject]@{Name='Update-DualArtifact';Keys=@('optimize.dualartifact');Off={param($x) Update-DualArtifact $x $false $ResourceDir};On={param($x) Update-DualArtifact $x ([bool]$Switches['optimize.dualartifact']) $ResourceDir ([bool]$Switches['optimize.equipnolimit'])}}
        [pscustomobject]@{Name='Update-AoYiOptimization';Keys=@('optimize.aoyi');Off={param($x) Update-AoYiOptimization $x $false $ResourceDir};On={param($x) Update-AoYiOptimization $x ([bool]$Switches['optimize.aoyi']) $ResourceDir}}
        [pscustomobject]@{Name='Update-ClassicShared';Keys=@('optimize.chuangwang','optimize.dynrank','optimize.wishfill');Off={param($x) Update-ClassicShared $x @{} $ResourceDir};On={param($x) Update-ClassicShared $x $Switches $ResourceDir}}
        [pscustomobject]@{Name='Update-ClassicCore';Keys=@('balance.exp','fix.chetmartialexp','optimize.countrule','optimize.equipnolimit','optimize.exclusive','optimize.learnnolimit');Off={param($x) Update-ClassicCore $x @{} $ResourceDir -BestEffort -Issues $issues};On={param($x) Update-ClassicCore $x $Switches $ResourceDir -BestEffort -Issues $issues}}
    )
    [byte[]]$b=$Data.Clone()
    try {
        foreach($m in $modules){$action=$m.Off;$candidate=$b.Clone();$b=& $action $candidate}
    } catch {
        $reason='共享原生布局无法安全拆分，保留DLL：'+$_.Exception.Message
        foreach($key in @($modules.Keys | Select-Object -Unique)){$Switches[$key]=$false}
        $issues.Add([pscustomobject]@{Keys=@($modules.Keys | Select-Object -Unique);Reason=$reason;Stage='共享原生组件'})
        return @{Original=$Data;Patched=$Data;Skipped=$issues.ToArray();NativePreserved=$true}
    }
    foreach($issue in $issues){foreach($key in $issue.Keys){$Switches[$key]=$false}}
    [byte[]]$clean=$b.Clone();$blocked=@{};$ordered=@($modules);[array]::Reverse($ordered)
    do {
        $restart=$false;$b=$clean.Clone()
        foreach($m in $ordered){
            if($blocked.ContainsKey($m.Name)){continue}
            try {$action=$m.On;$candidate=$b.Clone();$b=& $action $candidate}
            catch {
                $blocked[$m.Name]=$true;foreach($key in $m.Keys){$Switches[$key]=$false}
                $issues.Add([pscustomobject]@{Keys=@($m.Keys);Reason=$_.Exception.Message;Stage=$m.Name})
                $restart=$true;break
            }
        }
    } while($restart)
    return @{Original=$clean;Patched=$b;Skipped=$issues.ToArray();NativePreserved=$false}
}
