﻿# ============================================================================
#  patch_server.ps1  —— 服务端补丁：数量上限闸门 + 闯王刀强化（梦江湖 单机版）
# ============================================================================
#  作用
#    《梦江湖》单机版的服务端逻辑跑在本机进程里的原生 C++ 层：
#        DreamRivakes_Data\Plugins\RaceLogic_Release_x64.dll
#    它有两套「武学 / 天赋数量已达上限」判定，并且**不认识本 MOD 的
#    「心愿 / 专属不占数量上限」口径**，只会按原始条数拦 —— 于是就出现
#    「角色面板显示 x/y 是对的，用秘籍学习却被服务器拒绝」。
#
#    本脚本把那两道闸门改成恒放行（其余逻辑一概不动），数量上限的最终裁定
#    交回客户端（由 MOD 的计数规则负责）。这与 MOD 的「心愿/专属不占数量上限」
#    是**同一个功能的两半**，开关也共用 optimize.countrule。
#
#  改的是什么（四处，均只把「拦截」改成「放行」，其余逻辑一概不动）
#    0x180724286  BeInstRole::AddMartial   武学闸门1   72 57             -> EB 57
#    0x1807242E7  BeInstRole::AddMartial   武学闸门2   0F 82 94 00 00 00 -> E9 95 00 00 00 90
#    0x18072AB7F  BeInstRole::CanAddGift   天赋闸门    72 73             -> EB 73
#    0x18047A907  CheckReplaceLearnedWishReward 心愿闸门  75 07        -> 90 90
#    括号里是 VA；下面用的是**文件内偏移**（本游戏版本固定）：
#    0x723686 / 0x7236E7 / 0x729F7F / 0x479D07
#
#    前两处 + 第三处 = 数量上限（与 MOD 的「心愿/专属不占数量上限」是同一功能的两半，
#    共用开关 optimize.countrule）。
#    第四处 = 心愿奖励：原版规则「该心愿奖励你已领取」会挡住重复领取；但 MOD 的计数
#    减免要求「心愿里必须有它」，所以也要放行（同属 optimize.countrule）。
#
#  安全性
#    · 打之前先逐字节核对原始字节，对不上就中止（不猜、不盲改）
#    · 先把整份原版 DLL 备份到 游戏目录\_MOD备份_暗影MOD合集\
#    · 该 DLL 没有数字签名、也没有 TLS 回调自校验，改完照样能被游戏加载
#    · 幂等：已经打过就跳过，不会重复改
#
#  用法
#    powershell -ExecutionPolicy Bypass -File patch_server.ps1                 # 安装/打补丁
#    powershell -ExecutionPolicy Bypass -File patch_server.ps1 -Check          # 只看状态
#    powershell -ExecutionPolicy Bypass -File patch_server.ps1 -Restore        # 还原成原版
#    powershell -ExecutionPolicy Bypass -File patch_server.ps1 "D:\...\xiake"  # 指定游戏目录
#
#  注意：Steam「验证文件完整性」会把这份 DLL 还原 —— 之后需要重新跑一次本脚本。
# ============================================================================

[CmdletBinding()]
param(
    [Parameter(Position = 0)][string]$GameDir = '',
    [switch]$Check,
    [switch]$Restore
)

$ErrorActionPreference = 'Stop'

$DLL_REL     = 'DreamRivakes_Data\Plugins\RaceLogic_Release_x64.dll'
$BACKUP_NAME = '_MOD备份_暗影MOD合集'
$BAK_FILE    = 'RaceLogic_Release_x64.dll.orig'

# 文件内偏移, 原始字节(hex), 补丁字节(hex), 说明
#
# ★ 按功能分八组：
#     $PATCHES      数量上限 / 心愿重复领取（安装器里对应开关 optimize.countrule）
#     $PATCHES_CW   闯王刀强化（对应开关 optimize.chuangwang）
#         = 迷宫跳过对藏宝迷宫无条件开放 + 持有闯王军刀时战斗胜利积分 +100
#     $PATCHES_VSZ  .text 映射区（共享基础项）—— 闯王刀 与 角色动态品质 的 cave
#           都在原版 .text 末尾填充区里，必须把 VirtualSize 抬到 SizeOfRawData
#           （0x210）那块内存才被映射。任一 cave 功能需要就抬。
#     $PATCHES_DYN  角色动态品质（对应开关 optimize.dynrank）
#   本脚本一次把八组都打上；-Restore 用整份备份还原（八组一起回退）。
$PATCHES = @(
    @{ Off = 0x723686; Orig = '7257'; New = 'EB57'; Note = '武学闸门1 @BeInstRole::AddMartial  jb→jmp' }
    @{ Off = 0x7236E7; Orig = '0F8294000000'; New = 'E99500000090'; Note = '武学闸门2 @BeInstRole::AddMartial  jb→jmp' }
    @{ Off = 0x729F7F; Orig = '7273'; New = 'EB73'; Note = '天赋闸门  @BeInstRole::CanAddGift  jb→jmp' }
    @{ Off = 0x479D07; Orig = '7507'; New = '9090'; Note = '心愿闸门  @CheckReplaceLearnedWishReward  jne→nop' }
)

$PATCHES_CW = @(
    @{ Off = 0x533F23; Orig = '0F8440010000'; New = '909090909090'; Note = '迷宫跳过 H1 @0x180534a70  flag1==0 不再直接返回，继续走持刀判定（填 +0x2ec 缓存）' }
    @{ Off = 0x533F40; Orig = '0F8423010000'; New = '909090909090'; Note = '迷宫跳过 H0 @0x180534a70  非迷宫也不短路，继续走持刀判定（填 +0x2ec 缓存）' }
    @{ Off = 0x533F94; Orig = 'B001E9D3000000'; New = 'E9D00000009090'; Note = '迷宫跳过 H2 @0x180534a70  玩家持刀命中出口：跳返回 flag1 而非恒 1' }
    @{ Off = 0x53405C; Orig = 'B001EB0E'; New = 'EB0B9090'; Note = '迷宫跳过 H3 @0x180534a70  队友持刀命中出口：跳返回 flag1 而非恒 1' }
    @{ Off = 0x534065; Orig = '32C0EB05'; New = 'EB029090'; Note = '迷宫跳过 H4 @0x180534a70  持刀未命中出口：跳返回 flag1 而非恒 0' }

    @{ Off = 0x52CDE9; Orig = '0FB6098808'; New = '0FB6098808'; Legacy = @('E90BA9A300'); Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0xF676F9; Orig = '000000000000000000000000000000000000000000000000000000000000000000000000000000'; New = '0FB644243885C00F8581655CFFE992655CFF3D05500600740A2D12D206003D40030000C3909090'; Legacy = @('53488B5C24780FB60983BBEC02000000740C83C16484ED7405B9FF00000088085BE9CF565CFF90','53488B5C24780FB60983BBEC02000000740D83C16383F9FF7605B9FF00000088085BE9CE565CFF','53488B5C24780FB60983BBEC02000000740D83C16483F9FF7605B9FF00000088085BE9CE565CFF'); Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0x52DC7E; Orig = '0FB644243885C0'; New = 'E9769AA3009090'; Legacy = @('E990B231009090'); Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0x848F13; Orig = '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'; New = '488B54247083BAEC02000000740F83C0643DFF0000007E05B8FF00000089442420488B442470E9473ECEFF90'; Legacy = @('0FB644243885C00F85674DCEFFE9784DCEFF9090909090909090909090909090909090909090900000000000','E96F4DCEFF909090909090909090909090909090909090909090909090909090909090909090900000000000'); Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0x52CD7C; Orig = '89442420488B442470'; New = 'E992C1310090909090'; Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0x533F8D; Orig = '3D055006007507'; New = 'E87937A3007707'; Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0x53403E; Orig = '3D05500600751B'; New = 'E8C836A300771B'; Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
)

# ★ 共享基础项：.text 映射区（把末尾填充区纳入映射，供 cave 使用）
#   闯王刀强化 与 角色动态品质 的 cave 都落在原版 .text 末尾填充区，
#   任意一方需要就得把 VirtualSize 抬起来；两个功能都不用时才还原。
$PATCHES_VSZ = @(
    @{ Off = 0x210; Orig = 'F972F600'; New = '0074F600'; Note = '.text VirtualSize 0xf672f9→0xf67400：把末尾填充区纳入映射，供闯王刀/动态品质的 cave 使用' }
)

# ★ 第三组：经验值平衡（2026-09-29 新增，安装器里对应开关 balance.exp）
#
#   解除战斗经验的「等级压制」：原版在 等级差 =（我方等级 − 怪物等级）> 3 时，
#   按 (等级差−3) 递减经验；等级差够大时经验先算成负数、再被夹到 0
#   ⇒ 打低级怪完全白打。这里改为无条件跳过整段压制。
#
#   0x539A82 = VA 0x18053A682（等级压制函数 0x18053A4D0 内 jle→jmp，1 字节）。
#   `this+0x268`（= 下发给客户端的 uiLevelAddExp，结算页「低等级碾压 经验-XX%」）
#   会被跳过 ⇒ 该提示也不再出现。
#
#   ★ 本表与 install.ps1 里的 $SRV_PATCHES_BAL 必须逐项一致。
$PATCHES_BAL = @(
    @{ Off = 0x539A82; Orig = '7E5F'; New = 'EB5F'; Note = '等级压制解除 @战斗经验结算 0x18053A4D0  jle→jmp [等级差再大也不扣经验]' }
)

# ③ 修复坏掉的作弊指令 CHET_ADDMARTIALEXP（加武学经验）—— 归「修复mod」，开关 fix.chetmartialexp
#    现象：同一套 ID，CHET_ADDROLEMARTIAL（加武学）、CHET_ADDROLEEXP（加角色经验）
#          都正常，唯独这条**毫无反应且不报错**（作弊面板里填也一样）。
#    根因（反汇编实证）：注册表中的 handler `0x18060F450` 调内层 `0x180737470` 时，
#          把两个模式参数**硬编码成 0**：
#            0x18060F534  mov byte [rsp+0x28], 0 → 第6参 → AddMartialExp 的「匹配判据」
#            0x18060F539  mov byte [rsp+0x20], 0 → 第5参 → LookupRole 的「角色查找模式」
#          而**游戏自己的丹药效果**调同一个函数时（0x180574365/:448/:4DC/:5B9）：
#            · 判据（第6参）            4 处**恒为 1**
#            · 角色查找（第5参）        从角色对象读 ID 时传 0、传配置ID 时传 1
#          ⇒ 判据 0 = 拿武学ID 去比「容器键(运行时实例ID)」，静态武学ID 永远匹配不上；
#            角色查找 0 = 只认运行时实例ID，玩家填的配置ID（如 1020101002）根本不入表。
#            两处都错 ⇒ 查不到就静默返回（不报错、不落日志），正是「毫无反应」。
#    修法：两条各改 1 字节 00→01，对齐丹药路径。原址改动，无绝对地址（ASLR 安全）。
#    09-29 实测：修好后玩家在作弊面板手填这条指令能正常加武学经验。
#    ★ 依赖：平衡mod 的「丹药吃开局奖励加成」就是靠这条指令落库的，
#      关掉本项 = 指令恢复原版的坏样子 = 丹药补量一起失效（回到原版行为）。
#
#   ★ 本表与 install.ps1 里的 $SRV_PATCHES_CHET 必须逐项一致。
$PATCHES_CHET = @(
    @{ Off = 0x60E934; Orig = 'C644242800'; New = 'C644242801'; Note = '修 CHET_ADDMARTIALEXP 判据 0→1 @0x18060F534 [武学ID 按静态配置ID匹配，与丹药一致]' }
    @{ Off = 0x60E939; Orig = 'C644242000'; New = 'C644242001'; Note = '修 CHET_ADDMARTIALEXP 角色查找 0→1 @0x18060F539 [支持玩家填的角色配置ID]' }
)

# ★ 第五组：无视装备穿戴限制（安装器里对应开关 optimize.equipnolimit，★默认关）
#
#   需求：全局跳过装备的穿戴限制（等级 / 门派 / 角色专属 / 精通属性）。
#
#   ★ 为什么必须打服务端（2026-10-02 实测）：
#     客户端那半边（Lua 钩子放行了 ItemDataManager.CheckItemCondition）早就做完
#     并验证过了 —— 放行后 ★SendEquip 确实发了出去，但服务端**独立校验并静默驳回**：
#     无回包、无提示、就是穿不上。只改客户端没用，服务端这道闸门必须一起放。
#
#   ★ 服务端判定函数（反汇编实证）：BeRoleManager::_ItemUseConditionCheck
#       0x180494FC0  依次查 时限(dueTime) / 等级("[%s]needLevel=%d") /
#                    门派("[%s]needClan=%d") / 属性·精通("[%s]needAttrValue=[%d,%d]")
#     与客户端 ItemDataManager:CheckItemCondition 的四路一一对应（两套并存的手游遗留）。
#
#   ★ 装备链（VA）：
#       BeInstRole::EquipItem       0x180723D00
#         → BeRoleManager::EquipItem 0x18047FEA0
#             → 0x1804945E0  普通装备
#             → 0x180494000  物品类型 0xF 那一路（BeRoleManager::EquipItem 里 cmp eax,0xF 分流）
#     两条路都在"调用 _ItemUseConditionCheck"之后用 `jne` 判结果：失败即 return false。
#
#   ★ 改法：只把这两条 `jne` 改成 `jmp`（各 1 字节），＝"条件检查结果一律当通过"。
#     条件检查函数本身照跑（它只读数据 + 打日志，无副作用），其余逻辑一概不动。
#     原址改、无绝对地址（ASLR 安全）、不需要 cave —— 比动跳转目标安全得多。
#
#   ★ 本表与 install.ps1 里的 $SRV_PATCHES_ENL 必须逐项一致。
$PATCHES_ENL = @(
    @{ Off = 0x493A96; Orig = '7507'; New = 'EB07'; Note = '穿戴限制闸门1 @0x180494696 装备主路径(0x1804945E0)  jne→jmp [条件检查失败也放行]' }
    @{ Off = 0x49350A; Orig = '7507'; New = 'EB07'; Note = '穿戴限制闸门2 @0x18049410A 类型0xF路径(0x180494000)  jne→jmp [同上]' }
)

# ★ 第六组：无视秘籍学习限制（对应开关 optimize.learnnolimit，★默认关）
#
#   ★ 与第五组是**两个独立开关**（用户拍板）：装备穿戴限制 与 秘籍学习限制各管各的。
#
#   链路：BeMain 指令分发 → 0x180433030 → BeRoleManager::RoleLearnSecretBookMartial
#         0x180482460（串 "[RoleLearnSecretBookMartial]"）→ _ItemUseConditionCheck 0x180494FC0
#         → 调完用 `jne` 判结果，失败即 return false（客户端表现：学不了）。
#   客户端那半边：CharacterUI「学习」按钮 → ItemDataManager:ItemUseCondition 的
#         913 行**秘籍分支**（CheckMartialLearnConditionByType）→ 不满足就只弹
#         "不满足学习条件"，压根不发 SendRoleLearnSecretBookMartial。
#   ★ 客户端秘籍分支与装备分支是**两个不同的分支**（装备走 CheckItemCondition 四路，
#     秘籍走武学学习条件），所以必须各放一路，不能靠装备那个钩子顺带解决。
#
#   ★ 本表与 install.ps1 里的 $SRV_PATCHES_LNL 必须逐项一致。
$PATCHES_LNL = @(
    @{ Off = 0x481B35; Orig = '7507'; New = 'EB07'; Note = '秘籍学习闸门 @0x180482735 RoleLearnSecretBookMartial  jne→jmp [条件检查失败也放行]' }
)



# ★ 第七组：角色动态品质（对应开关 optimize.dynrank）
#
#   角色品质随等级抬升（方案 2：以游戏默认品质为底，等级超出则提升，只升不降）：
#     等级档 = min(7, 1 + floor(等级/5))  ⇒ 1-4白 / 5-9绿 / 10-14蓝 / 15-19紫 /
#                                           20-24橙 / 25-29金 / 30+暗金
#     原版五彩(8) / 三等暗金(9) 原样保留。
#
#   注入点 RankGetter 0x35CF70（唯一读 [obj+0x19C] 品质字段的 getter，78 处调用）：
#   入口 5 字节改 jmp 到 .text 末尾 0x180F68320 的 98 字节 cave。
#   ★ 依赖 $PATCHES_VSZ（cave 在原版 VirtualSize 之外，必须先抬映射区）。
#
#   ★ 本表与 install.ps1 里的 $SRV_PATCHES_DYN 必须逐项一致。
$PATCHES_DYN = @(
    @{ Off = 0x35C370; Orig = '48894C2408'; New = 'E9ABB3C000'; Note = '动态品质入口跳板 @0x18035CF70 RankGetter 前5字节改 jmp cave(0x180F68320)  [跳转点]' }
    @{ Off = 0x35C375; Orig = '488B4424088B809C010000C3'; New = 'CCCCCCCCCCCCCCCCCCCCCCCC'; Note = '动态品质入口跳板残余 12字节原指令(mov rax,[rsp+8]; mov eax,[rax+0x19C]; ret)填入 int3 —— cave 已复刻同样的取值逻辑并自带 ret' }
    @{ Off = 0xF67720; Orig = '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'; New = '48894C24088B819C01000083F801725183F809774C8B915801000083FA05724181FAC8000000773941B80100000041FFC083FA0A722341FFC083FA0F721B41FFC083FA14721341FFC083FA19720B41FFC083FA1E720341FFC04139C076034489C0C3'; Note = '动态品质 cave (98B) 位于 .text 末尾零区 0x180F68320：品质 = max(原品质, min(7, 1+floor(等级/5)))；护栏 等级5..200、原品质1..9，越界原样返回 [cave 代码]' }
)

# 本脚本一次性处理八组
$PATCHES_EX = @(
    @{ Off = 0x4E20E5; Orig = '0F8ED9000000'; New = 'E9DA00000090'; Note = '专属闸门  @BeMartialManager::AddMartial  jle→jmp  [放判定]' }
)

$PATCHES_WISH = @(
    @{ Off = 0x479357; Orig = '837C2444000F8603010000'; New = 'E926E4AE00CCCCCCCCCCCC'; Note = '心愿补足：仅允许新增模板496..502、ready状态、模板请求' }
    @{ Off = 0xF67782; Orig = '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'; New = '837C2444000F87D51B51FF83BC24C800000002755A80BC24D00000000074508B8424C00000003DF001000072423DF6010000773B448BC0488B8424B0000000488B4008488B48588B94245000000041B101E8A8D162FF85C07415894424448BD0488B4C2448E8E47555FFE9711B51FFE96F1C51FF'; Legacy = @('837C2444000F87D51B51FF83BC24C800000002755A80BC24D00000000074508B8424C00000003DF001000072423DF0010000773B448BC0488B8424B0000000488B4008488B48588B94245000000041B101E8A8D162FF85C07415894424448BD0488B4C2448E8E47555FFE9711B51FFE96F1C51FF','837C2444000F87D51B51FF83BC24C800000002755A83BC24D00000000074508B8424C00000003DF001000072423DF6010000773B448BC0488B8424B0000000488B4008488B48588B94245000000041B101E8A8D162FF85C07415894424448BD0488B4C2448E8E47555FFE9711B51FFE96F1C51FF','837C2444000F87D51B51FF83BC24C800000002755A83BC24D00000000074508B8424C00000003DF001000072423DF0010000773B448BC0488B8424B0000000488B4008488B48588B94245000000041B101E8A8D162FF85C07415894424448BD0488B4C2448E8E47555FFE9711B51FFE96F1C51FF'); Note = '心愿补足116字节cave，复用原版创建与角色登记' }
)

$ALL_PATCHES = $PATCHES + $PATCHES_CW + $PATCHES_VSZ + $PATCHES_BAL + $PATCHES_CHET + $PATCHES_ENL + $PATCHES_LNL + $PATCHES_DYN + $PATCHES_EX + $PATCHES_WISH

$ExitOk = 0
$ExitBad = 2

function Say([string]$s) { Write-Host $s }

function HexToBytes([string]$hex) {
    $h = $hex -replace '\s', ''
    $out = New-Object byte[] ($h.Length / 2)
    for ($i = 0; $i -lt $out.Length; $i++) {
        $out[$i] = [Convert]::ToByte($h.Substring($i * 2, 2), 16)
    }
    return , $out
}

# 从 $buf 的 $off 起取出 $n 字节，返回大写 hex 字符串
function GetHex([byte[]]$buf, [int]$off, [int]$n) {
    if ($off -lt 0 -or ($off + $n) -gt $buf.Length) { return '' }
    $sb = New-Object System.Text.StringBuilder
    for ($i = 0; $i -lt $n; $i++) { [void]$sb.Append($buf[$off + $i].ToString('X2')) }
    return $sb.ToString()
}

function Test-GameDir([string]$d) {
    if ([string]::IsNullOrWhiteSpace($d)) { return $false }
    if (-not (Test-Path -LiteralPath $d)) { return $false }
    return (Test-Path -LiteralPath (Join-Path $d 'DreamRivakes.exe'))
}

# 未传 -GameDir 时：从脚本所在目录逐级向上找含 DreamRivakes.exe 的目录
function Find-GameDir {
    $d = $PSScriptRoot
    for ($i = 0; $i -lt 5 -and $d; $i++) {
        if (Test-GameDir $d) { return $d }
        $parent = Split-Path -Parent $d
        if (-not $parent -or $parent -eq $d) { break }
        $d = $parent
    }
    return ''
}

# ---- 1) 解析游戏目录 ----
if (-not (Test-GameDir $GameDir)) {
    $auto = Find-GameDir
    if ($auto) {
        $GameDir = $auto
    } else {
        Say ''
        Say '  [X] 没有找到游戏主目录（那个里面有 DreamRivakes.exe 的 xiake 文件夹）。'
        Say '      请把本脚本放到游戏主目录里运行，或显式传入路径：'
        Say '        powershell -ExecutionPolicy Bypass -File patch_server.ps1 "D:\steamapps\common\xiake"'
        Say ''
        exit $ExitBad
    }
}

$dll = Join-Path $GameDir $DLL_REL
if (-not (Test-Path -LiteralPath $dll)) {
    Say ''
    Say ("  [X] 找不到 " + $DLL_REL)
    Say ("      游戏目录：" + $GameDir)
    Say ''
    exit $ExitBad
}

$bakDir = Join-Path $GameDir $BACKUP_NAME
if(-not $Check -or $Restore) {
    . (Join-Path $PSScriptRoot 'game_build.ps1')
    $buildProfile=Get-ShadowBuildContext $GameDir
    $bakDir=Join-Path $GameDir $buildProfile.BackupName
}
$bakDll = Join-Path $bakDir $BAK_FILE

# ---- 2) 还原模式 ----
if ($Restore) {
    Say ''
    Say '  === 服务端闸门补丁 · 还原 ==='
    if (-not (Test-Path -LiteralPath $bakDll)) {
        Say ("  [X] 没有备份，无法还原：" + $bakDll)
        Say '      若本机从未打过本补丁，就无需还原。'
        Say ''
        exit $ExitBad
    }
    Copy-Item -LiteralPath $bakDll -Destination $dll -Force
    Say ("  已还原 <- " + $bakDll)
    Say ''
    exit $ExitOk
}

# ---- 3) 读取并判定当前状态 ----
$buf = [System.IO.File]::ReadAllBytes($dll)

$states = @()
foreach ($p in $ALL_PATCHES) {
    $n = $p.Orig.Length / 2
    $cur = GetHex $buf $p.Off $n
    if ($cur -eq $p.Orig) {
        $st = 'orig'
    } elseif ($cur -eq $p.New) {
        $st = 'patched'
    } elseif ($p.ContainsKey('Legacy') -and (@($p.Legacy) -contains $cur)) {
        $st = 'orig'
    } else {
        $st = 'unknown'
    }
    $states += [pscustomobject]@{ P = $p; Cur = $cur; St = $st }
}

$nOrig = ($states | Where-Object { $_.St -eq 'orig' }).Count
$nPatched = ($states | Where-Object { $_.St -eq 'patched' }).Count
$nUnknown = ($states | Where-Object { $_.St -eq 'unknown' }).Count

Say ''
Say '  === 服务端闸门补丁 ==='
Say ("  游戏目录：" + $GameDir)
Say ("  目标文件：" + $DLL_REL)
Say ''

if ($Check) {
    foreach ($s in $states) {
        Say ("    {0}  {1}  {2}" -f ('0x' + $s.P.Off.ToString('X')), $s.St.PadRight(8), $s.P.Note)
    }
    Say ''
    if ($nUnknown -gt 0) {
        Say '  [!] 有字节对不上 —— 游戏版本可能不同，或 DLL 已被别的程序改过。'
        Say '      为安全起见不做任何改动。'
        Say ''
        exit $ExitBad
    }
    if ($nPatched -eq $ALL_PATCHES.Count) { Say '  状态：已打补丁';  Say ''; exit $ExitOk }
    if ($nOrig -eq $ALL_PATCHES.Count)    { Say '  状态：原版（尚未打补丁）'; Say ''; exit 0 }
    Say '  状态：部分已打 —— 建议先 -Restore 再重打'
    Say ''
    exit $ExitBad
}

if ($nUnknown -gt 0) {
    Say '  [X] 闸门里有字节对不上，已中止（不猜、不盲改）。'
    foreach ($s in ($states | Where-Object { $_.St -eq 'unknown' })) {
        Say ("      " + ('0x' + $s.P.Off.ToString('X')) + "  实际=" + $s.Cur + "  期望原始=" + $s.P.Orig)
    }
    Say ''
    Say '      常见原因：游戏版本不是本补丁对应的那一版；或 Steam 已还原过 / 别的工具改过。'
    Say ''
    exit $ExitBad
}

if ($nPatched -eq $ALL_PATCHES.Count) {
    Say '  闸门之前已经打过补丁 —— 跳过（幂等）。'
    Say ''
    exit $ExitOk
}

# ---- 4) 游戏是否在跑 ----
$proc = Get-Process -Name 'DreamRivakes' -ErrorAction SilentlyContinue
if ($proc) {
    Say '  [X] 检测到游戏正在运行 —— DLL 被占用，改不了。'
    Say '      请完全退出游戏后再运行本脚本。'
    Say ''
    exit $ExitBad
}

# ---- 5) 备份 ----
if (-not (Test-Path -LiteralPath $bakDir)) {
    New-Item -ItemType Directory -Path $bakDir -Force | Out-Null
}
if (Test-Path -LiteralPath $bakDll) {
    Say ("  原版备份已存在，保留最早那份：" + $bakDll)
} else {
    Copy-Item -LiteralPath $dll -Destination $bakDll -Force
    Say ("  已备份原版 -> " + $bakDll)
}

# ---- 6) 打补丁 ----
foreach ($s in $states) {
    if ($s.St -eq 'patched') { continue }   # 已经是补丁态，跳过（幂等，与安装器一致）
    $new = HexToBytes $s.P.New
    [Array]::Copy($new, 0, $buf, [int]$s.P.Off, $new.Length)
    Say ("    {0}  {1} -> {2}   {3}" -f ('0x' + $s.P.Off.ToString('X')), $s.P.Orig, $s.P.New, $s.P.Note)
}
[System.IO.File]::WriteAllBytes($dll, $buf)

# ---- 7) 回读校验 ----
$chk = [System.IO.File]::ReadAllBytes($dll)
$bad = 0
foreach ($p in $ALL_PATCHES) {
    $cur = GetHex $chk $p.Off ($p.New.Length / 2)
    if ($cur -ne $p.New) { $bad++ }
}
Say ''
if ($bad -eq 0) {
    Say '  [OK] 补丁已写入并回读校验通过'
    Say '       注意：Steam「验证文件完整性」会还原它，之后需重跑本脚本。'
    Say ''
    exit $ExitOk
} else {
    Say ("  [X] 写入后校验失败（" + $bad + " 处不符），请用 -Restore 还原。")
    Say ''
    exit $ExitBad
}
