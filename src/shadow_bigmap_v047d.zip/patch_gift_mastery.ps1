function Update-GiftMastery([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    return ,(Update-ClanTalentTable $Data 'Gift' $Enabled $ResourceDir 'gift_mastery_tables.json')
}
