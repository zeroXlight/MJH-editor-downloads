﻿# =====================================================================
#  梦江湖 MOD · 「新建角色词条优化」补丁器（零依赖，仅用 Windows 自带 PowerShell）
#
#  要什么效果
#  ---------------------------------------------------------------
#  新建角色时随机到的天赋（词条）**不再出现橙色以下** —— 也就是白色 / 绿色 /
#  蓝色 / 紫色那几档从随机池里去掉，只留橙、金、暗金。
#
#  表在哪、怎么用
#  ---------------------------------------------------------------
#  `TableData/RoleGiftpool.bytes` —— 天赋随机池。Lua 侧**没有任何文件引用它**
#  （`grep RoleGiftpool` 全项目零命中），说明这是**原生 / 服务端**读的表，
#  改 .bytes 才生效（铁律1：表两套互不相通）。
#
#  池结构（已逐字节核对，与 `references/_lua_full/RoleGiftpool.lua` 完全对齐）
#  ---------------------------------------------------------------
#  文件是**列式 protobuf**（无文件头）：
#      field 1 (varint) × 173  —— 每一行的 BaseID，连续排在最前面
#      field 2 (bytes)  × 173  —— 每一行的行数据（子消息），顺序与 BaseID 一一对应
#      field 3 (bytes)  × 1    —— 表自带的 md5 串（原版补丁器也不动它，见 patch_table.ps1）
#  行内子消息的字段号：
#      field 1 = BaseID    field 2 = GiftType    field 3 = ClanID
#      field 7 = Weight    field 8 = GiftIDs（unpacked repeated varint）
#
#  `GiftType == 1` 就是 `GiftPoolType.GPT_CreatRole`（新建角色池），共 8 条，
#  每条**正好一个品质档**，Weight 越大越常见：
#      BaseID 161 Weight 100  白   ×6       ★ 本次归零
#      BaseID 162 Weight  90  绿   ×2       ★ 本次归零
#      BaseID 163 Weight  80  橙   ×6
#      BaseID 164 Weight  70  蓝   ×2       ★ 本次归零
#      BaseID 165 Weight  60  橙   ×1
#      BaseID 178 Weight  50  金   ×2
#      BaseID 179 Weight  10  暗金 ×3   （Gift 表没写 Rank → 走 GiftDefault = RT_DarkGolden）
#      BaseID 180 Weight   3  暗金 ×11
#  （紫色那一档在新建角色池里本来就没有条目，所以不用管）
#
#  为什么改 Weight 而不是删行
#  ---------------------------------------------------------------
#  ★ 列式存储下"删一行"要同步删掉**每一列**对应位置的元素，牵一发动全身；
#    而把权重置 0 是**原址改 1 个字节**（100/90/70 都是单字节 varint），
#    文件长度不变、结构不变，加权抽取时权重 0 的档永远抽不中 —— 效果等价、风险最小。
#    （这是用户 09-29 拍板的做法。）
#
#  设计要点
#  ---------------------------------------------------------------
#    * 幂等：已经归零过再跑一次不会产生任何字节变化。
#    * 自校验：改写后重新解析一遍，只有确认三条 Weight 全为 0 才允许落盘。
#    * 只动目标行：BaseID + GiftType 双重定位，绝不误伤其它池。
# =====================================================================

Set-StrictMode -Version 2.0

# 目标：新建角色池(GiftType=1) 里这三档的权重归零
$SCRIPT:GP_GIFTTYPE = 1
$SCRIPT:GP_TARGETS = @(161, 162, 164)

function Read-VarintGP {
    param([byte[]]$Buf, [ref]$Pos)
    [long]$n = 0
    [int]$s = 0
    while ($true) {
        if ($Pos.Value -ge $Buf.Length) { throw 'varint 读到文件末尾' }
        [int]$b = [int]$Buf[$Pos.Value]
        $Pos.Value = $Pos.Value + 1
        $n = $n -bor ([long]($b -band 0x7F) -shl $s)
        if (($b -band 0x80) -eq 0) { return $n }
        $s = $s + 7
    }
}

# 解析列式结构，返回 @{ Bases = <BaseID 数组>; Rows = <每行 [起始, 长度]> }
function Split-GiftPool {
    param([byte[]]$Data)
    $bases = New-Object System.Collections.ArrayList
    $rows  = New-Object System.Collections.ArrayList
    [int]$i = 0
    while ($i -lt $Data.Length) {
        [int]$p = $i
        [long]$key = Read-VarintGP $Data ([ref]$i)
        [int]$fn = [int]($key -shr 3)
        [int]$wt = [int]($key -band 7)
        if ($wt -eq 0) {
            [long]$v = Read-VarintGP $Data ([ref]$i)
            if ($fn -eq 1) { [void]$bases.Add([int]$v) }
        }
        elseif ($wt -eq 2) {
            [long]$len = Read-VarintGP $Data ([ref]$i)
            if ($fn -eq 2) { [void]$rows.Add(@($i, [int]$len)) }
            $i = $i + [int]$len
        }
        elseif ($wt -eq 5) { $i = $i + 4 }
        elseif ($wt -eq 1) { $i = $i + 8 }
        else { throw ("偏移 {0} 处出现非法 wiretype {1}，文件可能不是 RoleGiftpool.bytes" -f $p, $wt) }
    }
    if ($bases.Count -ne $rows.Count) {
        throw ('BaseID 列({0}) 与行数据列({1}) 数量不一致，文件结构异常' -f $bases.Count, $rows.Count)
    }
    return @{ Bases = $bases.ToArray(); Rows = $rows.ToArray() }
}

# 在一行里找 field 7(Weight) 的值起始偏移；顺带读出 field 2(GiftType)
function Scan-GiftPoolRow {
    param([byte[]]$Data, [int]$Start, [int]$Len)
    [int]$j = $Start
    [int]$end = $Start + $Len
    $giftType = $null
    $wPos = $null
    $wVal = $null
    while ($j -lt $end) {
        [int]$fp = $j
        [long]$k = Read-VarintGP $Data ([ref]$j)
        [int]$f = [int]($k -shr 3)
        [int]$w = [int]($k -band 7)
        if ($w -eq 0) {
            [int]$vp = $j
            [long]$v = Read-VarintGP $Data ([ref]$j)
            if ($f -eq 2) { $giftType = [int]$v }
            if ($f -eq 7) { $wPos = $vp; $wVal = [int]$v }
        }
        elseif ($w -eq 2) {
            [long]$l = Read-VarintGP $Data ([ref]$j)
            $j = $j + [int]$l
        }
        elseif ($w -eq 5) { $j = $j + 4 }
        elseif ($w -eq 1) { $j = $j + 8 }
        else { throw ("行内偏移 {0} 出现非法 wiretype {1}" -f $fp, $w) }
    }
    return @{ GiftType = $giftType; WeightPos = $wPos; Weight = $wVal }
}

# 收集本次要改的字节位置（BaseID + GiftType 双重匹配）
function Get-GiftPoolPlan {
    param([byte[]]$Data)
    $sp = Split-GiftPool $Data
    $plan = New-Object System.Collections.ArrayList
    for ([int]$n = 0; $n -lt $sp.Bases.Length; $n++) {
        [int]$bid = [int]$sp.Bases[$n]
        if ($SCRIPT:GP_TARGETS -notcontains $bid) { continue }
        $r = $sp.Rows[$n]
        $info = Scan-GiftPoolRow $Data ([int]$r[0]) ([int]$r[1])
        if ($info.GiftType -ne $SCRIPT:GP_GIFTTYPE) {
            throw ('BaseID {0} 的 GiftType={1}，不是新建角色池(期望 {2})，已放弃' -f $bid, $info.GiftType, $SCRIPT:GP_GIFTTYPE)
        }
        if ($info.WeightPos -eq $null) { throw ('BaseID {0} 找不到 Weight 字段' -f $bid) }
        [void]$plan.Add(@{ BaseID = $bid; Pos = [int]$info.WeightPos; Old = [int]$info.Weight })
    }
    if ($plan.Count -ne $SCRIPT:GP_TARGETS.Length) {
        throw ('只找到 {0} 条目标行（期望 {1} 条），已放弃' -f $plan.Count, $SCRIPT:GP_TARGETS.Length)
    }
    return @{ Split = $sp; Plan = $plan.ToArray() }
}

# 状态：'original'（三条都有非 0 权重）/ 'patched'（三条都已归零）/ 'mixed' / 'unknown'
function Get-GiftPoolState {
    param([byte[]]$Data)
    try {
        $g = Get-GiftPoolPlan $Data
    } catch {
        return @{ State = 'unknown'; Zero = 0; Total = 0; Note = $_.Exception.Message }
    }
    [int]$zero = 0
    foreach ($p in $g.Plan) { if ($p.Old -eq 0) { $zero = $zero + 1 } }
    [int]$total = $g.Plan.Count
    if ($zero -eq 0) { return @{ State = 'original'; Zero = 0; Total = $total; Note = '' } }
    if ($zero -eq $total) { return @{ State = 'patched'; Zero = $zero; Total = $total; Note = '' } }
    return @{ State = 'mixed'; Zero = $zero; Total = $total; Note = '部分权重已归零' }
}

# 执行改写：把三条的 Weight 字节置 0（单字节 varint，原址改写，长度不变）
function Apply-GiftPool {
    param([byte[]]$Data)
    $g = Get-GiftPoolPlan $Data
    $out = New-Object 'byte[]' $Data.Length
    [System.Array]::Copy($Data, $out, $Data.Length)
    [int]$changed = 0
    foreach ($p in $g.Plan) {
        if ($p.Old -ne 0) {
            if ($out[$p.Pos] -band 0x80) { throw ('BaseID {0} 的 Weight 是多字节 varint，本补丁不支持' -f $p.BaseID) }
            $out[$p.Pos] = 0
            $changed = $changed + 1
        }
    }
    # 自校验：重新解析一遍，必须三条全 0
    $st = Get-GiftPoolState $out
    if ($st.State -ne 'patched') {
        throw ('自校验失败：改写后仍有 {0}/{1} 条权重非 0，已放弃' -f ($st.Total - $st.Zero), $st.Total)
    }
    return @{ Bytes = $out; Changed = $changed; Total = $g.Plan.Count }
}
