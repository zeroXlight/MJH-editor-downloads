using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;
public static class ShadowWishCandidateStore {
 static uint R(byte[] b,int o){return BitConverter.ToUInt32(b,o);}
 static void W(byte[] b,int o,uint v){Buffer.BlockCopy(BitConverter.GetBytes(v),0,b,o,4);}
 static int A(int n,int a){return checked((n+a-1)/a*a);}
 static byte[] S(byte[] b,int o,int n){byte[] r=new byte[n];Buffer.BlockCopy(b,o,r,0,n);return r;}
 static bool Eq(byte[] a,byte[] b){if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true;}
 static void C(bool ok,string s){if(!ok)throw new InvalidDataException("Wish store: "+s);}
 static int O(byte[] b,int r){int pe=(int)R(b,60),t=pe+24+BitConverter.ToUInt16(b,pe+20),n=BitConverter.ToUInt16(b,pe+6);for(int i=0;i<n;i++){int h=t+i*40,v=(int)R(b,h+12),z=Math.Max((int)R(b,h+8),(int)R(b,h+16));if(r>=v&&r<v+z)return (int)R(b,h+20)+r-v;}throw new InvalidDataException("Unmapped RVA");}
 static byte[] Code(byte[] v,int r,int[] os,int[] ts,int[] ls){byte[] b=(byte[])v.Clone();for(int i=0;i<os.Length;i++)W(b,os[i],unchecked((uint)(ts[i]+(ls[i]!=0?r:0)-r-os[i]-4)));return b;}
 static byte[] Jump(int a,int b){byte[] v={232,0,0,0,0};W(v,1,unchecked((uint)(b-a-5)));return v;}
 public static byte[] Update(byte[] input,bool on,byte[] code,int[] ro,int[] rt,int[] rl,int[] hooks,byte[][] orig,int[] he,int[] begins,int[] ends,byte[] uw,int[] pr,byte[][] po,byte[][] pn,int[] gr,int[] gs,string[] gh){
 byte[] b=(byte[])input.Clone();int pe=(int)R(b,60),opt=pe+24,t=opt+BitConverter.ToUInt16(b,pe+20),n=BitConverter.ToUInt16(b,pe+6),h=t+(n-1)*40;
 C(R(b,pe)==0x4550&&BitConverter.ToUInt16(b,pe+4)==0x8664&&BitConverter.ToUInt16(b,opt)==0x20b,"unsupported PE");
 C(hooks.Length==1&&he[0]==0&&begins.Length==1&&pr.Length==0,"unsupported template");
 int hook=O(b,hooks[0]);
 if(!Eq(S(b,hook,5),orig[0])){
 C(b[hook]==232,"unknown hook");int r=hooks[0]+5+BitConverter.ToInt32(b,hook+1),raw=O(b,r);
 C(raw+0x1000<=b.Length&&Encoding.ASCII.GetString(b,raw+0xa00,8)=="WISHNAT1","unknown owner");
 C(Eq(S(b,raw,code.Length),Code(code,r,ro,rt,rl)),"unknown installed code");
 int len=(int)R(b,raw+0xa08);uint image=R(b,raw+0xa0c),ex=R(b,raw+0xa10),esz=R(b,raw+0xa14),vs=R(b,raw+0xa18),rs=R(b,raw+0xa1c),sum=R(b,raw+0xa20),ch=R(b,raw+0xa24);
 C(len==R(b,h+20)+rs&&r>=R(b,h+12)+Math.Max(vs,rs)&&b.Length==R(b,h+20)+R(b,h+16),"parent changed");
 C(R(b,opt+136)==r+0x1000&&R(b,opt+140)==esz+12,"exception directory changed");
 C(Eq(S(b,raw+0x1000,(int)esz),S(b,O(b,(int)ex),(int)esz)),"parent unwind changed");
 C(Eq(S(b,raw+0x980,uw.Length),uw),"shim unwind changed");
 C(R(b,raw+0x1000+(int)esz)==r&&R(b,raw+0x1000+(int)esz+4)==r+ends[0]&&R(b,raw+0x1000+(int)esz+8)==r+0x980,"shim pdata changed");
 Buffer.BlockCopy(orig[0],0,b,hook,5);W(b,h+8,vs);W(b,h+16,rs);W(b,h+36,ch);W(b,opt+56,image);W(b,opt+136,ex);W(b,opt+140,esz);W(b,opt+64,sum);Array.Resize(ref b,len);
 }
 if(!on)return b;
 C(Eq(S(b,O(b,hooks[0]),5),orig[0]),"unknown original hook");
 using(SHA256 sha=SHA256.Create())for(int i=0;i<gr.Length;i++)C(BitConverter.ToString(sha.ComputeHash(b,O(b,gr[i]),gs[i])).Replace("-","").ToLowerInvariant()==gh[i],"original function changed");
 int oldLen=b.Length,rawStart=(int)R(b,h+20),local=A(Math.Max((int)R(b,h+8),(int)R(b,h+16)),4096),rva=(int)R(b,h+12)+local,rawCode=rawStart+local;
 uint exR=R(b,opt+136),exSize=R(b,opt+140);byte[] pdata=S(b,O(b,(int)exR),(int)exSize);
 C(exSize%12==0&&oldLen==rawStart+R(b,h+16),"unexpected overlay/pdata");
 C(exSize==0||R(pdata,pdata.Length-12)<rva,"pdata is not sorted");
 int used=local+0x1000+pdata.Length+12,rawSize=A(used,(int)R(b,opt+36));byte[] outb=new byte[rawStart+rawSize];Buffer.BlockCopy(b,0,outb,0,b.Length);
 Buffer.BlockCopy(Code(code,rva,ro,rt,rl),0,outb,rawCode,code.Length);Buffer.BlockCopy(uw,0,outb,rawCode+0x980,uw.Length);
 Buffer.BlockCopy(Encoding.ASCII.GetBytes("WISHNAT1"),0,outb,rawCode+0xa00,8);
 uint[] meta={(uint)oldLen,R(b,opt+56),exR,exSize,R(b,h+8),R(b,h+16),R(b,opt+64),R(b,h+36)};
 for(int i=0;i<meta.Length;i++)W(outb,rawCode+0xa08+i*4,meta[i]);
 Buffer.BlockCopy(pdata,0,outb,rawCode+0x1000,pdata.Length);int e=rawCode+0x1000+pdata.Length;W(outb,e,(uint)rva);W(outb,e+4,(uint)(rva+ends[0]));W(outb,e+8,(uint)(rva+0x980));
 W(outb,h+8,(uint)used);W(outb,h+16,(uint)rawSize);W(outb,h+36,(R(b,h+36)|0x60000020)&~0x02000000u);
 W(outb,opt+56,(uint)A((int)R(b,h+12)+used,(int)R(b,opt+32)));W(outb,opt+136,(uint)(rva+0x1000));W(outb,opt+140,exSize+12);W(outb,opt+64,0);
 Buffer.BlockCopy(Jump(hooks[0],rva),0,outb,O(outb,hooks[0]),5);return outb;
 }
}
