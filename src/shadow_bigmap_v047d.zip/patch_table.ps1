﻿# 专属元数据只读核验工具。Exclusive 同时供参悟读取，禁止删除。
# 可 dot-source 复用解析/统计函数，或用 -Path <文件> -CountOnly 查询。
# 旧的清空调用明确报错，防止旧安装流程重新破坏 Martial.bytes。
param(
    [string]$Path = '',
    [string]$Output = '',
    [string]$FieldName = 'Exclusive',
    [switch]$CountOnly,
    [switch]$Quiet
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# Exclusive 在 Martial 表里的 protobuf 字段号（由逆向确定，见项目文档）
$SCRIPT:EXCL_FIELD = 20

function Get-Varint {
    param([byte[]]$Buf, [ref]$Pos)
    [long]$n = 0
    [int]$s = 0
    while ($true) {
        if ($Pos.Value -ge $Buf.Length) { throw 'varint 读到文件末尾' }
        [int]$b = [int]$Buf[$Pos.Value]
        $Pos.Value = $Pos.Value + 1
        $n = $n -bor ([long]($b -band 0x7F) -shl $s)
        if (($b -band 0x80) -eq 0) { return $n }
        $s = $s + 7
        if ($s -gt 63) { throw 'varint 过长(>10 字节)，文件可能不是该表' }
    }
}

function Add-Varint {
    param([System.Collections.Generic.List[byte]]$Out, [long]$N)
    if ($N -lt 0) { throw 'varint 不接受负数' }
    while ($true) {
        [int]$b = [int]($N -band 0x7F)
        $N = $N -shr 7
        if ($N -ne 0) { $Out.Add([byte]($b -bor 0x80)) }
        else { $Out.Add([byte]$b); break }
    }
}

function Skip-Value {
    # 读完当前字段的值，$Pos 停在字段末尾
    param([byte[]]$Buf, [ref]$Pos, [int]$WireType, [int]$At)
    switch ($WireType) {
        0 { [void](Get-Varint $Buf $Pos) }
        1 { $Pos.Value = $Pos.Value + 8 }
        2 { [long]$ln = Get-Varint $Buf $Pos; $Pos.Value = $Pos.Value + [int]$ln }
        5 { $Pos.Value = $Pos.Value + 4 }
        default { throw ("偏移 $At 处出现非法 wiretype $WireType，文件可能不是该表") }
    }
}

function Get-FieldSpans {
    # 解析 [$Start,$End) 区间，返回字段区间清单（不复制字节）
    param([byte[]]$Buf, [int]$Start, [int]$End)
    $list = New-Object 'System.Collections.Generic.List[object]'
    [int]$i = $Start
    while ($i -lt $End) {
        [int]$fs = $i
        [long]$key = Get-Varint $Buf ([ref]$i)
        [int]$f = [int]($key -shr 3)
        [int]$wt = [int]($key -band 7)
        Skip-Value $Buf ([ref]$i) $wt $fs
        if ($i -gt $End) { throw ("偏移 $fs 处字段越过了所属记录边界") }
        $list.Add([pscustomobject]@{ Field = $f; WireType = $wt; Start = $fs; End = $i })
    }
    return , $list
}

function Get-ExclusiveRowCount {
    # 返回"Exclusive 字段非空的行数"
    param([byte[]]$Data, [int]$Field = $SCRIPT:EXCL_FIELD)
    [int]$n = 0
    [int]$i = 0
    [int]$len = $Data.Length
    while ($i -lt $len) {
        [int]$fs = $i
        [long]$key = Get-Varint $Data ([ref]$i)
        [int]$f = [int]($key -shr 3)
        [int]$wt = [int]($key -band 7)
        if ($f -eq 2 -and $wt -eq 2) {
            [long]$ln = Get-Varint $Data ([ref]$i)
            [int]$vs = $i
            [int]$ve = $i + [int]$ln
            $i = $ve
            foreach ($it in (Get-FieldSpans $Data $vs $ve)) {
                if ($it.Field -eq $Field) { $n = $n + 1; break }
            }
        }
        else {
            Skip-Value $Data ([ref]$i) $wt $fs
        }
    }
    return $n
}

function Test-ExclusiveSamples {
    # 旧安装器整表删除字段20；仅抽查重阳神剑/江晖剑，不统计整表。
    param([byte[]]$Data)
    $found = @{}
    [int]$i = 0
    while ($i -lt $Data.Length) {
        [int]$at = $i
        [long]$key = Get-Varint $Data ([ref]$i)
        if ($key -ne 18) {
            Skip-Value $Data ([ref]$i) ([int]($key -band 7)) $at
            continue
        }
        [long]$size = Get-Varint $Data ([ref]$i)
        [int]$end = $i + [int]$size
        if ($end -gt $Data.Length -or $end -lt $i) { throw '武学记录越界' }
        # 原版记录以字段1的武学ID开头，其他记录直接跳过。
        [int]$pos = $i
        [long]$idKey = Get-Varint $Data ([ref]$pos)
        if ($idKey -ne 8) { throw '武学记录ID格式不符，停止抽查' }
        [long]$id = Get-Varint $Data ([ref]$pos)
        if ($id -eq 10811 -or $id -eq 51201) {
            $present = $false
            while ($pos -lt $end) {
                [int]$fieldAt = $pos
                [long]$fieldKey = Get-Varint $Data ([ref]$pos)
                if ($fieldKey -eq 160) {
                    $present = (Get-Varint $Data ([ref]$pos)) -gt 0
                    break
                }
                Skip-Value $Data ([ref]$pos) ([int]($fieldKey -band 7)) $fieldAt
                if ($pos -gt $end) { throw '抽查字段越界' }
            }
            $found[$id] = $present
            if ($found.Count -eq 2) { return ($found[10811L] -and $found[51201L]) }
        }
        $i = $end
    }
    throw '未找到重阳神剑或江晖剑，无法判断旧版专属数据状态'
}

function Get-TableRowCount {
    param([byte[]]$Data)
    [int]$n = 0
    [int]$i = 0
    [int]$len = $Data.Length
    while ($i -lt $len) {
        [int]$fs = $i
        [long]$key = Get-Varint $Data ([ref]$i)
        [int]$f = [int]($key -shr 3)
        [int]$wt = [int]($key -band 7)
        if ($f -eq 2 -and $wt -eq 2) {
            [long]$ln = Get-Varint $Data ([ref]$i)
            $i = $i + [int]$ln
            $n = $n + 1
        }
        else { Skip-Value $Data ([ref]$i) $wt $fs }
    }
    return $n
}

function Remove-Exclusive {
    param([byte[]]$Data, [int]$Field = $SCRIPT:EXCL_FIELD)
    throw '已禁用清空 Exclusive：该操作会破坏参悟所需元数据。请使用新版安装器恢复专属数据并仅放行归属检查。'
}

# ---------------------------------------------------------------- 命令行入口
if ($Path -ne '') {
    if (-not (Test-Path -LiteralPath $Path)) { throw "找不到文件: $Path" }
    $data = [System.IO.File]::ReadAllBytes($Path)

    $before = Get-ExclusiveRowCount $data
    $rows = Get-TableRowCount $data
    if (-not $Quiet) {
        Write-Host ("文件      : {0}" -f $Path)
        Write-Host ("大小      : {0} 字节" -f $data.Length)
        Write-Host ("记录数    : {0}" -f $rows)
        Write-Host ("{0} 非空行 : {1}" -f $FieldName, $before)
    }

    if ($CountOnly) {
        # 给调用方读的机器可读结果
        Write-Output ("COUNT={0}" -f $before)
        exit 0
    }

    throw '此工具仅支持只读核验，请使用 -CountOnly；专属解禁与数据恢复由新版 install.ps1 处理。'
}
