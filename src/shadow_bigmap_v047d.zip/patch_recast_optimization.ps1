﻿# Reforge weights use vanilla value ranges; changes are exactly reversible.
. (Join-Path $PSScriptRoot 'patch_fragment.ps1')
function Update-RecastPercentPool([byte[]]$Data,[bool]$Enabled) {
    # Scale: player-facing weight 1 = 100000 native units.
    $percentTypes=@(36,37,38,40,41,42,43,45,46,47,48,49,50)
    $weights=@{17=5000000;18=5000000;53=5000000;54=5000000;
        30=2000000;33=2000000;31=2000000;64=2000000;32=2000000;65=2000000;35=2000000;39=3000000;70=3000000;71=3000000;
        36=3000000;37=3000000;38=3000000;40=3000000;41=3000000;42=3000000;
        43=3000000;45=3000000;46=3000000;47=3000000;48=3000000;49=3000000;50=3000000}
    foreach($attr in 56..61) {$weights[$attr]=1000000}
    $types=@($weights.Keys)
    $seen=@{};$rowSeen=$false;$out=New-Object 'System.Collections.Generic.List[byte]';$cursor=0
    foreach($f in (Read-FragmentFields $Data 0 $Data.Length)) {
        if($f.F -eq 2 -and $f.W -eq 2) {
            $fields=Read-FragmentFields $Data $f.Start $f.End
            $id=@($fields | Where-Object {$_.F -eq 1 -and $_.W -eq 0})
            if($id.Count -ne 1) {throw 'Unsupported ItemRecastAttrGen row'}
            if($id[0].V -ne 1) {$out.AddRange([byte[]]$Data[$cursor..($f.End-1)]);$cursor=$f.End;continue}
            if($rowSeen) {throw 'Duplicate default ItemRecastAttrGen row'}
            $rowSeen=$true;$row=New-Object 'System.Collections.Generic.List[byte]';$p=$f.Start
            foreach($r in $fields) {
                $replace=$false
                if($r.F -eq 10 -and $r.W -eq 2) {
                    $values=@{};$nested=Read-FragmentFields $Data $r.Start $r.End
                    foreach($n in $nested) {
                        if($n.W -ne 0 -or $n.F -notin @(1,2) -or $values.ContainsKey($n.F)) {throw 'Unsupported reforge weight record'}
                        $values[$n.F]=$n.V
                    }
                    if(-not $values.ContainsKey(1)) {throw 'Missing reforge attribute type'}
                    $attr=[int]$values[1]
                    if($attr -in $types) {
                        if($seen.ContainsKey($attr)) {throw 'Duplicate reforge percentage attribute'}
                        $seen[$attr]=$true
                        $originalWeight=10000000
                        if($attr -in $percentTypes -or $attr -in @(35,39,53,56,57,58,59,60,61,70,71)) {$originalWeight=0}
                        if($attr -eq 65) {$originalWeight=2000000}
                        $legacyWeight=$originalWeight
                        if($attr -in $percentTypes) {$legacyWeight=10000000}
                        $currentWeight=0;if($values.ContainsKey(2)) {$currentWeight=$values[2]}
                        if($currentWeight -notin @($originalWeight,$legacyWeight,$weights[$attr])) {
                            # Preserve independent editor/player weight changes.
                            $row.AddRange([byte[]]$Data[$p..($r.End-1)])
                            $p=$r.End
                            continue
                        }
                        $entry=New-Object 'System.Collections.Generic.List[byte]'
                        $entry.Add(8);Add-FragmentExtraVar $entry $attr
                        $targetWeight=$originalWeight
                        if($Enabled) {$targetWeight=$weights[$attr]}
                        if($targetWeight -ne 0) {$entry.Add(16);Add-FragmentExtraVar $entry $targetWeight}
                        $row.Add(82);Add-FragmentExtraVar $row $entry.Count;$row.AddRange($entry.ToArray());$replace=$true
                    }
                }
                if(-not $replace) {$row.AddRange([byte[]]$Data[$p..($r.End-1)])}
                $p=$r.End
            }
            $out.Add(18);Add-FragmentExtraVar $out $row.Count;$out.AddRange($row.ToArray())
        } else {$out.AddRange([byte[]]$Data[$cursor..($f.End-1)])}
        $cursor=$f.End
    }
    if(-not $rowSeen -or $seen.Count -ne $types.Count) {throw 'Incomplete reforge percentage pool'}
    return ,$out.ToArray()
}

function Convert-RecastHex([string]$Hex) {
    [byte[]]$bytes=New-Object byte[] ($Hex.Length/2)
    for($i=0;$i -lt $bytes.Length;$i++) {$bytes[$i]=[Convert]::ToByte($Hex.Substring($i*2,2),16)}
    return ,$bytes
}
function Update-RecastRanges([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    $specs=[IO.File]::ReadAllText((Join-Path $ResourceDir 'recast_ranges.json'),[Text.Encoding]::UTF8)|ConvertFrom-Json
    $byAttr=@{};$byId=@{};$found=@{};$remove=@{};$replace=@{};$migrate=@{}
    foreach($s in $specs) {$byAttr[[int]$s.attr]=$s;$byId[[int]$s.id]=$s}
    $top=Read-FragmentFields $Data 0 $Data.Length
    $cursor=0
    foreach($f in $top) {
        if($f.F -eq 2 -and $f.W -eq 2) {
            $fields=Read-FragmentFields $Data $f.Start $f.End
            $id=@($fields|Where-Object {$_.F -eq 1 -and $_.W -eq 0})
            $attr=@($fields|Where-Object {$_.F -eq 2 -and $_.W -eq 0})
            if($id.Count -ne 1) {throw 'Invalid reforge range row ID'}
            if($attr.Count -eq 1 -and $byAttr.ContainsKey([int]$attr[0].V)) {
                $s=$byAttr[[int]$attr[0].V]
                if($found.ContainsKey([int]$s.attr)) {throw 'Duplicate reforge attribute range'}
                $found[[int]$s.attr]=$true
                $rowHex=[BitConverter]::ToString($Data,$f.Start,$f.End-$f.Start).Replace('-','')
                if($s.original -eq '') {
                    # Remove only our exact added row; preserve later editor changes.
                    $legacy=$s.PSObject.Properties['legacy'] -and $s.legacy -and $rowHex -eq $s.legacy
                    if(-not $Enabled -and (($id[0].V -eq $s.id -and $rowHex -eq $s.patched) -or $legacy)) {$remove[[int]$id[0].V]=$true}
                    elseif($Enabled -and $legacy) {
                        $replace[$cursor]=Convert-RecastHex $s.patched
                        $migrate[[int]$id[0].V]=[int]$s.id
                    }
                } else {
                    $range=New-Object 'System.Collections.Generic.List[byte]';$p=$f.Start
                    foreach($v in $fields) {
                        if($v.F -in @(4,5)) {$range.AddRange([byte[]]$Data[$p..($v.End-1)])}
                        $p=$v.End
                    }
                    $rangeHex=[BitConverter]::ToString($range.ToArray()).Replace('-','')
                    if($rangeHex -eq $s.originalRange -or $rangeHex -eq $s.patchedRange) {
                        $target=if($Enabled) {$s.patchedRange} else {$s.originalRange}
                        $row=New-Object 'System.Collections.Generic.List[byte]';$p=$f.Start;$inserted=$false
                        foreach($v in $fields) {
                            if($v.F -in @(4,5)) {
                                if(-not $inserted) {$row.AddRange((Convert-RecastHex $target));$inserted=$true}
                            } else {$row.AddRange([byte[]]$Data[$p..($v.End-1)])}
                            $p=$v.End
                        }
                        $replace[$cursor]=$row.ToArray()
                    }
                }
            }
        }
        $cursor=$f.End
    }
    # Added IDs must not collide with any external row or orphaned key.
    foreach($f in $top) {
        if($f.F -eq 1 -and $f.W -eq 0 -and [int]$f.V -in @($migrate.Values)) {throw 'Reforge range migration ID collision'}
        if($f.F -eq 1 -and $f.W -eq 0 -and $byId.ContainsKey([int]$f.V)) {
            $s=$byId[[int]$f.V]
            if($Enabled -and $s.original -eq '' -and -not $found.ContainsKey([int]$s.attr)) {throw 'Custom reforge range ID collision'}
        }
    }
    $out=New-Object 'System.Collections.Generic.List[byte]';$cursor=0
    foreach($f in $top) {
        $drop=$false
        if($f.F -eq 1 -and $f.W -eq 0 -and $remove.ContainsKey([int]$f.V)) {$drop=$true}
        if($f.F -eq 2 -and $f.W -eq 2) {
            $id=@((Read-FragmentFields $Data $f.Start $f.End)|Where-Object {$_.F -eq 1 -and $_.W -eq 0})
            if($remove.ContainsKey([int]$id[0].V)) {$drop=$true}
        }
        if(-not $drop) {
            if($f.F -eq 1 -and $f.W -eq 0 -and $migrate.ContainsKey([int]$f.V)) {
                $out.Add(8);Add-FragmentExtraVar $out $migrate[[int]$f.V]
            } elseif($replace.ContainsKey($cursor)) {
                [byte[]]$row=$replace[$cursor];$out.Add(18);Add-FragmentExtraVar $out $row.Length;$out.AddRange($row)
            } else {$out.AddRange([byte[]]$Data[$cursor..($f.End-1)])}
        }
        $cursor=$f.End
    }
    if($Enabled) {
        foreach($s in $specs) {
            if($s.original -eq '' -and -not $found.ContainsKey([int]$s.attr)) {
                [byte[]]$row=Convert-RecastHex $s.patched
                $out.Add(8);Add-FragmentExtraVar $out $s.id
                $out.Add(18);Add-FragmentExtraVar $out $row.Length;$out.AddRange($row)
            }
        }
    }
    return ,$out.ToArray()
}

function Update-RecastOptimization([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    . (Join-Path $ResourceDir 'game_build.ps1')
    if((Get-ShadowGameBuild $Data).Family -eq 'classic') {
        . (Join-Path $ResourceDir 'patch_equal_layout.ps1')
        return ,(Update-ShadowEqualLayout $Data $Enabled (Get-ShadowNativeLayoutPath $Data $ResourceDir 'recast_optimization_layout.json'))
    }
    $offset=0x30bcf3;$size=358;$functionOffset=0x30b9d0;$functionSize=0x734
    if($Data.Length -lt 0x17d1db0) {throw 'Unsupported reforge DLL'}
    function Read-RecastCode([string]$Name) {
        $hex=[IO.File]::ReadAllText((Join-Path $ResourceDir $Name)).Trim()
        if($hex -notmatch '^[0-9A-F]+$' -or $hex.Length -ne $size*2) {throw 'Invalid reforge patch resource'}
        [byte[]]$bytes=New-Object byte[] $size
        for($i=0;$i -lt $size;$i++) {$bytes[$i]=[Convert]::ToByte($hex.Substring($i*2,2),16)}
        return ,$bytes
    }
    $original=Read-RecastCode 'recast_optimization_original.hex';$patched=Read-RecastCode 'recast_optimization.hex';$legacy=Read-RecastCode 'recast_optimization_legacy.hex'
    $sha=[Security.Cryptography.SHA256]::Create()
    try {
        if([BitConverter]::ToString($sha.ComputeHash($original)).Replace('-','') -ne '41A9F2227C1B32C3AB7A7BF48F460967145E46DEF0C19C54966F7959014B1B6C') {throw 'Original reforge resource differs'}
        if([BitConverter]::ToString($sha.ComputeHash($patched)).Replace('-','') -ne '31423A6A6B6E7D5CC457EF76FE5F6356F3FEE4E568337D8AE00734C7633120A0') {throw 'Reforge patch resource differs'}
        if([BitConverter]::ToString($sha.ComputeHash($legacy)).Replace('-','') -ne 'E79770CF8457C77527DB003D869E63727E11DBAEABD09A3DC3ECAEDD91D9B8A4') {throw 'Legacy reforge resource differs'}
        $current=[BitConverter]::ToString($Data,$offset,$size)
        if($current -ne [BitConverter]::ToString($original) -and $current -ne [BitConverter]::ToString($patched) -and $current -ne [BitConverter]::ToString($legacy)) {throw 'Unknown reforge code; refused'}
        [byte[]]$function=$Data[$functionOffset..($functionOffset+$functionSize-1)]
        $original.CopyTo($function,$offset-$functionOffset)
        if([BitConverter]::ToString($sha.ComputeHash($function)).Replace('-','') -ne 'DE9B47E5E4125DDEE23AF938503DC4AFF75BA867E229B642C16426E9831C80A4') {throw 'Unknown reforge generator layout; refused'}
        foreach($guard in @(
            @(0x5e7118,216,'6B49B19046A5A60B3330E0C0BA5F4E5257CE5D44BEEF5393DC142E244F38DC07'),
            @(0x23dc30,30,'B54F91D3D2F61DD0E80EA7A234E2B58C506B5D273B28BC7E1E2DFC569784CC7B'),
            @(0x269590,25,'1F9A817EC18087B7503D0F7A21337011E0A26F4D601D53A2D285B002368E8D3C'),
            @(0x2c0120,14,'F51810CBF854F603A83E48ACA2458B9BF734A352CB395DA0DD6E0491AE96D66E'),
            @(0x17d1da8,8,'785532C46FAC2ACF9272CC7399F550747206622E1D56FC7379F34628E071C80A')
        )) {
            if([BitConverter]::ToString($sha.ComputeHash($Data,[int]$guard[0],[int]$guard[1])).Replace('-','') -ne $guard[2]) {throw 'Unknown reforge caller, attribute layout or coefficient; refused'}
        }
        [byte[]]$out=$Data.Clone()
        if($Enabled) {$patched.CopyTo($out,$offset)} else {$original.CopyTo($out,$offset)}
        return ,$out
    } finally {$sha.Dispose()}
}
