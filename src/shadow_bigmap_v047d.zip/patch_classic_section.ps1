﻿function Update-ClassicSection([byte[]]$Data,[bool]$Enabled,[string]$LayoutPath,[byte[]]$Payload=@()) {
    $layout=Get-Content -LiteralPath $LayoutPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $resources=Split-Path (Split-Path (Split-Path $LayoutPath -Parent) -Parent) -Parent
    if(-not ('ShadowClassicSection' -as [type])) {Add-Type -Path (Join-Path $resources 'classic_section_native.cs')}
    function Classic-Bytes([string]$hex) {
        if([string]::IsNullOrEmpty($hex)) {return ,([byte[]]@())}
        if($hex -notmatch '^(?:[0-9a-fA-F]{2})+$') {throw 'Invalid classic section bytes'}
        [byte[]]$b=New-Object byte[] ($hex.Length/2)
        for($i=0;$i -lt $b.Length;$i++) {$b[$i]=[Convert]::ToByte($hex.Substring(2*$i,2),16)}
        return ,$b
    }
    [int[]]$ro=@($layout.relocations | ForEach-Object {$_[0]})
    [int[]]$rt=@($layout.relocations | ForEach-Object {$_[1]})
    [int[]]$rl=@($layout.relocations | ForEach-Object {$_[2]})
    [int[]]$hooks=@($layout.hooks | ForEach-Object {$_.rva})
    [int[]]$targets=@($layout.hooks | ForEach-Object {$_.entry})
    [int[]]$opcodes=@($layout.hooks | ForEach-Object {$_.opcode})
    $originals=New-Object 'System.Collections.Generic.List[byte[]]'
    $tails=New-Object 'System.Collections.Generic.List[byte[]]'
    foreach($h in $layout.hooks) {
        $tail='';if($h.PSObject.Properties['tail']) {$tail=$h.tail}
        $originals.Add((Classic-Bytes $h.original));$tails.Add((Classic-Bytes $tail))
    }
    [int[]]$begins=@($layout.entries | ForEach-Object {$_[0]})
    [int[]]$ends=@($layout.entries | ForEach-Object {$_[1]})
    [int[]]$uw=@($layout.entries | ForEach-Object {$_[2]})
    [int[]]$guards=@($layout.guards | ForEach-Object {$_.rva})
    [int[]]$sizes=@($layout.guards | ForEach-Object {$_.size})
    [string[]]$hashes=@($layout.guards | ForEach-Object {$_.sha256})
    return ,[ShadowClassicSection]::Update($Data,$Enabled,[string]$layout.section,(Classic-Bytes $layout.code),$Payload,[int]$layout.data_offset,
        $ro,$rt,$rl,$hooks,$originals.ToArray(),$targets,$opcodes,$tails.ToArray(),$begins,$ends,$uw,(Classic-Bytes $layout.unwind),$guards,$sizes,$hashes)
}
