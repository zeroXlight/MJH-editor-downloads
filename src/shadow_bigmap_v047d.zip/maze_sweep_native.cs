﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;
public static class ShadowMazeSweep {
 static uint R(byte[] b,int o){return BitConverter.ToUInt32(b,o);}
 static void W(byte[] b,int o,uint v){Buffer.BlockCopy(BitConverter.GetBytes(v),0,b,o,4);}
 static int Align(int n,int a){return checked((n+a-1)/a*a);}
 static byte[] Slice(byte[] b,int o,int n){byte[] v=new byte[n];Buffer.BlockCopy(b,o,v,0,n);return v;}
 static bool Same(byte[] a,byte[] b){if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true;}
 static string Hash(byte[] b){using(SHA256 h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(b)).Replace("-","").ToLowerInvariant();}
 static void Check(bool ok,string msg){if(!ok)throw new InvalidDataException("Maze sweep: "+msg);}
 static int Rva(byte[] b,int r){int pe=(int)R(b,0x3c),t=pe+24+BitConverter.ToUInt16(b,pe+20),n=BitConverter.ToUInt16(b,pe+6);for(int i=0;i<n;i++){int h=t+i*40,v=(int)R(b,h+12),size=Math.Max((int)R(b,h+8),(int)R(b,h+16));if(r>=v&&r<v+size)return (int)R(b,h+20)+r-v;}throw new InvalidDataException("Unmapped RVA");}
 static byte[] Code(byte[] template,int baseRva,int[] offsets,int[] targets){byte[] code=(byte[])template.Clone();for(int i=0;i<offsets.Length;i++)W(code,offsets[i],unchecked((uint)(targets[i]-baseRva-offsets[i]-4)));return code;}
 public static byte[] Update(byte[] input,bool enabled,byte[] template,int[] offsets,int[] targets,byte[] originalHook,int hook,int shimLength,int driverLength,int cloneLength,uint cloneUnwind,uint vanillaExceptionRva,uint vanillaExceptionSize,string[] legacyHashes,int[] guardRvas,int[] guardSizes,string[] guardHashes){
  byte[] b=(byte[])input.Clone();int pe=(int)R(b,0x3c),opt=pe+24;Check(R(b,pe)==0x4550&&BitConverter.ToUInt16(b,pe+4)==0x8664&&BitConverter.ToUInt16(b,opt)==0x20b,"unsupported PE");
  int table=opt+BitConverter.ToUInt16(b,pe+20),count=BitConverter.ToUInt16(b,pe+6),last=table+(count-1)*40;
  for(int i=0;i<count-1;i++)Check(Encoding.ASCII.GetString(b,table+i*40,8).TrimEnd('\0')!=".dyswp","sweep section is not last");
  if(Encoding.ASCII.GetString(b,last,8).TrimEnd('\0')==".dyswp"){
   int raw=(int)R(b,last+20),baseRva=(int)R(b,last+12),hookRaw=Rva(b,hook);byte[] code=Code(template,baseRva,offsets,targets);
   byte[] jump=new byte[]{0xe9,0,0,0,0,0x90,0x90,0x90,0x90,0x90,0x90,0x90};W(jump,1,unchecked((uint)(baseRva-hook-5)));
   Check(Same(Slice(b,hookRaw,12),jump)&&Same(Slice(b,raw,shimLength),Slice(code,0,shimLength)),"unknown installed hook");
   bool driverOK=Same(Slice(b,raw+0x100,0x500),Slice(code,0x100,0x500));string driverHash=Hash(Slice(b,raw+0x100,0x500));foreach(string h in legacyHashes)if(h==driverHash)driverOK=true;
   Check(driverOK&&Same(Slice(b,raw+0x600,cloneLength),Slice(code,0x600,cloneLength)),"unknown installed code");
   int oldLength=raw;uint oldSize=(uint)Align((int)(R(b,last-40+12)+R(b,last-40+8)),(int)R(b,opt+32));uint exRva=vanillaExceptionRva,exSize=vanillaExceptionSize;
   if(Encoding.ASCII.GetString(b,raw+0x980,8)=="MSWEEP02"){
    oldLength=(int)R(b,raw+0x988);oldSize=R(b,raw+0x98c);exRva=R(b,raw+0x990);exSize=R(b,raw+0x994);
    Check(R(b,raw+0x998)==count-1&&oldLength<=raw&&oldLength>=R(b,last-40+20)+R(b,last-40+16),"invalid parent metadata");
   } else Check(exSize>0&&exSize%12==0,"invalid test section parent");
   Check(b.Length==raw+R(b,last+16),"unexpected sweep overlay");
   Check(R(b,opt+136)==baseRva+0x1000 && R(b,opt+140)==exSize+36,"installed unwind directory changed");
   Check(Same(Slice(b,raw+0x1000,(int)exSize),Slice(b,Rva(b,(int)exRva),(int)exSize)),"parent unwind records changed");
   int unwindEnd=raw+0x1000+(int)exSize;
   Check(R(b,unwindEnd)==baseRva && R(b,unwindEnd+12)==baseRva+0x100 && R(b,unwindEnd+24)==baseRva+0x600,"installed unwind entries changed");
   Buffer.BlockCopy(originalHook,0,b,hookRaw,12);Array.Clear(b,last,40);Buffer.BlockCopy(BitConverter.GetBytes((ushort)(count-1)),0,b,pe+6,2);W(b,opt+56,oldSize);W(b,opt+136,exRva);W(b,opt+140,exSize);Array.Resize(ref b,oldLength);count--;last-=40;
  }
  Check(Same(Slice(b,Rva(b,hook),12),originalHook),"unknown original hook");
  for(int i=0;i<guardRvas.Length;i++)Check(Hash(Slice(b,Rva(b,guardRvas[i]),guardSizes[i]))==guardHashes[i],"native API changed "+guardRvas[i].ToString("X"));
  if(!enabled)return b;
  int sectionHeader=table+count*40;Check(sectionHeader+40<=R(b,opt+60)&&Same(Slice(b,sectionHeader,40),new byte[40]),"no free section header");
  int oldLen=b.Length,sa=(int)R(b,opt+32),fa=(int)R(b,opt+36);Check(oldLen==R(b,last+20)+R(b,last+16),"unexpected parent overlay");
  int baseNew=Align(Math.Max((int)R(b,opt+56),(int)(R(b,last+12)+R(b,last+8))),sa),rawNew=Align(oldLen,fa);
  uint oldImage=R(b,opt+56),exceptionRva=R(b,opt+136),exceptionSize=R(b,opt+140);Check(exceptionSize>0&&exceptionSize%12==0,"invalid unwind table");
  byte[] pdata=Slice(b,Rva(b,(int)exceptionRva),(int)exceptionSize);List<uint[]> entries=new List<uint[]>();for(int i=0;i<pdata.Length;i+=12)entries.Add(new uint[]{R(pdata,i),R(pdata,i+4),R(pdata,i+8)});
  entries.Add(new uint[]{(uint)baseNew,(uint)(baseNew+shimLength),(uint)(baseNew+0x920)});entries.Add(new uint[]{(uint)(baseNew+0x100),(uint)(baseNew+0x100+driverLength),(uint)(baseNew+0x940)});entries.Add(new uint[]{(uint)(baseNew+0x600),(uint)(baseNew+0x600+cloneLength),cloneUnwind});entries.Sort(delegate(uint[] a,uint[] c){return a[0].CompareTo(c[0]);});
  int vsize=0x1000+entries.Count*12,rawSize=Align(vsize,fa);byte[] output=new byte[rawNew+rawSize];Buffer.BlockCopy(b,0,output,0,b.Length);byte[] newCode=Code(template,baseNew,offsets,targets);Buffer.BlockCopy(newCode,0,output,rawNew,newCode.Length);
  Buffer.BlockCopy(Encoding.ASCII.GetBytes("MSWEEP02"),0,output,rawNew+0x980,8);W(output,rawNew+0x988,(uint)oldLen);W(output,rawNew+0x98c,oldImage);W(output,rawNew+0x990,exceptionRva);W(output,rawNew+0x994,exceptionSize);W(output,rawNew+0x998,(uint)count);
  for(int i=0;i<entries.Count;i++)for(int j=0;j<3;j++)W(output,rawNew+0x1000+i*12+j*4,entries[i][j]);
  Buffer.BlockCopy(Encoding.ASCII.GetBytes(".dyswp"),0,output,sectionHeader,6);W(output,sectionHeader+8,(uint)vsize);W(output,sectionHeader+12,(uint)baseNew);W(output,sectionHeader+16,(uint)rawSize);W(output,sectionHeader+20,(uint)rawNew);W(output,sectionHeader+36,0x60000020);Buffer.BlockCopy(BitConverter.GetBytes((ushort)(count+1)),0,output,pe+6,2);W(output,opt+56,(uint)Align(baseNew+vsize,sa));W(output,opt+136,(uint)(baseNew+0x1000));W(output,opt+140,(uint)(entries.Count*12));W(output,opt+64,0);
  int hr=Rva(output,hook);output[hr]=0xe9;W(output,hr+1,unchecked((uint)(baseNew-hook-5)));for(int i=5;i<12;i++)output[hr+i]=0x90;return output;
 }
 static ulong Var(byte[] b,ref int p){ulong v=0;int s=0;while(true){Check(p<b.Length&&s<64,"invalid protobuf varint");byte c=b[p++];v|=(ulong)(c&127)<<s;if(c<128)return v;s+=7;}}
 static void V(Stream s,ulong v){while(v>127){s.WriteByte((byte)((v&127)|128));v>>=7;}s.WriteByte((byte)v);}
 static void Skip(byte[] b,ref int p,int wire){switch(wire){case 0:Var(b,ref p);break;case 1:p+=8;break;case 2:int n=checked((int)Var(b,ref p));p+=n;break;case 5:p+=4;break;default:throw new InvalidDataException("Invalid protobuf wire");}Check(p<=b.Length,"protobuf bounds");}
 static byte[] Tag(uint id){using(MemoryStream s=new MemoryStream()){s.WriteByte(8);V(s,id);byte[] name=Encoding.ASCII.GetBytes(id==1900000909?"ShadowMod_SnowPathSweepMonth":"ShadowMod_MazeSweepMonth_"+(id-1900000900));s.WriteByte(18);V(s,(uint)name.Length);s.Write(name,0,name.Length);s.WriteByte(26);s.WriteByte(0);return s.ToArray();}}
 public static byte[] Tags(byte[] b,bool enabled,uint[] ids){HashSet<uint> wanted=new HashSet<uint>(ids),owned=new HashSet<uint>();int p=0;
  while(p<b.Length){ulong key=Var(b,ref p);int field=(int)(key>>3),wire=(int)(key&7);if(field==2&&wire==2){int n=checked((int)Var(b,ref p)),end=p+n;Check(end<=b.Length,"row bounds");byte[] row=Slice(b,p,n);int q=0;uint id=0;while(q<row.Length){ulong k=Var(row,ref q);if(k==8)id=checked((uint)Var(row,ref q));else Skip(row,ref q,(int)(k&7));}if(wanted.Contains(id)){Check(Same(row,Tag(id)),"task-tag ID conflict");owned.Add(id);}p=end;}else Skip(b,ref p,wire);}
  using(MemoryStream output=new MemoryStream()){p=0;while(p<b.Length){int start=p;ulong key=Var(b,ref p);bool remove=false;if(key==8){uint id=checked((uint)Var(b,ref p));remove=owned.Contains(id);}else if(key==18){int n=checked((int)Var(b,ref p));byte[] row=Slice(b,p,n);int q=0;uint id=0;while(q<row.Length){ulong k=Var(row,ref q);if(k==8)id=checked((uint)Var(row,ref q));else Skip(row,ref q,(int)(k&7));}p+=n;remove=owned.Contains(id);}else Skip(b,ref p,(int)(key&7));if(!remove)output.Write(b,start,p-start);}
   if(enabled)foreach(uint id in ids){byte[] row=Tag(id);output.WriteByte(8);V(output,id);output.WriteByte(18);V(output,(uint)row.Length);output.Write(row,0,row.Length);}return output.ToArray();}
 }
}
