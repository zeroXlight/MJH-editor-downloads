﻿# Source patch_table.ps1 first. Change only field 20; retain every other wire byte.
function Repair-EditorMartialExclusive([byte[]]$Data, [byte[]]$Reference) {
    $referenceRows = @{}
    foreach ($span in (Get-FieldSpans $Reference 0 $Reference.Length)) {
        if ($span.Field -ne 2 -or $span.WireType -ne 2) { continue }
        [int]$pos=$span.Start; [void](Get-Varint $Reference ([ref]$pos)); $length=Get-Varint $Reference ([ref]$pos)
        $rowFields=Get-FieldSpans $Reference $pos ($pos+[int]$length)
        $idSpan=@($rowFields | Where-Object {$_.Field -eq 1 -and $_.WireType -eq 0})
        if ($idSpan.Count -ne 1) {throw 'Invalid reference martial ID'}
        [int]$idPos=$idSpan[0].Start;[void](Get-Varint $Reference ([ref]$idPos));[long]$id=Get-Varint $Reference ([ref]$idPos)
        if ($referenceRows.ContainsKey($id)) {throw 'Duplicate reference martial ID'}
        $bytes=New-Object 'System.Collections.Generic.List[byte]'
        foreach ($field in $rowFields) {
            if ($field.Field -eq 20) {
                for($j=$field.Start;$j -lt $field.End;$j++) {$bytes.Add($Reference[$j])}
            }
        }
        $referenceRows[$id]=$bytes.ToArray()
    }
    $output=New-Object 'System.Collections.Generic.List[byte]';$seen=@{}
    foreach ($span in (Get-FieldSpans $Data 0 $Data.Length)) {
        if ($span.Field -ne 2 -or $span.WireType -ne 2) {
            for($j=$span.Start;$j -lt $span.End;$j++) {$output.Add($Data[$j])};continue
        }
        [int]$pos=$span.Start;[void](Get-Varint $Data ([ref]$pos));$length=Get-Varint $Data ([ref]$pos)
        $rowFields=Get-FieldSpans $Data $pos ($pos+[int]$length)
        $idSpan=@($rowFields | Where-Object {$_.Field -eq 1 -and $_.WireType -eq 0})
        if ($idSpan.Count -ne 1) {throw 'Invalid edited martial ID'}
        [int]$idPos=$idSpan[0].Start;[void](Get-Varint $Data ([ref]$idPos));[long]$id=Get-Varint $Data ([ref]$idPos)
        if($seen.ContainsKey($id)){throw 'Duplicate edited martial ID'};$seen[$id]=$true
        if(-not $referenceRows.ContainsKey($id)) {
            for($j=$span.Start;$j -lt $span.End;$j++) {$output.Add($Data[$j])};continue
        }
        $row=New-Object 'System.Collections.Generic.List[byte]'
        foreach($field in $rowFields) {
            if($field.Field -ne 20) {for($j=$field.Start;$j -lt $field.End;$j++) {$row.Add($Data[$j])}}
        }
        $row.AddRange([byte[]]$referenceRows[$id])
        Add-Varint $output 18;Add-Varint $output $row.Count;$output.AddRange($row.ToArray())
    }
    return ,$output.ToArray()
}


# Native fallback: only our compatible editor's complete, certified takeover
# receipt can authorize restoring the associated configuration session.
function Get-EditorTakeoverRestorePlan([string]$Dir) {
    $root=[IO.Path]::GetFullPath($Dir).TrimEnd('\')
    $receipt=Join-Path $root '装备编辑器配置\运行库优先权.json'
    $dll=Join-Path $root 'DreamRivakes_Data\Plugins\RaceLogic_Release_x64.dll'
    if(-not(Test-Path -LiteralPath $receipt)) {return $null}
    $doc=Get-Content -LiteralPath $receipt -Raw -Encoding UTF8 | ConvertFrom-Json
    if($doc.Winner -ne 'Editor') {return $null}
    if($doc.FormatVersion -ne 1 -or $doc.StartedAt -notmatch '^\d{8}_\d{6}_\d{6}$') {throw 'Invalid editor takeover receipt'}
    if((Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash -ne $doc.EditorSHA256) {throw '编辑器接管后运行库又被其他工具修改，不能自动覆盖未知版本'}
    $first=@{};$found=$false
    $history=Join-Path $root '装备编辑器备份'
    foreach($folder in @(Get-ChildItem -LiteralPath $history -Directory | Sort-Object Name)) {
        if($folder.Name -lt [string]$doc.StartedAt) {continue}
        $manifestPath=Join-Path $folder.FullName 'manifest.json'
        if(-not(Test-Path -LiteralPath $manifestPath)){continue}
        $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if(-not $manifest.complete){continue}
        if([IO.Path]::GetFullPath([string]$manifest.root).TrimEnd('\') -ne $root){throw 'Editor history belongs to another game'}
        $native=@($manifest.entries | Where-Object {$_.path.Replace('/','\') -eq 'DreamRivakes_Data\Plugins\RaceLogic_Release_x64.dll'})
        if(-not $found) {
            if($native.Count -ne 1 -or $native[0].before_sha256 -ne $doc.BeforeShadowSHA256){continue}
            $found=$true
        }
        foreach($entry in $manifest.entries) {
            $relative=[string]$entry.path
            if([IO.Path]::IsPathRooted($relative) -or $relative.Split([char[]]'\/') -contains '..'){throw 'Invalid editor history target'}
            $path=[IO.Path]::GetFullPath((Join-Path $root $relative))
            if(-not $path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Editor history path escapes game'}
            if([IO.Path]::GetFileName($path).ToLowerInvariant() -in @('save.sav','saveai.sav')){continue}
            if($path.StartsWith((Join-Path $root '装备编辑器备份')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Editor history targets its own backups'}
            if($first.ContainsKey($path)){continue}
            [byte[]]$before=$null
            if($entry.exists) {
                $backupPath=[IO.Path]::GetFullPath((Join-Path $folder.FullName ([string]$entry.backup)))
                if(-not $backupPath.StartsWith($folder.FullName+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid editor backup path'}
                if((Get-FileHash -LiteralPath $backupPath -Algorithm SHA256).Hash -ne $entry.before_sha256){throw 'Editor baseline backup checksum differs'}
                $before=[IO.File]::ReadAllBytes($backupPath)
            }
            [byte[]]$current=if(Test-Path -LiteralPath $path){,[IO.File]::ReadAllBytes($path)}else{$null}
            $first[$path]=@{Before=$before;Current=$current;Relative=$relative}
        }
    }
    if(-not $found -or -not $first.ContainsKey($dll)){throw '找不到完整编辑器接管备份，不能自动覆盖'}
    $sha=[Security.Cryptography.SHA256]::Create()
    try {$originalHash=[BitConverter]::ToString($sha.ComputeHash([byte[]]$first[$dll].Before)).Replace('-','')} finally {$sha.Dispose()}
    if($originalHash -ne $doc.BeforeShadowSHA256){throw 'Editor takeover original runtime checksum differs'}
    return @{Root=$root;Files=$first}
}
function Invoke-EditorTakeoverRestore($Plan,[string]$BackupRoot) {
    if($null -eq $Plan){return}
    $backup=Join-Path $BackupRoot ('编辑器互斥覆盖_'+[Guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($backup)
    $entries=New-Object 'System.Collections.Generic.List[object]';$written=New-Object 'System.Collections.Generic.List[string]'
    foreach($path in $Plan.Files.Keys) {
        $row=$Plan.Files[$path]
        $current=if(Test-Path -LiteralPath $path){,[IO.File]::ReadAllBytes($path)}else{$null}
        if(($null -eq $current) -ne ($null -eq $row.Current) -or [Convert]::ToBase64String([byte[]]$current) -ne [Convert]::ToBase64String([byte[]]$row.Current)){throw '编辑器接管文件在预检后发生变化'}
        $name=('{0:D4}.bin' -f $entries.Count)
        if($null -ne $current){[IO.File]::WriteAllBytes((Join-Path $backup $name),$current)}
        $entries.Add(@{Path=$row.Relative;Exists=($null -ne $current);Backup=$name})
    }
    @{Rule='最后安装暗影 MOD 优先，回退互斥编辑器原生会话的配置；不回退存档';Files=$entries}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $backup 'manifest.json') -Encoding UTF8
    try {
        foreach($path in $Plan.Files.Keys) {
            $row=$Plan.Files[$path];$written.Add($path)
            if($null -eq $row.Before){if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path -Force}}
            else {[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($path));[IO.File]::WriteAllBytes($path,[byte[]]$row.Before)}
        }
    } catch {
        foreach($path in $written){$row=$Plan.Files[$path];if($null -eq $row.Current){if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path -Force}}else{[IO.File]::WriteAllBytes($path,[byte[]]$row.Current)}}
        throw
    }
    Write-Output $backup
}
