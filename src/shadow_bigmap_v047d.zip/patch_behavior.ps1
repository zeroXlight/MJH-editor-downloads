﻿# =====================================================================
#  梦江湖 MOD · 「冒险手札」修复补丁器（零依赖，仅用 Windows 自带 PowerShell）
#
#  修的是什么
#  ---------------------------------------------------------------
#  开局赠送的道具「冒险手札」(Item 4007) 使用后，应当把 9 类冒险天赋
#  全部拉到 5 级，实际只有 8 类生效 —— 「食材搜刮」从来没被发放过。
#
#  根因（已逐字节验证）
#  ---------------------------------------------------------------
#  调用链：Item 4007 (ETT_OpenTask, Value1=5699)
#            -> Task 5699
#              -> TaskEdge 5699001  （行为列表 5699004..5699012）
#                -> Behavior 5699004..5699012   每条都是 BET_ROLE_ADDGIFT
#
#  这 9 条本该"一类天赋一条"，实际：
#      5699011  Arg2 = "530"   金钱搜刮 L5
#      5699012  Arg2 = "530"   金钱搜刮 L5   <-- 复制粘贴写重了
#  于是 Gift 525「食材搜刮 L5」被漏掉，一个都没发。
#
#  修法
#  ---------------------------------------------------------------
#  把 Behavior 行 5699012 的 Arg2（field 5）由 "530" 改成 "525"。
#  两个值都是 3 字节 ASCII —— **文件长度、行内所有偏移完全不变**，
#  所以做的是"原位字节覆盖"，不是重新编码，碰不到任何别的数据。
#
#  安全前提（三重校验，任何一条不符就拒绝写入）
#  ---------------------------------------------------------------
#    · 该行 BaseID 必须是 5699012
#    · 该行 Type    必须是 42（BehaviorType.BET_ROLE_ADDGIFT）
#    · 该行 Arg1    必须是 "发布角色"
#  写盘前的自校验：长度不变 + 目标值确实变成 "525" + 用 MD5 证明
#  "目标 3 字节以外的部分逐字节未变"。
#  幂等：已经是 "525" 就直接返回，不写盘。
#
#  性能说明
#  ---------------------------------------------------------------
#  这张表有 2 MB / 2.2 万条记录。顶层扫描刻意写成了**内联 varint**
#  （不用函数调用），并且只在 BaseID 命中时才完整解析该行 ——
#  否则光"认一下这是什么表"就要跑一分钟（实测过，见 _tmp 里的对照实验）。
#
#  可被 dot-source 复用（install.ps1 就是这么用的），也可单独命令行运行：
#     patch_behavior.ps1 -Path <文件>
#     patch_behavior.ps1 -Path <文件> -CountOnly
#  （实际调用时前面还要带执行策略旁路参数，写法见 install.ps1）
# =====================================================================
param(
    [string]$Path = '',
    [switch]$CountOnly,
    [switch]$Quiet
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# Behavior 表里这一行 + 这两个值（由逆向确定，见项目文档）
$SCRIPT:ADV_ROW_ID   = 5699012
$SCRIPT:ADV_ROW_TYPE = 42
$SCRIPT:ADV_ROW_ARG1 = '发布角色'
$SCRIPT:ADV_FIELD    = 5
$SCRIPT:ADV_BAD      = '530'
$SCRIPT:ADV_FIX      = '525'

# ------------------------------------------------------------------ 原语
# （只用于"命中的那一行"，一次调用几十次，不会是瓶颈）
function Get-AdvVarint {
    param([byte[]]$Buf, [ref]$Pos)
    [long]$n = 0
    [int]$s = 0
    while ($true) {
        if ($Pos.Value -ge $Buf.Length) { throw 'varint 读到文件末尾' }
        [int]$b = [int]$Buf[$Pos.Value]
        $Pos.Value = $Pos.Value + 1
        $n = $n -bor ([long]($b -band 0x7F) -shl $s)
        if (($b -band 0x80) -eq 0) { return $n }
        $s = $s + 7
        if ($s -gt 63) { throw 'varint 过长(>10 字节)，文件可能不是该表' }
    }
}

function Skip-AdvValue {
    param([byte[]]$Buf, [ref]$Pos, [int]$WireType, [int]$At)
    switch ($WireType) {
        0 { [void](Get-AdvVarint $Buf $Pos) }
        1 { $Pos.Value = $Pos.Value + 8 }
        2 { [long]$ln = Get-AdvVarint $Buf $Pos; $Pos.Value = $Pos.Value + [int]$ln }
        5 { $Pos.Value = $Pos.Value + 4 }
        default { throw ("偏移 $At 处出现非法 wiretype $WireType，文件可能不是该表") }
    }
}

# ------------------------------------------------------------------ 状态
function Get-AdvState {
    # 返回 @{ State; Found; RowCount; ValueOffset; ValueLen; BaseID; Type; Arg1; Arg2 }
    # State: missing 找不到该行 / mismatch 找到但内容不符 / orig 原版(有 bug)
    #        / fixed 已修复 / unknown Arg2 是别的值
    param([byte[]]$Data)

    $st = @{
        State       = 'missing'
        Found       = $false
        RowCount    = 0
        ValueOffset = -1
        ValueLen    = 0
        BaseID      = -1
        Type        = -1
        Arg1        = ''
        Arg2        = ''
    }

    [int]$target = $SCRIPT:ADV_ROW_ID
    [int]$len = $Data.Length
    [int]$i = 0
    [int]$rows = 0

    while ($i -lt $len) {
        [int]$fs = $i

        # ---- 顶层：读字段 key（内联 varint）----
        [long]$key = 0
        [int]$sh = 0
        while ($true) {
            if ($i -ge $len) { throw '文件在记录中途结束，可能不是 Behavior 表' }
            [int]$b = [int]$Data[$i]
            $i = $i + 1
            $key = $key -bor ([long]($b -band 0x7F) -shl $sh)
            if (($b -band 0x80) -eq 0) { break }
            $sh = $sh + 7
            if ($sh -gt 63) { throw 'varint 过长(>10 字节)，文件可能不是 Behavior 表' }
        }
        [int]$f = [int]($key -shr 3)
        [int]$wt = [int]($key -band 7)

        if ($f -ne 2 -or $wt -ne 2) {
            # 非"行记录"字段：跳过它的值
            if ($wt -eq 0) {
                [int]$sh = 0
                while ($true) {
                    if ($i -ge $len) { throw '文件在字段中途结束，可能不是 Behavior 表' }
                    [int]$b = [int]$Data[$i]
                    $i = $i + 1
                    if (($b -band 0x80) -eq 0) { break }
                    $sh = $sh + 7
                    if ($sh -gt 63) { throw 'varint 过长，可能不是 Behavior 表' }
                }
            }
            elseif ($wt -eq 2) {
                [long]$sl = 0
                [int]$sh = 0
                while ($true) {
                    if ($i -ge $len) { throw '文件在字段中途结束，可能不是 Behavior 表' }
                    [int]$b = [int]$Data[$i]
                    $i = $i + 1
                    $sl = $sl -bor ([long]($b -band 0x7F) -shl $sh)
                    if (($b -band 0x80) -eq 0) { break }
                    $sh = $sh + 7
                    if ($sh -gt 63) { throw 'varint 过长，可能不是 Behavior 表' }
                }
                $i = $i + [int]$sl
            }
            elseif ($wt -eq 5) { $i = $i + 4 }
            elseif ($wt -eq 1) { $i = $i + 8 }
            else { throw ("偏移 $fs 处出现非法 wiretype $wt，文件可能不是 Behavior 表") }
            if ($i -gt $len) { throw ("偏移 $fs 处的字段越过文件末尾，文件可能不是 Behavior 表") }
            continue
        }

        # ---- 行长度 ----
        [long]$ln = 0
        [int]$sh = 0
        while ($true) {
            if ($i -ge $len) { throw '文件在行长度处结束，可能不是 Behavior 表' }
            [int]$b = [int]$Data[$i]
            $i = $i + 1
            $ln = $ln -bor ([long]($b -band 0x7F) -shl $sh)
            if (($b -band 0x80) -eq 0) { break }
            $sh = $sh + 7
            if ($sh -gt 63) { throw 'varint 过长，可能不是 Behavior 表' }
        }
        [int]$vs = $i
        [int]$ve = $i + [int]$ln
        if ($ve -gt $len) { throw ("偏移 $fs 处的记录越过文件末尾，文件可能不是 Behavior 表") }
        $i = $ve
        $rows = $rows + 1

        # ---- 快速取 BaseID：绝大多数行 f1 就是第一个字段(key=0x08) ----
        #      只看第一个字节，不跑通用解析 —— 这是整段扫描的性能关键
        [int]$bid = -1
        [int]$avail = $ve - $vs
        if ($avail -ge 2 -and [int]$Data[$vs] -eq 0x08) {
            [int]$p = $vs + 1
            [long]$v = 0
            [int]$sh = 0
            while ($true) {
                if ($p -ge $ve) { throw '行内 BaseID 字段越界，文件可能不是 Behavior 表' }
                [int]$b = [int]$Data[$p]
                $p = $p + 1
                $v = $v -bor ([long]($b -band 0x7F) -shl $sh)
                if (($b -band 0x80) -eq 0) { break }
                $sh = $sh + 7
                if ($sh -gt 63) { throw 'varint 过长，文件可能不是 Behavior 表' }
            }
            $bid = [int]$v
        }
        elseif ($avail -ge 2) {
            # 兜底：f1 不在首位时走通用解析
            [int]$q = $vs
            while ($q -lt $ve) {
                [long]$k2 = Get-AdvVarint $Data ([ref]$q)
                [int]$f2 = [int]($k2 -shr 3)
                if ($f2 -eq 1 -and [int]($k2 -band 7) -eq 0) {
                    $bid = [int](Get-AdvVarint $Data ([ref]$q))
                    break
                }
                Skip-AdvValue $Data ([ref]$q) ([int]($k2 -band 7)) $q
            }
        }

        if ($bid -ne $target) { continue }

        # ---- 命中：完整解析这一行（只有一条，慢一点无所谓）----
        [int]$j = $vs
        [int]$ty = -1
        [string]$a1 = ''
        [int]$a2off = -1
        [int]$a2len = 0
        while ($j -lt $ve) {
            [int]$is = $j
            [long]$k2 = Get-AdvVarint $Data ([ref]$j)
            [int]$f2 = [int]($k2 -shr 3)
            [int]$w2 = [int]($k2 -band 7)
            if ($w2 -eq 0) {
                [long]$vv = Get-AdvVarint $Data ([ref]$j)
                if ($f2 -eq 2) { $ty = [int]$vv }
            }
            elseif ($w2 -eq 2) {
                [long]$l2 = Get-AdvVarint $Data ([ref]$j)
                [int]$b2s = $j
                [int]$b2e = $j + [int]$l2
                if ($b2e -gt $ve) { throw ("偏移 $is 处的字段越过记录边界，文件可能不是 Behavior 表") }
                if ($f2 -eq 4) {
                    $a1 = [System.Text.Encoding]::UTF8.GetString($Data, $b2s, [int]$l2)
                }
                elseif ($f2 -eq $SCRIPT:ADV_FIELD) {
                    $a2off = $b2s
                    $a2len = [int]$l2
                }
                $j = $b2e
            }
            else {
                Skip-AdvValue $Data ([ref]$j) $w2 $is
            }
        }

        $st.Found = $true
        $st.BaseID = $bid
        $st.Type = $ty
        $st.Arg1 = $a1
        $st.ValueOffset = $a2off
        $st.ValueLen = $a2len
        if ($a2off -ge 0) {
            $st.Arg2 = [System.Text.Encoding]::UTF8.GetString($Data, $a2off, $a2len)
        }
        if ($ty -ne $SCRIPT:ADV_ROW_TYPE -or $a1 -ne $SCRIPT:ADV_ROW_ARG1) {
            $st.State = 'mismatch'
        }
        elseif ($st.Arg2 -eq $SCRIPT:ADV_FIX) { $st.State = 'fixed' }
        elseif ($st.Arg2 -eq $SCRIPT:ADV_BAD) { $st.State = 'orig' }
        else { $st.State = 'unknown' }
        break
    }

    $st.RowCount = $rows
    return $st
}

function Get-AdvStateText {
    param([string]$State)
    switch ($State) {
        'missing'  { return '找不到目标行' }
        'mismatch' { return '找到该行但内容与预期不符' }
        'orig'     { return '原版（有这个 bug）' }
        'fixed'    { return '已修复' }
        default    { return '未知值' }
    }
}

function Test-AdvRangeSame {
    # 用 MD5 判断 A、B 两段 [Start, Count) 是否逐字节相同（纯 .NET，毫秒级）
    param([byte[]]$A, [byte[]]$B, [int]$Start, [int]$Count)
    if ($Count -le 0) { return $true }
    $md5 = [System.Security.Cryptography.MD5]::Create()
    try {
        $sa = New-Object byte[] $Count
        $sb = New-Object byte[] $Count
        [System.Array]::Copy($A, $Start, $sa, 0, $Count)
        [System.Array]::Copy($B, $Start, $sb, 0, $Count)
        $ha = [System.BitConverter]::ToString($md5.ComputeHash($sa))
        $hb = [System.BitConverter]::ToString($md5.ComputeHash($sb))
        return ($ha -eq $hb)
    }
    finally { $md5.Dispose() }
}

# ------------------------------------------------------------------ 打补丁
function Repair-AdventureGift {
    # 返回 @{ Bytes = <新字节>; Fixed = 0 或 1; State = <补丁前的状态> }
    param([byte[]]$Data)

    $st = Get-AdvState $Data
    if (-not $st.Found) {
        throw ("Behavior 行 {0} 未找到，已放弃写入（游戏版本可能不同）" -f $SCRIPT:ADV_ROW_ID)
    }
    if ($st.State -eq 'mismatch') {
        throw ("Behavior 行 {0} 的内容与预期不符（Type={1} Arg1='{2}'），已放弃写入" -f $SCRIPT:ADV_ROW_ID, $st.Type, $st.Arg1)
    }
    if ($st.State -eq 'fixed') {
        return @{ Bytes = $Data; Fixed = 0; State = 'fixed' }
    }
    if ($st.State -ne 'orig') {
        throw ("Behavior 行 {0} 的 Arg2='{1}'，既不是 {2} 也不是 {3}，已放弃写入" -f $SCRIPT:ADV_ROW_ID, $st.Arg2, $SCRIPT:ADV_BAD, $SCRIPT:ADV_FIX)
    }

    $out = New-Object byte[] $Data.Length
    [System.Array]::Copy($Data, $out, $Data.Length)
    $patch = [System.Text.Encoding]::ASCII.GetBytes($SCRIPT:ADV_FIX)
    if ($patch.Length -ne $st.ValueLen) {
        throw ("自校验失败：新值 {0} 字节、原值 {1} 字节，长度不等，已放弃写入" -f $patch.Length, $st.ValueLen)
    }
    [System.Array]::Copy($patch, 0, $out, $st.ValueOffset, $patch.Length)

    # ---- 自校验 ----
    #  ① 长度不变
    #  ② 目标位置确实变成了 "525"
    #  ③ 目标 3 字节以外的部分，用 MD5 证明逐字节未变
    #     注意 "530" -> "525" 只有 2 个字节真的不同（首字符都是 '5'），
    #     所以不要去数"改了几个字节"，只证明"别处没动"。
    if ($out.Length -ne $Data.Length) { throw '自校验失败：文件长度发生变化，已放弃写入' }
    $now = [System.Text.Encoding]::ASCII.GetString($out, $st.ValueOffset, $patch.Length)
    if ($now -ne $SCRIPT:ADV_FIX) {
        throw ("自校验失败：写入后该处为 '{0}' 而不是 '{1}'，已放弃写入" -f $now, $SCRIPT:ADV_FIX)
    }
    $tailStart = $st.ValueOffset + $patch.Length
    $tailCount = $Data.Length - $tailStart
    if (-not (Test-AdvRangeSame $Data $out 0 $st.ValueOffset)) {
        throw '自校验失败：目标位置之前的内容被改动，已放弃写入'
    }
    if (-not (Test-AdvRangeSame $Data $out $tailStart $tailCount)) {
        throw '自校验失败：目标位置之后的内容被改动，已放弃写入'
    }

    return @{ Bytes = $out; Fixed = 1; State = 'orig' }
}

# ---------------------------------------------------------------- 命令行入口
if ($Path -ne '') {
    if (-not (Test-Path -LiteralPath $Path)) { throw "找不到文件: $Path" }
    $data = [System.IO.File]::ReadAllBytes($Path)
    $st = Get-AdvState $data

    if (-not $Quiet) {
        Write-Host ("文件      : {0}" -f $Path)
        Write-Host ("大小      : {0} 字节" -f $data.Length)
        Write-Host ("记录数    : {0}" -f $st.RowCount)
        Write-Host ("目标行    : Behavior {0}" -f $SCRIPT:ADV_ROW_ID)
        Write-Host ("Arg2      : '{0}'  -> {1}" -f $st.Arg2, (Get-AdvStateText $st.State))
    }

    if ($CountOnly) {
        $flag = if ($st.State -eq 'fixed') { 1 } else { 0 }
        Write-Output ("FIXED={0}" -f $flag)
        exit 0
    }

    if ($st.State -eq 'fixed') {
        if (-not $Quiet) { Write-Host '已经是修复后的状态，无需修改。' }
        Write-Output 'FIXED=0'
        exit 0
    }

    $res = Repair-AdventureGift $data
    [System.IO.File]::WriteAllBytes($Path, $res.Bytes)
    if (-not $Quiet) {
        Write-Host ("已修复：Arg2 '{0}' -> '{1}'" -f $SCRIPT:ADV_BAD, $SCRIPT:ADV_FIX)
        Write-Host ("大小      : {0} 字节（不变）" -f $res.Bytes.Length)
        Write-Host ("写入      : {0}" -f $Path)
    }
    Write-Output ("FIXED={0}" -f $res.Fixed)
    exit 0
}
