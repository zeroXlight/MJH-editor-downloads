using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;

// Classic-only sections. Each owns its hooks, dynamic data, unwind records and
// parent directory snapshot. Later sections must be removed in reverse order.
public static class ShadowClassicSection {
 static uint R(byte[] b,int p){return BitConverter.ToUInt32(b,p);}
 static void W(byte[] b,int p,uint v){Buffer.BlockCopy(BitConverter.GetBytes(v),0,b,p,4);}
 static int A(int n,int a){return checked((n+a-1)/a*a);}
 static void C(bool ok,string s){if(!ok)throw new InvalidDataException("Classic section: "+s);}
 static byte[] S(byte[] b,int p,int n){C(p>=0&&n>=0&&p<=b.Length-n,"invalid range");byte[] v=new byte[n];Buffer.BlockCopy(b,p,v,0,n);return v;}
 static bool Eq(byte[] a,byte[] b){if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true;}
 static int Map(byte[] b,int r){int pe=(int)R(b,0x3c),t=pe+24+BitConverter.ToUInt16(b,pe+20),n=BitConverter.ToUInt16(b,pe+6);for(int i=0;i<n;i++){int h=t+i*40,v=(int)R(b,h+12),sz=Math.Max((int)R(b,h+8),(int)R(b,h+16));if(r>=v&&r<v+sz)return checked((int)R(b,h+20)+r-v);}throw new InvalidDataException("Classic unmapped RVA");}
 static byte[] Hook(int from,int to,int length,int opcode,byte[] tail){C(length>=5&&length<=32&&(opcode==0xe8||opcode==0xe9),"invalid hook");byte[] v=new byte[length];for(int i=0;i<length;i++)v[i]=0x90;C(tail.Length<=length-5,"hook tail too large");v[0]=(byte)opcode;W(v,1,unchecked((uint)(to-from-5)));Buffer.BlockCopy(tail,0,v,5,tail.Length);return v;}
 static string Hash(byte[] b){using(SHA256 h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(b)).Replace("-","").ToLowerInvariant();}
 static byte[] Code(byte[] code,int baseRva,int[] ro,int[] rt,int[] rl){byte[] c=(byte[])code.Clone();for(int i=0;i<ro.Length;i++)W(c,ro[i],unchecked((uint)(rt[i]+(rl[i]!=0?baseRva:0)-baseRva-ro[i]-4)));return c;}
 public static byte[] Update(byte[] input,bool enabled,string name,byte[] code,byte[] data,int dataOffset,
  int[] ro,int[] rt,int[] rl,int[] hooks,byte[][] originals,int[] targets,int[] opcodes,byte[][] tails,
  int[] begins,int[] ends,int[] uwOffsets,byte[] unwind,int[] guards,int[] sizes,string[] hashes){
  C(name.Length<=8&&name.StartsWith(".dy"),"invalid owner");
  C(code.Length<0x4000&&dataOffset>=code.Length&&dataOffset+data.Length<=0x7000&&unwind.Length<=0x400,"invalid payload");
  C(ro.Length==rt.Length&&ro.Length==rl.Length&&hooks.Length==originals.Length&&hooks.Length==targets.Length&&hooks.Length==opcodes.Length&&hooks.Length==tails.Length,"invalid hooks/relocations");
  C(begins.Length==ends.Length&&begins.Length==uwOffsets.Length&&guards.Length==sizes.Length&&guards.Length==hashes.Length,"invalid guards/unwind");
  byte[] b=(byte[])input.Clone();int pe=(int)R(b,0x3c),opt=pe+24;
  C(pe==0x108&&R(b,pe)==0x4550&&BitConverter.ToUInt16(b,pe+4)==0x8664,"unsupported classic PE");
  int t=opt+BitConverter.ToUInt16(b,pe+20),count=BitConverter.ToUInt16(b,pe+6),last=t+(count-1)*40;
  C(count>=7&&count<=12,"invalid section count");
  for(int i=0;i<count-1;i++)C(Encoding.ASCII.GetString(b,t+i*40,8).TrimEnd('\0')!=name,"strip later sections first");
  bool installed=Encoding.ASCII.GetString(b,last,8).TrimEnd('\0')==name;
  byte[] installedInput=null;
  if(installed){
   installedInput=b;int raw=(int)R(b,last+20),baseRva=(int)R(b,last+12),m=raw+0x7800;
   C(Encoding.ASCII.GetString(b,m,8)=="DYSECT02","unknown section owner");
   int oldLen=(int)R(b,m+8);uint oldImage=R(b,m+12),oldEx=R(b,m+16),oldSize=R(b,m+20),checksum=R(b,m+24);
   C(R(b,m+28)==count-1&&oldLen<=raw&&oldLen==R(b,last-40+20)+R(b,last-40+16),"invalid parent");
   for(int i=0;i<hooks.Length;i++)C(Eq(S(b,Map(b,hooks[i]),originals[i].Length),Hook(hooks[i],baseRva+targets[i],originals[i].Length,opcodes[i],tails[i])),"unknown installed hook");
   byte[] restored=S(b,0,oldLen);
   for(int i=0;i<hooks.Length;i++)Buffer.BlockCopy(originals[i],0,restored,Map(restored,hooks[i]),originals[i].Length);
   Array.Clear(restored,last,40);Buffer.BlockCopy(BitConverter.GetBytes((ushort)(count-1)),0,restored,pe+6,2);
   W(restored,opt+56,oldImage);W(restored,opt+136,oldEx);W(restored,opt+140,oldSize);W(restored,opt+64,checksum);
   // Rebuild with the installed data before changing pools/configuration.
   int savedDataLength=(int)R(b,m+32);C(savedDataLength>=0&&dataOffset+savedDataLength<=0x7000,"invalid installed data size");
   using(SHA256 sha=SHA256.Create())C(Eq(sha.ComputeHash(S(b,raw+dataOffset,savedDataLength)),S(b,m+40,32)),"installed data modified");
   byte[] expected=Update(restored,true,name,code,S(b,raw+dataOffset,savedDataLength),dataOffset,ro,rt,rl,hooks,originals,targets,opcodes,tails,begins,ends,uwOffsets,unwind,guards,sizes,hashes);
   C(Eq(expected,installedInput),"installed code/section/unwind modified");
   b=restored;count--;last-=40;
  }
  for(int i=0;i<hooks.Length;i++)C(Eq(S(b,Map(b,hooks[i]),originals[i].Length),originals[i]),"unknown original hook");
  for(int i=0;i<guards.Length;i++)C(Hash(S(b,Map(b,guards[i]),sizes[i]))==hashes[i],"native dependency changed");
  if(!enabled)return b;
  int header=t+count*40;
  C(header+40<=R(b,opt+60)&&Eq(S(b,header,40),new byte[40]),"section header occupied");
  C(b.Length==R(b,last+20)+R(b,last+16),"unknown parent overlay");
  int sa=(int)R(b,opt+32),fa=(int)R(b,opt+36);C(sa==0x1000&&fa==0x200,"unknown alignment");
  int baseNew=A(Math.Max((int)R(b,opt+56),(int)(R(b,last+12)+Math.Max(R(b,last+8),R(b,last+16)))),sa),rawNew=A(b.Length,fa);
  uint ex=R(b,opt+136),exSize=R(b,opt+140);C(exSize>0&&exSize%12==0,"invalid parent unwind");
  byte[] pdata=S(b,Map(b,(int)ex),(int)exSize);
  int previous=(int)R(pdata,pdata.Length-8);C(previous<=baseNew,"parent unwind unsorted");
  for(int i=0;i<begins.Length;i++){C(begins[i]>=0&&begins[i]<ends[i]&&ends[i]<=code.Length&&uwOffsets[i]>=0&&uwOffsets[i]<unwind.Length,"invalid unwind range");C(i==0||ends[i-1]<=begins[i],"unsorted shim unwind");}
  int vsize=checked(0x8000+(int)exSize+12*begins.Length),rawSize=A(vsize,fa);
  byte[] output=new byte[rawNew+rawSize];Buffer.BlockCopy(b,0,output,0,b.Length);
  byte[] relocated=Code(code,baseNew,ro,rt,rl);Buffer.BlockCopy(relocated,0,output,rawNew,relocated.Length);
  Buffer.BlockCopy(data,0,output,rawNew+dataOffset,data.Length);Buffer.BlockCopy(unwind,0,output,rawNew+0x7000,unwind.Length);
  int meta=rawNew+0x7800;Buffer.BlockCopy(Encoding.ASCII.GetBytes("DYSECT02"),0,output,meta,8);
  W(output,meta+8,(uint)b.Length);W(output,meta+12,R(b,opt+56));W(output,meta+16,ex);W(output,meta+20,exSize);W(output,meta+24,R(b,opt+64));W(output,meta+28,(uint)count);W(output,meta+32,(uint)data.Length);
  using(SHA256 sha=SHA256.Create())Buffer.BlockCopy(sha.ComputeHash(data),0,output,meta+40,32);
  Buffer.BlockCopy(pdata,0,output,rawNew+0x8000,pdata.Length);
  for(int i=0;i<begins.Length;i++){int at=rawNew+0x8000+pdata.Length+i*12;W(output,at,(uint)(baseNew+begins[i]));W(output,at+4,(uint)(baseNew+ends[i]));W(output,at+8,(uint)(baseNew+0x7000+uwOffsets[i]));}
  Buffer.BlockCopy(Encoding.ASCII.GetBytes(name),0,output,header,name.Length);W(output,header+8,(uint)vsize);W(output,header+12,(uint)baseNew);W(output,header+16,(uint)rawSize);W(output,header+20,(uint)rawNew);W(output,header+36,0x60000020);
  Buffer.BlockCopy(BitConverter.GetBytes((ushort)(count+1)),0,output,pe+6,2);W(output,opt+56,(uint)A(baseNew+vsize,sa));W(output,opt+136,(uint)(baseNew+0x8000));W(output,opt+140,exSize+(uint)(12*begins.Length));W(output,opt+64,0);
  for(int i=0;i<hooks.Length;i++){byte[] jump=Hook(hooks[i],baseNew+targets[i],originals[i].Length,opcodes[i],tails[i]);Buffer.BlockCopy(jump,0,output,Map(output,hooks[i]),jump.Length);}
  return output;
 }
}
