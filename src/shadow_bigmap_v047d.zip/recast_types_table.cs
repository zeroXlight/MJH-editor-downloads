using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

public static class ShadowRecastTypeItems {
    sealed class Edit { public int Start,End,Value; }
    sealed class JsonScan {
        readonly string text; int p;
        readonly bool enabled;
        readonly HashSet<int> usable,removed;
        readonly List<Edit> edits=new List<Edit>();
        public JsonScan(string text,bool enabled,int[] usable,int[] removed) {
            this.text=text;this.enabled=enabled;
            this.usable=new HashSet<int>(usable);this.removed=new HashSet<int>(removed);
        }
        void Space() {while(p<text.Length && Char.IsWhiteSpace(text[p]))p++;}
        void Expect(char c) {Space();if(p>=text.Length || text[p++]!=c)throw new InvalidDataException("JSON syntax");}
        string String() {
            Expect('"');int start=p;bool escaped=false;
            while(p<text.Length) {
                char c=text[p++];
                if(c=='"')return escaped ? null : text.Substring(start,p-start-1);
                if(c=='\\') {escaped=true;if(p>=text.Length)break;p++;}
            }
            throw new InvalidDataException("JSON string");
        }
        void Value(int depth) {
            if(depth>100)throw new InvalidDataException("JSON nesting");
            Space();if(p>=text.Length)throw new InvalidDataException("JSON end");
            char c=text[p];
            if(c=='"') {String();return;}
            if(c=='{' || c=='[') {
                bool obj=c=='{';p++;Space();char end=obj?'}':']';
                if(p<text.Length && text[p]==end) {p++;return;}
                while(true) {
                    if(obj) {String();Expect(':');}
                    Value(depth+1);Space();
                    if(p<text.Length && text[p]==end) {p++;return;}
                    Expect(',');
                }
            }
            int start=p;
            while(p<text.Length && text[p]!=',' && text[p]!=']' && text[p]!='}' && !Char.IsWhiteSpace(text[p]))p++;
            if(p==start)throw new InvalidDataException("JSON value");
        }
        void Item() {
            Expect('{');int type=0,current=0,types=0,gens=0,start=0,end=0;
            Space();if(p<text.Length && text[p]=='}') {p++;return;}
            while(true) {
                string key=String();Expect(':');Space();int first=p;
                Value(1);int value;
                if(key=="ItemType" && Int32.TryParse(text.Substring(first,p-first),out value)) {type=value;types++;}
                if(key=="RecastAttrGenID" && Int32.TryParse(text.Substring(first,p-first),out value)) {current=value;gens++;start=first;end=p;}
                Space();if(p<text.Length && text[p]=='}') {p++;break;}
                Expect(',');
            }
            if(types!=1 || gens!=1)return;
            int pool=Pool(type),target=0;
            if(enabled && usable.Contains(pool) && (current==1 || usable.Contains(current)))target=pool;
            else if(!enabled && removed.Contains(current))target=1;
            if(target!=0 && target!=current)edits.Add(new Edit{Start=start,End=end,Value=target});
        }
        void Items() {
            Expect('[');Space();if(p<text.Length && text[p]==']') {p++;return;}
            while(true) {
                Space();if(p<text.Length && text[p]=='{')Item();else Value(1);
                Space();if(p<text.Length && text[p]==']') {p++;return;}
                Expect(',');
            }
        }
        public string Run() {
            Expect('{');Space();if(p<text.Length && text[p]=='}') {p++;return text;}
            while(true) {
                string key=String();Expect(':');
                if(key=="Items")Items();else Value(1);
                Space();if(p<text.Length && text[p]=='}') {p++;break;}
                Expect(',');
            }
            Space();if(p!=text.Length)throw new InvalidDataException("JSON trailing data");
            if(edits.Count==0)return text;
            var result=new StringBuilder(text.Length);int start=0;
            foreach(var edit in edits) {result.Append(text,start,edit.Start-start);result.Append(edit.Value);start=edit.End;}
            result.Append(text,start,text.Length-start);return result.ToString();
        }
    }
    public static string UpdateJson(string text,bool enabled,int[] usable,int[] removed) {
        return new JsonScan(text,enabled,usable,removed).Run();
    }
    public static int Pool(int type) {
        switch(type) {
            case 3: return 1900000611;
            case 4: return 1900000612;
            case 5: return 1900000613;
            case 14: return 1900000614;
            case 8: case 9: case 10: case 11: case 12: case 13:
            case 18: case 19: case 27: case 28: case 29: case 30: return 1900000615;
            default: return 0;
        }
    }
    static ulong Read(byte[] b, ref int p, int end) {
        ulong v=0; int shift=0;
        while(p<end && shift<=63) {
            byte x=b[p++];
            if(shift==63 && (x&254)!=0) throw new InvalidDataException("Varint overflow");
            v |= (ulong)(x&127)<<shift;
            if((x&128)==0) return v;
            shift+=7;
        }
        throw new InvalidDataException("Invalid varint");
    }
    static void Write(Stream s, ulong v) {
        while(v>=128) {s.WriteByte((byte)((v&127)|128));v>>=7;}
        s.WriteByte((byte)v);
    }
    static void Skip(byte[] b, ref int p, int end, int wire) {
        if(wire==0) Read(b,ref p,end);
        else if(wire==1) p=checked(p+8);
        else if(wire==5) p=checked(p+4);
        else if(wire==2) {
            ulong n=Read(b,ref p,end);
            if(n>(ulong)(end-p)) throw new InvalidDataException("Field boundary");
            p+=(int)n;
        } else throw new InvalidDataException("Wire type");
        if(p>end) throw new InvalidDataException("Field boundary");
    }
    public static byte[] Update(byte[] data, bool enabled, int[] usableIDs, int[] removedIDs) {
        var usable=new HashSet<int>(usableIDs);var removed=new HashSet<int>(removedIDs);
        using(var output=new MemoryStream(data.Length)) {
            int p=0;bool changed=false;
            while(p<data.Length) {
                int start=p;ulong key=Read(data,ref p,data.Length);
                if(key!=18) {Skip(data,ref p,data.Length,(int)(key&7));output.Write(data,start,p-start);continue;}
                ulong size=Read(data,ref p,data.Length);
                if(size>(ulong)(data.Length-p)) throw new InvalidDataException("Row boundary");
                int begin=p,end=p+(int)size,q=p,type=0,current=0,types=0,gens=0,genStart=0,genEnd=0;
                while(q<end) {
                    int fieldStart=q;ulong tag=Read(data,ref q,end);
                    if(tag==80) {type=unchecked((int)Read(data,ref q,end));types++;}
                    else if(tag==264) {
                        current=unchecked((int)Read(data,ref q,end));gens++;genStart=fieldStart;genEnd=q;
                    } else Skip(data,ref q,end,(int)(tag&7));
                }
                int target=0,pool=Pool(type);
                if(types==1 && gens==1) {
                    if(enabled && usable.Contains(pool) && (current==1 || usable.Contains(current))) target=pool;
                    else if(!enabled && removed.Contains(current)) target=1;
                }
                if(target!=0 && target!=current) {
                    using(var row=new MemoryStream()) {
                        row.Write(data,begin,genStart-begin);
                        Write(row,264);Write(row,(ulong)target);
                        row.Write(data,genEnd,end-genEnd);
                        output.WriteByte(18);Write(output,(ulong)row.Length);
                        row.Position=0;row.CopyTo(output);changed=true;
                    }
                } else output.Write(data,start,end-start);
                p=end;
            }
            return changed ? output.ToArray() : data;
        }
    }
}
