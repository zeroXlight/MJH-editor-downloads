using System;
using System.IO;
using System.Collections.Generic;
public static class ShadowTreasureWood {
 class F {public int Key,Wire,Start,ValueStart,End;public ulong Value;}
 static ulong Var(byte[] b,ref int pos,int end){ulong n=0;int s=0;while(pos<end&&s<64){byte x=b[pos++];n|=(ulong)(x&127)<<s;if(x<128)return n;s+=7;}throw new InvalidDataException("Invalid treasure drop varint");}
 static List<F> Fields(byte[] b){int pos=0;var list=new List<F>();while(pos<b.Length){var f=new F();f.Start=pos;ulong t=Var(b,ref pos,b.Length);f.Key=(int)(t>>3);f.Wire=(int)(t&7);f.ValueStart=pos;if(f.Key==0)throw new InvalidDataException("Invalid field");switch(f.Wire){case 0:f.Value=Var(b,ref pos,b.Length);break;case 1:pos+=8;break;case 2:int len=checked((int)Var(b,ref pos,b.Length));f.ValueStart=pos;pos=checked(pos+len);break;case 5:pos+=4;break;default:throw new InvalidDataException("Invalid wire type");}if(pos>b.Length)throw new InvalidDataException("Field crosses boundary");f.End=pos;list.Add(f);}return list;}
 static byte[] Slice(byte[] b,int p,int n){var x=new byte[n];Buffer.BlockCopy(b,p,x,0,n);return x;}
 static void V(List<byte> b,ulong v){while(v>=128){b.Add((byte)((v&127)|128));v>>=7;}b.Add((byte)v);}

 static ulong N(byte[] row,int key,ulong fallback){foreach(var f in Fields(row))if(f.Key==key&&f.Wire==0)return f.Value;return fallback;}
 static bool Wood(byte[] child){ulong id=N(child,1,0);return id==31672||id==31673;}
 static bool Target(ulong group){return group>=7511&&group<=7564&&(group%10>=1&&group%10<=4);}
 static List<byte[]> Children(byte[] row){var list=new List<byte[]>();foreach(var f in Fields(row))if(f.Key==6&&f.Wire==2)list.Add(Slice(row,f.ValueStart,f.End-f.ValueStart));return list;}
 static void Message(List<byte> output,int key,byte[] value){V(output,(ulong)((key<<3)|2));V(output,(ulong)value.Length);output.AddRange(value);}
 static byte[] Weight(byte[] child,byte[] original,int divisor,bool enabled){
  ulong before=N(original,11,10000),current=N(child,11,10000);
  ulong adjusted=divisor==0?0:before/(ulong)divisor;
  bool known=current==before||current==adjusted||current==before/4||(divisor==0&&(current==before/2||current==before/10));
  if(enabled&&!known)throw new InvalidDataException("Treasure wood weight changed by unknown source");
  if(!enabled&&!known)return child;
  ulong desired=enabled?adjusted:before;
  if(current==desired)return child;
  var output=new List<byte>();bool found=false;
  foreach(var f in Fields(child)){
   if(f.Key==11&&f.Wire==0){V(output,88);V(output,desired);found=true;}
   else output.AddRange(Slice(child,f.Start,f.End-f.Start));
  }
  if(!found){V(output,88);V(output,desired);}
  return output.ToArray();
 }
 static byte[] Edit(byte[] row,byte[] baseline,bool enabled){
  ulong group=N(row,2,8008);
  if(!Target(group))return row;
  if(!enabled&&baseline!=null){var own=Edit(baseline,baseline,true);bool same=row.Length==own.Length;for(int i=0;same&&i<row.Length;i++)same=row[i]==own[i];if(same)return baseline;}
  var current=Children(row);var original=baseline==null?new List<byte[]>():Children(baseline);
  bool currentWood=current.Exists(Wood),originalWood=original.Exists(Wood);
  if(enabled&&currentWood&&!originalWood)throw new InvalidDataException("New wood-bearing drop row requires a current backup: "+N(row,1,0));
  if(!currentWood&&!originalWood)return row;
  var wanted=new List<byte[]>(current);bool setCounts=false;ulong min=0,max=0;
  {
   if(baseline==null)return row;
   for(int i=0;i<original.Count;i++)if(Wood(original[i])){
    ulong id=N(original[i],1,0);bool found=wanted.Exists(x=>N(x,1,0)==id);
    if(!found)wanted.Insert(Math.Min(i,wanted.Count),original[i]);
   }
   // Upgrade a previous release that removed the wood-only row completely.
   if(original.Count>0&&original.TrueForAll(Wood)&&N(row,3,1)==0&&N(row,4,1)==0){setCounts=true;min=N(baseline,3,1);max=N(baseline,4,1);}
   int divisor=group>=7541?0:1;
   for(int i=0;i<wanted.Count;i++)if(Wood(wanted[i])){
    ulong id=N(wanted[i],1,0);var before=original.Find(x=>N(x,1,0)==id);
    if(before!=null)wanted[i]=Weight(wanted[i],before,divisor,enabled);
   }
   // Native count bounds 0/0 mean one draw, not disabled. Remove forbidden
   // candidates instead of relying on weight/count zero handling.
   if(enabled&&group>=7541)wanted.RemoveAll(Wood);
   if(enabled&&wanted.Count==0){setCounts=true;min=0;max=0;}
  }
  var output=new List<byte>();bool childrenWritten=false,hasMin=false,hasMax=false;
  foreach(var f in Fields(row)){
   if(f.Key==6&&f.Wire==2){if(!childrenWritten){foreach(var c in wanted)Message(output,6,c);childrenWritten=true;}continue;}
   if(setCounts&&(f.Key==3||f.Key==4)&&f.Wire==0){hasMin|=f.Key==3;hasMax|=f.Key==4;V(output,(ulong)(f.Key<<3));V(output,f.Key==3?min:max);continue;}
   output.AddRange(Slice(row,f.Start,f.End-f.Start));
  }
  if(!childrenWritten)foreach(var c in wanted)Message(output,6,c);
  if(setCounts&&!hasMin){V(output,24);V(output,min);}if(setCounts&&!hasMax){V(output,32);V(output,max);}
  return output.ToArray();
 }
 public static byte[] Update(byte[] input,byte[] baseline,bool enabled){
  var originals=new Dictionary<ulong,byte[]>();
  foreach(var f in Fields(baseline))if(f.Key==2&&f.Wire==2){var row=Slice(baseline,f.ValueStart,f.End-f.ValueStart);ulong id=N(row,1,0);if(originals.ContainsKey(id))throw new InvalidDataException("Duplicate baseline drop row");originals[id]=row;}
  var output=new List<byte>();var seen=new HashSet<ulong>();
  foreach(var f in Fields(input)){
   if(f.Key==2&&f.Wire==2){var row=Slice(input,f.ValueStart,f.End-f.ValueStart);ulong id=N(row,1,0);if(!seen.Add(id))throw new InvalidDataException("Duplicate input drop row");byte[] before;originals.TryGetValue(id,out before);var changed=Edit(row,before,enabled);Message(output,2,changed);}
   else output.AddRange(Slice(input,f.Start,f.End-f.Start));
  }
  return output.ToArray();
 }
}
