﻿# Installed configuration lives outside the release folder, so upgrades can reuse it.
function Get-LastInstallConfigPath([string]$Dir) {
    return Join-Path $Dir 'mod\暗影mod\配置\上次安装.json'
}

function Read-LastInstallSwitches([string]$Dir) {
    # Use installer defaults, never the current player's edited switch document.
    $sw = @{}
    foreach ($k in $FEAT_DEF.Values) { $sw[$k] = ($FEAT_DEFAULT_OFF -notcontains $k) }
    $sw['balance.outcrackcount'] = 2
    $sw['optimize.mazeautolootinterval'] = 0.5
    $sw['__found'] = $true
    $sw['__seen'] = @{}
    $sw['__bad'] = @()
    $path = Get-LastInstallConfigPath $Dir
    if (-not (Test-Path -LiteralPath $path)) {
        Say '      未找到上次安装配置，本次使用当前版本默认配置。'
        return $sw
    }
    try {
        $doc = [IO.File]::ReadAllText($path, [Text.Encoding]::UTF8) | ConvertFrom-Json
        if ($null -eq $doc -or $doc.Schema -ne 1 -or $null -eq $doc.Switches) { throw '格式不支持' }
        foreach ($p in $doc.Switches.PSObject.Properties) {
            if ($FEAT_DEF.Values -contains $p.Name) {
                if ($p.Value -isnot [bool]) { throw ('开关值不是布尔值：' + $p.Name) }
                $sw[$p.Name] = $p.Value
                $sw['__seen'][$p.Name] = $true
            }
            elseif ($p.Name -eq 'balance.outcrackcount') {
                if ($p.Value -isnot [int] -and $p.Value -isnot [long]) { throw '裂纹数必须是整数' }
                if ($p.Value -lt 0 -or $p.Value -gt 7) { throw '裂纹数必须为0～7' }
                $sw[$p.Name] = [int]$p.Value
            }
            elseif ($p.Name -eq 'optimize.mazeautolootinterval') {
                if ($p.Value -is [bool] -or $p.Value -isnot [ValueType] -or [double]$p.Value -le 0 -or [double]::IsNaN([double]$p.Value) -or [double]::IsInfinity([double]$p.Value)) {throw '迷宫自动拾取间隔必须是大于0的秒数'}
                $sw[$p.Name] = [double]$p.Value
            }
            # Removed/unknown historical feature keys do not belong to this version.
        }
    } catch { throw ('上次安装配置无法读取：' + $path + '；' + $_.Exception.Message + '。可使用普通安装入口重新配置。') }
    return $sw
}

function Sync-SwitchDocuments([string]$Dir, $sw, [switch]$PackageOnly) {
    $path = Join-Path $ROOT $SWITCH_NAME
    $enc = [Text.Encoding]::GetEncoding(936)
    $lines = @()
    $seen = @{}
    if (Test-Path -LiteralPath $path) {
        foreach ($line in ([IO.File]::ReadAllText($path, $enc) -split "`r?`n")) {
            $m = [regex]::Match($line, '^\s*(.+?)\s*[:：=]\s*(\d+(?:\.\d+)?)\s*$')
            $key = $null
            if ($m.Success) {
                $name = $m.Groups[1].Value.Trim()
                if ($FEAT_DEF.Contains($name)) { $key = $FEAT_DEF[$name] }
                elseif ($FEAT_NAME.ContainsKey($name)) { $key = $name }
                if ($key) {
                    if (-not $seen.ContainsKey($key)) {
                        $value = if ($sw[$key]) { 1 } else { 0 }
                        $lines += ($FEAT_NAME[$key] + ':' + $value)
                        $seen[$key] = $true
                    }
                    continue
                }
                if ($name -eq '迷宫自动拾取间隔' -or $name -eq 'optimize.mazeautolootinterval') {
                    if (-not $seen.ContainsKey('optimize.mazeautolootinterval')) {
                        $lines += ('迷宫自动拾取间隔:' + ([double]$sw['optimize.mazeautolootinterval']).ToString([Globalization.CultureInfo]::InvariantCulture))
                        $seen['optimize.mazeautolootinterval'] = $true
                    }
                    continue
                }
                if ($name -eq '副本带出7裂纹数配置' -or $name -eq 'balance.outcrackcount') {
                    if (-not $seen.ContainsKey('balance.outcrackcount')) {
                        $lines += ('副本带出7裂纹数配置:' + $sw['balance.outcrackcount'])
                        $seen['balance.outcrackcount'] = $true
                    }
                    continue
                }
            }
            $lines += $line
        }
    }
    foreach ($name in $FEAT_DEF.Keys) {
        $key = $FEAT_DEF[$name]
        if (-not $seen.ContainsKey($key)) {
            $value = if ($sw[$key]) { 1 } else { 0 }
            $lines += ($name + ':' + $value)
        }
    }
    if (-not $seen.ContainsKey('balance.outcrackcount')) { $lines += ('副本带出7裂纹数配置:' + $sw['balance.outcrackcount']) }
    if (-not $seen.ContainsKey('optimize.mazeautolootinterval')) {
        $lines += ('迷宫自动拾取间隔:' + ([double]$sw['optimize.mazeautolootinterval']).ToString([Globalization.CultureInfo]::InvariantCulture))
    }
    [IO.File]::WriteAllText($path, (($lines -join "`r`n").TrimEnd() + "`r`n"), $enc)
    $packageRuntime = Join-Path $ROOT '_build\features_runtime.txt'
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $packageRuntime))
    Write-RuntimeSwitches $packageRuntime $sw
    if (-not $PackageOnly) {
        $runtime = Join-Path $Dir $SWITCH_REL
        [void][IO.Directory]::CreateDirectory((Split-Path -Parent $runtime))
        Write-RuntimeSwitches $runtime $sw
    }
}

function Save-LastInstallSwitches([string]$Dir, $sw) {
    $values = [ordered]@{}
    foreach ($key in $FEAT_DEF.Values) { $values[$key] = [bool]$sw[$key] }
    $values['balance.outcrackcount'] = [int]$sw['balance.outcrackcount']
    $values['optimize.mazeautolootinterval'] = [double]$sw['optimize.mazeautolootinterval']
    $doc = [ordered]@{ Schema = 1; Switches = $values }
    $path = Get-LastInstallConfigPath $Dir
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $path))
    $temp = $path + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($temp, ($doc | ConvertTo-Json -Depth 4), (New-Object Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $temp -Destination $path -Force
    } finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp }
    }
    Say ('      已保存本次成功安装配置：' + $path)
}
