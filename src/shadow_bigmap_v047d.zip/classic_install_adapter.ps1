﻿function Get-ClassicInstallPlan([string]$Dir,$Switches,[string]$ResourceDir,$EditorPlan=$null) {
    . (Join-Path $ResourceDir 'patch_classic_bundle.ps1')
    . (Join-Path $ResourceDir 'patch_fragment.ps1')
    . (Join-Path $ResourceDir 'patch_uncollectible_cap.ps1')
    . (Join-Path $ResourceDir 'patch_custom_martials.ps1')
    function Source-Bytes([string]$relative) {
        $path=[IO.Path]::GetFullPath((Join-Path $Dir $relative))
        if($null -ne $EditorPlan -and $EditorPlan.Files.ContainsKey($path)) {return ,([byte[]]$EditorPlan.Files[$path].Before)}
        return ,([IO.File]::ReadAllBytes($path))
    }
    [byte[]]$inputDll=Source-Bytes 'DreamRivakes_Data\Plugins\RaceLogic_Release_x64.dll'
    # Validate native ownership before creating even temporary table fixtures.
    $normalized=Update-ClassicNativeBundle $inputDll @{} $ResourceDir @() @() -BestEffort
    foreach($issue in @($normalized.Skipped)){Add-InstallSkip $issue.Keys $issue.Reason}
    [byte[]]$clientInput=Source-Bytes 'DreamRivakes_Data\Plugins\ClientDll.dll'
    try {$client=Update-MartialJsonFix $clientInput ([bool]($Switches['fix.martialjson'] -or $Switches['fix.taichain'] -or $Switches['balance.taichain'])) $ResourceDir}
    catch {Add-InstallSkip @('fix.martialjson','fix.taichain','balance.taichain') $_.Exception.Message '武学添加/修改及铸剑客户端修复';$client=$clientInput}
    $temp=Join-Path ([IO.Path]::GetTempPath()) ('ShadowClassicPreflight_'+[Guid]::NewGuid().ToString('N'))
    [byte[]]$pool=@();[byte[]]$ids=@()
    try {
        [void][IO.Directory]::CreateDirectory($temp)
        [IO.File]::WriteAllBytes((Join-Path $temp 'Martial.bytes'),(Source-Bytes 'TableData\Martial.bytes'))
        [byte[]]$itemInput=Source-Bytes 'TableData\Item.bytes'
        try {$items=Update-FragmentItemTable $itemInput ([bool]$Switches['optimize.fragment'])}
        catch {Add-InstallSkip @('optimize.fragment') $_.Exception.Message '残章掉落优化';$items=$itemInput}
        [IO.File]::WriteAllBytes((Join-Path $temp 'Item.bytes'),$items)
        if($Switches['optimize.fragment']) {try {$pool=Get-FragmentPool $temp}catch{Add-InstallSkip @('optimize.fragment') $_.Exception.Message '残章掉落优化'}}
        if($Switches['optimize.uncollectiblecap']) {try {$ids=Get-UncollectibleCapIds $temp}catch{Add-InstallSkip @('optimize.uncollectiblecap') $_.Exception.Message '不可收藏武学等级上限'}}
        $plan=Update-ClassicNativeBundle $normalized.Original $Switches $ResourceDir $pool $ids -BestEffort
        foreach($issue in @($plan.Skipped)){Add-InstallSkip $issue.Keys $issue.Reason}
        $plan.Input=$inputDll;$plan.Client=$client;$plan.FragmentPool=$pool;$plan.CapIds=$ids
        return $plan
    } finally {
        foreach($name in @('Martial.bytes','Item.bytes')) {
            $path=Join-Path $temp $name
            if(Test-Path -LiteralPath $path) {[IO.File]::Delete($path)}
        }
        if(Test-Path -LiteralPath $temp) {[IO.Directory]::Delete($temp)}
    }
}

function Test-ClassicNativeBytes([byte[]]$Before,[byte[]]$After) {
    $sha=[Security.Cryptography.SHA256]::Create()
    try {return ([BitConverter]::ToString($sha.ComputeHash($Before)) -eq [BitConverter]::ToString($sha.ComputeHash($After)))} finally {$sha.Dispose()}
}
