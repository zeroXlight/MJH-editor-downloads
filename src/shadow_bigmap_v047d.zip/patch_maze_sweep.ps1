﻿function Initialize-MazeSweep([string]$ResourceDir) {
    if (-not ('ShadowMazeSweep' -as [type])) { Add-Type -Path (Join-Path $ResourceDir 'maze_sweep_native.cs') }
}
function Convert-MazeSweepHex([string]$Hex) {
    $Hex=$Hex.Trim();if($Hex -notmatch '^[0-9a-fA-F]+$' -or $Hex.Length%2){throw 'Invalid maze sweep hex'}
    [byte[]]$bytes=New-Object byte[] ($Hex.Length/2)
    for($i=0;$i -lt $bytes.Length;$i++){$bytes[$i]=[Convert]::ToByte($Hex.Substring($i*2,2),16)}
    return ,$bytes
}
function Update-MazeSweep([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    . (Join-Path $ResourceDir 'game_build.ps1')
    if((Get-ShadowGameBuild $Data).Family -eq 'classic') {
        . (Join-Path $ResourceDir 'patch_classic_section.ps1')
        return ,(Update-ClassicSection $Data $Enabled (Get-ShadowNativeLayoutPath $Data $ResourceDir 'maze_sweep_section_layout.json'))
    }
    Initialize-MazeSweep $ResourceDir
    $meta=[IO.File]::ReadAllText((Join-Path $ResourceDir 'maze_sweep_layout.json')) | ConvertFrom-Json
    $code=Convert-MazeSweepHex ([IO.File]::ReadAllText((Join-Path $ResourceDir 'maze_sweep_code.hex')))
    [int[]]$offsets=@($meta.relocations | ForEach-Object { $_[0] });[int[]]$targets=@($meta.relocations | ForEach-Object { $_[1] })
    [int[]]$rvas=@($meta.guards | ForEach-Object { $_[0] });[int[]]$sizes=@($meta.guards | ForEach-Object { $_[1] });[string[]]$hashes=@($meta.guards | ForEach-Object { $_[2] })
    $orig=Convert-MazeSweepHex $meta.originalHook
    return ,[ShadowMazeSweep]::Update($Data,$Enabled,$code,$offsets,$targets,$orig,$meta.hook,$meta.shimLength,$meta.driverLength,$meta.cloneLength,$meta.cloneUnwind,$meta.originalExceptionRva,$meta.originalExceptionSize,[string[]]$meta.legacyDriverHashes,$rvas,$sizes,$hashes)
}
function Update-MazeSweepTags([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    Initialize-MazeSweep $ResourceDir
    $meta=[IO.File]::ReadAllText((Join-Path $ResourceDir 'maze_sweep_layout.json')) | ConvertFrom-Json
    return ,[ShadowMazeSweep]::Tags($Data,$Enabled,[uint32[]]$meta.tags)
}
