﻿# Must strip this last section before updating fragment/carryout sections.
$script:UncollectibleCapGuards=@(
    @(0x4e4820,746,'D5C38D823A4011336723656EEC4D105D939A555A29C55A71ED6F6C2823A2E41E'),
    @(0x464ff0,167,'D2C88076BEE39BC1D1BD9AB9CD635CC6E0989FD7D0D195A13AD7B20A1D37A264'),
    @(0x4725a0,196,'A580E3C6B2F24ABB3A76521F13AD5090FF4F46FDC95DFEE5370A5D3D69283150'),
    @(0x6ec380,14,'E5A207E5411C42015FE7E65D1C6F5B61F956E09509B453AAAAE1C3DB3C543464')
)
function Get-UncollectibleCapIds([string]$TableDir) {
    $preparsed = Get-PreparsedMartialResult $TableDir Cap
    if ($null -ne $preparsed) { return ,$preparsed }
    $tables=Get-FragmentSourceTables $TableDir
    $martials=$tables.Martials
    $items=$tables.Items
    $collectible=@{};foreach($r in (Get-FragmentExtras)) {$collectible[[long]$r.MartialID]=$true}
    foreach($it in $items.Values) {
        if($it[10] -ne 16 -or ($it['Feature'] -band 16) -or -not $martials.ContainsKey($it[36])) {continue}
        $m=$martials[$it[36]]
        if(($m.ContainsKey(8) -and $m[8] -ne 0) -or $m[18] -ne 1 -or $m[24] -ne 1) {continue}
        $collectible[$it[36]]=$true
    }
    $ids=New-Object 'System.Collections.Generic.List[byte]'
    foreach($mid in ($martials.Keys | Sort-Object)) {
        if($mid -notin @(12234,13016) -and -not $collectible.ContainsKey($mid)) {$ids.AddRange([BitConverter]::GetBytes([uint32]$mid))}
    }
    if($ids.Count -eq 0 -or $ids.Count -gt 1536*4) {throw 'Invalid uncollectible martial list'}
    return ,$ids.ToArray()
}
function Update-UncollectibleCap([byte[]]$Data,$Switches,[string]$CodePath,[byte[]]$Ids=@()) {
    $resourceDir=Split-Path $CodePath -Parent
    . (Join-Path $resourceDir 'game_build.ps1')
    if((Get-ShadowGameBuild $Data).Family -eq 'classic') {
        $enabled=[bool]$Switches['optimize.uncollectiblecap']
        [byte[]]$payload=@()
        if($enabled) {
            if($Ids.Length -eq 0 -or $Ids.Length%4 -or $Ids.Length -gt 1536*4) {throw 'Invalid classic cap list'}
            $payload=New-Object byte[] (0x400+$Ids.Length)
            [BitConverter]::GetBytes([uint32]($Ids.Length/4)).CopyTo($payload,0)
            $Ids.CopyTo($payload,0x400)
        }
        . (Join-Path $resourceDir 'patch_classic_section.ps1')
        return ,(Update-ClassicSection $Data $enabled (Get-ShadowNativeLayoutPath $Data $resourceDir 'uncollectible_cap_layout.json') $payload)
    }
    [byte[]]$b=$Data.Clone()
    function UCH([int]$o,[int]$n) {[BitConverter]::ToString($b,$o,$n).Replace('-','')}
    function UCP([int]$o,[uint32]$v) {[BitConverter]::GetBytes($v).CopyTo($b,$o)}
    $hex=[IO.File]::ReadAllText($CodePath).Trim()
    if($hex -notmatch '^[0-9A-F]+$' -or $hex.Length%2 -or $hex.Length -ge 0x800) {throw 'Invalid martial cap code'}
    [byte[]]$code=New-Object byte[] ($hex.Length/2)
    for($i=0;$i -lt $code.Length;$i++) {$code[$i]=[Convert]::ToByte($hex.Substring($i*2,2),16)}
    $pe=[BitConverter]::ToInt32($b,0x3c);$opt=$pe+24
    if($pe -ne 0x100 -or (UCH $pe 6) -ne '504500006486') {throw 'Unsupported martial cap PE'}
    $table=$opt+[BitConverter]::ToUInt16($b,$pe+20);$count=[BitConverter]::ToUInt16($b,$pe+6)
    $last=$table+($count-1)*40;$hook=0x4e3c20;$orig='8954241048894C2408'
    [byte[]]$jump=0xe9,0,0,0,0,0x90,0x90,0x90,0x90
    [BitConverter]::GetBytes([int](0x1b43000-0x4e4820-5)).CopyTo($jump,1)
    $jumpHex=[BitConverter]::ToString($jump).Replace('-','')
    if((UCH $last 8) -eq '2E64796361700000') {
        $raw=[BitConverter]::ToUInt32($b,$last+20)
        $sectionRva=[BitConverter]::ToUInt32($b,$last+12);$span=0x1b45000-$sectionRva;$offset=0x1b43000-$sectionRva
        if($sectionRva -notin @(0x1b40000,0x1b41000,0x1b43000)) {throw 'Invalid cap RVA'}
        $capRaw=$raw+$offset
        if($count -notin @(8,9,10) -or $b.Length -ne $raw+$span -or (UCH $hook 9) -ne $jumpHex -or [BitConverter]::ToUInt32($b,$opt+56) -ne 0x1b45000) {throw 'Unknown martial cap installation'}
        [byte[]]$header=New-Object byte[] 40;[Text.Encoding]::ASCII.GetBytes('.dycap').CopyTo($header,0)
        foreach($v in @(@(8,$span),@(12,$sectionRva),@(16,$span),@(20,$raw),@(36,0x60000020))) {[BitConverter]::GetBytes([uint32]$v[1]).CopyTo($header,$v[0])}
        if((UCH $last 40) -ne [BitConverter]::ToString($header).Replace('-','')) {throw 'Unknown martial cap header'}
        $n=[BitConverter]::ToUInt32($b,$capRaw+0x400)
        if($n -eq 0 -or $n -gt 1536) {throw 'Invalid installed martial cap list'}
        [byte[]]$expected=New-Object byte[] $span;$code.CopyTo($expected,$offset)
        $legacySha=[Security.Cryptography.SHA256]::Create()
        $legacyHash=[BitConverter]::ToString($legacySha.ComputeHash($b,$capRaw,186)).Replace('-','');$bonusLegacyHash=[BitConverter]::ToString($legacySha.ComputeHash($b,$capRaw,237)).Replace('-','');$attainedLegacyHash=[BitConverter]::ToString($legacySha.ComputeHash($b,$capRaw,214)).Replace('-','');$legacySha.Dispose()
        if($legacyHash -eq '2AC9DFAE2BDFCC038CD74B67209EF09662A2B05459C1427A2F0BE118C5562666') {
            [Array]::Clear($expected,$offset,0x400)
            [Array]::Copy($b,$capRaw,$expected,$offset,186)
        }
        if($bonusLegacyHash -eq '5BF776BB57C5A39790E472A141637C531391AB84FC6ABADEBE5B99B74448F10B') {
            [Array]::Clear($expected,$offset,0x400)
            [Array]::Copy($b,$capRaw,$expected,$offset,237)
        }
        if($attainedLegacyHash -eq '9DE30862CAE42FB00388AA778841B7CCB4191E05E722CC682F59426C432C6603') {
            [Array]::Clear($expected,$offset,0x400)
            [Array]::Copy($b,$capRaw,$expected,$offset,214)
        }
        [Array]::Copy($b,$capRaw+0x400,$expected,($offset+0x400),4);[Array]::Copy($b,$capRaw+0x800,$expected,($offset+0x800),$n*4)
        if((UCH $raw $span) -ne [BitConverter]::ToString($expected).Replace('-','')) {throw 'Unknown martial cap bytes'}
        [Array]::Clear($b,$last,40);$count--;[BitConverter]::GetBytes([uint16]$count).CopyTo($b,$pe+6)
        $prev=$table+($count-1)*40;$end=[BitConverter]::ToUInt32($b,$prev+12)+[BitConverter]::ToUInt32($b,$prev+8)
        UCP ($opt+56) ([uint32](([math]::Ceiling($end/0x1000))*0x1000))
        [byte[]]$restore=0x89,0x54,0x24,0x10,0x48,0x89,0x4c,0x24,0x08;$restore.CopyTo($b,$hook)
        [Array]::Resize([ref]$b,[int]$raw)
    }
    if((UCH $hook 9) -ne $orig) {throw 'Unknown original martial max-level function'}
    if((UCH (0x28a310-0xc00) 17) -ne '48894C2408488B4424088B8084000000C3') {throw 'Unsupported martial attained-level field'}
    # Full original authoritative cap and native difficulty getter guards.
    $sha=[Security.Cryptography.SHA256]::Create()
    foreach($g in $script:UncollectibleCapGuards) {
        if([BitConverter]::ToString($sha.ComputeHash($b,$g[0]-0xc00,$g[1])).Replace('-','') -ne $g[2]) {throw 'Unsupported martial cap native API'}
    }
    $sha.Dispose()
    if(-not $Switches['optimize.uncollectiblecap']) {return ,$b}
    if($count -notin @(7,8,9) -or $Ids.Length -eq 0 -or $Ids.Length%4 -or $Ids.Length -gt 1536*4 -or $table+($count+1)*40 -gt 0x400) {throw 'Invalid martial cap parent/list'}
    $section=$table+$count*40
    if((UCH $section 40) -ne ('00'*40)) {throw 'Martial cap section header occupied'}
    $prev=$table+($count-1)*40
    if($count -gt 7 -and (UCH $prev 8) -notin @('2E64796672616700','2E64796F75740000')) {throw 'Unsupported martial cap parent section'}
    $raw=[BitConverter]::ToUInt32($b,$prev+20)+[BitConverter]::ToUInt32($b,$prev+16)
    if($b.Length -ne $raw) {throw 'Unexpected martial cap overlay'}
    $parentEnd=[BitConverter]::ToUInt32($b,$prev+12)+[BitConverter]::ToUInt32($b,$prev+8)
    $sectionRva=[int]([math]::Ceiling($parentEnd/0x1000)*0x1000);$span=0x1b45000-$sectionRva;$capRaw=$raw+0x1b43000-$sectionRva
    if($sectionRva -notin @(0x1b40000,0x1b41000,0x1b43000)) {throw 'Unsupported cap parent RVA'}
    [byte[]]$new=New-Object byte[] ($raw+$span);$b.CopyTo($new,0);$b=$new
    [Text.Encoding]::ASCII.GetBytes('.dycap').CopyTo($b,$section)
    UCP ($section+8) $span;UCP ($section+12) $sectionRva;UCP ($section+16) $span;UCP ($section+20) $raw;UCP ($section+36) 0x60000020
    [BitConverter]::GetBytes([uint16]($count+1)).CopyTo($b,$pe+6);UCP ($opt+56) 0x1b45000
    $code.CopyTo($b,$capRaw);UCP ($capRaw+0x400) ($Ids.Length/4);$Ids.CopyTo($b,$capRaw+0x800);$jump.CopyTo($b,$hook)
    return ,$b
}
