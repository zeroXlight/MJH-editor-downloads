﻿# Official JSON overlay. Both switches are independent; no save edits.
function Sync-TaiAChain([string]$Dir,[bool]$Fix,[bool]$Balance,[string]$ResourceDir) {
    $target=Join-Path $Dir 'ModProject\GameProject\Mod_MJH\Json'
    $kinds=@('Martial','MartialItem','Skill','SkillEffect','Buff','Language')
    if(-not ($Fix -or $Balance)) {
        foreach($kind in $kinds) {
            $path=Join-Path $target ($kind+'_ShadowTaiA.json')
            if(Test-Path -LiteralPath $path) {Remove-Item -LiteralPath $path -Force}
        }
        return
    }
    $tables=Get-Content -LiteralPath (Join-Path $ResourceDir 'tai_a_chain_tables.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $probability=if($Balance) {1900041107} else {450174001}
    $condition=if($Fix) {1900041100} else {$probability}
    $effect=if($Fix) {1900041104} else {450174009}
    $tables.Skill.Items[0].SkillTriggers[0].ConditionID=$condition
    $tables.Skill.Items[0].SkillTriggers[0].EffectID=$effect
    ($tables.SkillEffect.Items | Where-Object {$_.BaseID -eq 1900041101}).EventArg2=@(0,$probability)
    $percent=if($Balance) {2} else {10}
    $description='梦·泰阿剑法释放后，每层铸剑蓄力有'+$percent+'%概率再次释放。'
    if($Fix) {$description+='一轮连击最多释放10次（含首次）。'}
    $language=$tables.Language.Items | Where-Object {$_.BaseID -eq 1900041202}
    $language.Text=$description;$language.Ch_Text=$description
    # Validate all six documents before changing any deployed file.
    $encoded=@{}
    foreach($kind in $kinds) {$encoded[$kind]=$tables.$kind | ConvertTo-Json -Depth 64}
    [void][IO.Directory]::CreateDirectory($target)
    foreach($kind in $kinds) {[IO.File]::WriteAllText((Join-Path $target ($kind+'_ShadowTaiA.json')),$encoded[$kind],(New-Object Text.UTF8Encoding($false)))}
}
