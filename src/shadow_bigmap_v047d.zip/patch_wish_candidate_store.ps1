﻿function Update-WishCandidateStore([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    if(-not ('ShadowWishCandidateStore' -as [type])){Add-Type -Path (Join-Path $ResourceDir 'wish_candidate_store_native.cs')}
    . (Join-Path $ResourceDir 'game_build.ps1')
    $meta=Get-Content -LiteralPath (Get-ShadowNativeLayoutPath $Data $ResourceDir 'wish_candidate_store_layout.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    function WishStore-Bytes([string]$Hex){
        if($Hex -notmatch '^(?:[0-9a-fA-F]{2})+$'){throw 'Invalid wish store hex'}
        [byte[]]$b=New-Object byte[] ($Hex.Length/2)
        for($i=0;$i -lt $b.Length;$i++){$b[$i]=[Convert]::ToByte($Hex.Substring(2*$i,2),16)}
        return ,$b
    }
    [int[]]$offsets=@($meta.relocations | ForEach-Object {$_[0]});[int[]]$targets=@($meta.relocations | ForEach-Object {$_[1]});[int[]]$local=@($meta.relocations | ForEach-Object {$_[2]})
    [int[]]$patchRvas=@($meta.patches | ForEach-Object {$_.rva})
    $originals=New-Object 'System.Collections.Generic.List[byte[]]';$patched=New-Object 'System.Collections.Generic.List[byte[]]'
    foreach($p in $meta.patches){$originals.Add((WishStore-Bytes $p.original));$patched.Add((WishStore-Bytes $p.patched))}
    [int[]]$guardRvas=@($meta.guards | ForEach-Object {$_.rva});[int[]]$sizes=@($meta.guards | ForEach-Object {$_.size});[string[]]$hashes=@($meta.guards | ForEach-Object {$_.sha256})
    [int[]]$hooks=@($meta.hooks | ForEach-Object {$_.rva});[int[]]$entries=@($meta.hooks | ForEach-Object {$_.entry})
    $originalHooks=New-Object 'System.Collections.Generic.List[byte[]]'
    foreach($h in $meta.hooks){$originalHooks.Add((WishStore-Bytes $h.original))}
    [int[]]$begins=@($meta.entries | ForEach-Object {$_[0]});[int[]]$ends=@($meta.entries | ForEach-Object {$_[1]})
    return ,[ShadowWishCandidateStore]::Update($Data,$Enabled,(WishStore-Bytes $meta.code),$offsets,$targets,$local,$hooks,$originalHooks.ToArray(),$entries,$begins,$ends,(WishStore-Bytes $meta.unwindCode),$patchRvas,$originals.ToArray(),$patched.ToArray(),$guardRvas,$sizes,$hashes)
}
