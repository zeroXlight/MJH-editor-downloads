﻿# Installation results are separate from the player's requested configuration.
function Reset-InstallResults {
    $SCRIPT:INSTALL_SKIPS=New-Object 'System.Collections.Generic.List[object]'
}
function Add-InstallSkip([string[]]$Keys,[string]$Reason,[string]$Label='',[bool]$Disable=$true) {
    if(-not (Get-Variable -Scope Script -Name INSTALL_SKIPS -ErrorAction SilentlyContinue)){Reset-InstallResults}
    $SCRIPT:INSTALL_SKIPS.Add([pscustomobject]@{Keys=@($Keys);Label=$Label;Reason=$Reason})
    if($Disable -and (Get-Variable -Scope Script -Name SW -ErrorAction SilentlyContinue)){foreach($key in $Keys){$SCRIPT:SW[$key]=$false}}
    if(Get-Command Say -ErrorAction SilentlyContinue){Say ('      ! 本次跳过 '+$(if($Label){$Label}else{$Keys -join ' / '})+'：'+$Reason)}
}
function Invoke-OptionalInstallStep([string]$Dir,[string[]]$Keys,[string[]]$Paths,[scriptblock]$Action,[string]$Label='') {
    $saved=@{};$base=[IO.Path]::GetFullPath($Dir).TrimEnd('\')+'\'
    foreach($rel in $Paths){
        $path=[IO.Path]::GetFullPath((Join-Path $Dir $rel))
        if(-not $path.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)){throw 'Install step path leaves game directory'}
        $saved[$path]=if(Test-Path -LiteralPath $path){[IO.File]::ReadAllBytes($path)}else{$null}
    }
    try {& $Action;return $true}
    catch {
        $reason=$_.Exception.Message
        foreach($path in $saved.Keys){if($null -eq $saved[$path]){if(Test-Path -LiteralPath $path){[IO.File]::Delete($path)}}else{[IO.File]::WriteAllBytes($path,$saved[$path])}}
        Add-InstallSkip $Keys $reason $Label
        return $false
    }
}
function Write-InstallResultSummary([string]$Dir) {
    if(-not (Get-Variable -Scope Script -Name INSTALL_SKIPS -ErrorAction SilentlyContinue)) {return}
    $lines=New-Object 'System.Collections.Generic.List[string]'
    if($SCRIPT:INSTALL_SKIPS.Count -eq 0){$lines.Add('本次未发现功能安装失败。')}
    else {
        $lines.Add('安装完成，但以下功能/组件本次未安装或未更新；其余功能继续安装：')
        foreach($item in $SCRIPT:INSTALL_SKIPS){
            $names=@();foreach($key in $item.Keys){$found=$false;foreach($name in $FEAT_DEF.Keys){if($FEAT_DEF[$name] -eq $key){$names+=$name;$found=$true;break}};if(-not $found){$names+=$key}}
            $label=if($item.Label){$item.Label}else{$names -join '、'}
            $lines.Add('未安装/未更新：'+$label+'；原因：'+$item.Reason)
        }
        $lines.Add('已保留玩家原先的开关选择；再次安装会重新尝试。未知冲突文件未被盲目覆盖。')
    }
    foreach($line in $lines){Say ('  '+$line)}
    $folder=Join-Path $Dir 'mod\暗影mod\配置';[void][IO.Directory]::CreateDirectory($folder)
    [IO.File]::WriteAllLines((Join-Path $folder '本次安装结果.txt'),$lines.ToArray(),[Text.UTF8Encoding]::new($true))
}
