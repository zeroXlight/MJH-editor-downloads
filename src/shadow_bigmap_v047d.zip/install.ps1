﻿# =====================================================================
#  梦江湖 · 暗影MOD合集  —— 一键安装 / 卸载
#
#  ★ 用法：把整个压缩包解压到【游戏主目录】里再运行。
#    "游戏主目录" = 那个里面有 DreamRivakes.exe 的 xiake 文件夹。
#    解压后会变成  xiake\梦江湖_暗影MOD合集_vX.Y\ ，在里面双击
#    1-安装.bat 即可。脚本会认出自己就站在游戏目录里，不需要你找路径。
#    （解压出来的这个文件夹看完再删；卸载脚本还要用它。）
#
#  ★ 装 / 卸之前一定先【完全退出游戏】—— 表文件被游戏占着的时候写不进去。
#    安装器会自己检测：发现游戏还开着就立刻停下并说明，不会写坏任何东西。
#    整个过程会记一份流水在包目录下的「安装日志.txt」，出问题直接看它。
#
#  本合集包含三个 MOD，安装器一次全部装好：
#
#  【MOD 1】暗影优化mod
#    ① 让原本"专属"的武学 / 天赋出现在 NPC 的请教列表里；
#    ② 学会之后不再被"归属白名单"拦下。
#    构成：数据层 TableData\Martial.bytes（解除专属武学的归属限制，原地打补丁）
#          + 插件层 winhttp.dll / BepInEx\（BepInEx 5.x 运行时）
#          + 钩子层 BepInEx\plugins\XiakeConsultFix.dll
#            （v0.23 起它只是引导器：启动时才去读下面的脚本）
#          + 逻辑层 BepInEx\plugins\XiakeConsultFix\consult_hook.lua
#            （明文 Lua，请教列表显示规则 + 指点子系统都在这里）
#            —— 想改开关不必重装，改完存盘重启游戏即可
#
#  【MOD 2】暗影修复mod
#    开局赠送的道具「冒险手札」本该把 9 类冒险天赋拉满 5 级，
#    实际漏掉了「食材搜刮」—— 这是原版表里的一个笔误。
#    构成：数据层 TableData\Behavior.bytes（改一个字段，等长原位覆盖）
#
#  【MOD 3】暗影平衡mod
#    给「请教 / 指点」加上好感的付出与回报：请教成功扣好感、指点成功加好感
#    （按武学 / 天赋档位 1~6），并且两边都要对方好感 ≥ 20 才能进行
#    （和原版「切磋」同一个门槛）。全部走客户端判定，不碰服务端。
#    构成：钩子层 BepInEx\plugins\XiakeConsultFix\consult_hook.lua
#
#  ★ 服务端闸门补丁（属于 MOD 1 的「心愿/专属不占数量上限」）
#    数量上限的最终裁定在游戏原生层（DreamRivakes_Data\Plugins\
#    RaceLogic_Release_x64.dll），它不认识本 MOD 的计数口径，会按原始条数拦人 ——
#    表现为「角色面板显示 x/y 是对的，用秘籍学习却被拒绝」。
#    安装器会把那 4 处闸门改成恒放行（武学 x2 / 天赋 / 心愿奖励重复领取），
#    并随「心愿/专属不占数量上限」这个开关一起装 / 卸。
#    ⚠ Steam「验证文件完整性」会把它还原成原版 —— 之后重新装一次本 MOD 即可。
#
#  ★ 存档备份（基础功能，不跟开关走，每次安装必做）
#    安装器在动任何游戏文件**之前**，先把玩家存档复制一份出去，落点两处：
#      ① <游戏目录>\存档备份\<日期_时间>\
#      ② <我的文档>\梦江湖存档备份\<日期_时间>\   （防玩家误删整个游戏目录）
#    只增不删：历次安装的备份一律保留，由玩家自己管理；卸载也不会碰它们。
#    不备份游戏本体 / 表数据 —— 那些 Steam「验证文件完整性」能整份恢复
#    （云存档对这类单机版不好用，所以存档才要自己留）。
#
#  ★ 功能开关
#    包根目录有一份「MOD功能开关.txt」，每一项 MOD 功能都能单独开关。
#    安装器会读它，然后：
#      · 开关为「开」的功能 -> 装进去（初次安装就是这样）
#      · 开关为「关」的功能 -> 初次安装时不装；
#                              已经装过则把对应改动**还原**（表从备份回滚）
#    同时它会把这个文件复制到游戏目录给 MOD 运行时读：
#      BepInEx\plugins\XiakeConsultFix\features.txt
#    （改开关的流程：改「MOD功能开关.txt」-> 保存 -> 重跑一次 1-安装.bat）
#
#  原版文件会被完整备份到游戏目录下的 _MOD备份_暗影MOD合集\，
#  随时可以用"卸载"脚本一键还原。（这是"回到原版"用的，可以删；
#  存档备份是另一套、在存档备份\ 和 我的文档\梦江湖存档备份\，那两份别删。）
#
#  用法（也可以直接双击同目录下的 1-安装.bat / 2-卸载.bat）：
#     powershell -ExecutionPolicy Bypass -File install.ps1
#     powershell -ExecutionPolicy Bypass -File install.ps1 -Uninstall
#     powershell -ExecutionPolicy Bypass -File install.ps1 "D:\别的路径\xiake"
#     powershell -ExecutionPolicy Bypass -File install.ps1 -SaveBakDocs "D:\测试用"
#       ↑ 只改「额外那一份存档备份」的落点，留空就是"我的文档"。一般用不到。
# =====================================================================
[CmdletBinding()]
param(
    [Parameter(Position = 0)][string]$GameDir = '',
    [switch]$Uninstall,
    [switch]$UseLastConfig,
    # 只认"包所在位置"和显式指定的路径，不做 Steam 库兜底搜索。
    # 给自动化测试用，也方便不想让脚本到处翻目录的人。
    [switch]$NoSearch,
    # 存档备份「额外那一份」的根目录。留空 = 我的文档（正常用法）。
    # 给自动化测试用 —— 免得测试往真实文档目录里写东西。
    [string]$SaveBakDocs = ''
)

Set-StrictMode -Version 2.0
# Import script functions globally before nested preflight calls (Windows PS 5.1).
Import-Module Microsoft.PowerShell.Utility -Global -ErrorAction Stop
$ErrorActionPreference = 'Stop'
# ★ 2026-09-30：本脚本是「玩家双击运行」的无人值守安装器，**永远不该弹交互确认**。
#   起因：拆 junction 原来用 `Remove-Item -Force`（PowerShell 5.1 下没带 -Recurse），
#   非空 reparse point 会弹出「该项具有子项…是否确实要继续?」——玩家一旦按 Y/A，
#   就顺着链接把 mod\暗影mod\角色换图 里的**真素材删光**（这正是素材离奇消失的一种路径）。
#   处置：① 这里全局关掉确认；② 4.5 / 2.2 两段拆链接改用 .NET 的 RemoveDirectory 语义
#   （只删链接本身、不递归、不碰目标）。全脚本的删除点已人工核对：其余 Remove-Item
#   全部作用于「文件」或「已判定为空」的目录，关掉确认不会造成静默误删。
$ConfirmPreference = 'None'

$INTERNAL = $PSScriptRoot
. (Join-Path $INTERNAL 'install_results.ps1')
$SCRIPT:CLASSIC_INSTALL=$false
$SCRIPT:CLASSIC_PLAN=$null
$ROOT = if ((Split-Path -Leaf $PSScriptRoot) -eq '安装资源') { Split-Path -Parent $PSScriptRoot } else { $PSScriptRoot }
$PAYLOAD = Join-Path $ROOT 'payload'
$PATCHER = Join-Path $INTERNAL 'patch_table.ps1'
$PATCHER_ADV = Join-Path $INTERNAL 'patch_behavior.ps1'
$PATCHER_YMZ = Join-Path $INTERNAL 'patch_taskreward.ps1'
$PATCHER_GP = Join-Path $INTERNAL 'patch_giftpool.ps1'
$PATCHER_SM = Join-Path $INTERNAL 'patch_item_static_max.ps1'
$BACKUP_NAME = '_MOD备份_暗影MOD合集'
# 早期版本用过下面这些名字，卸载时都要认，免得装过的人升级后卸不掉。
#   _MOD备份_梦江湖MOD合集   = v1.1（合集版）
#   _MOD备份_请教专属武学     = v1.0（单 MOD 版）
$BACKUP_NAME_OLD = @('_MOD备份_梦江湖MOD合集', '_MOD备份_请教专属武学')
$MANIFEST_NAME = 'manifest.json'
$MOD_NAME = '暗影MOD合集'
# 版本号：跟 _build/version.py 里的 VERSION 保持一致（打包时会校验）。
# 规则：每次出包 +0.01。
$MOD_VER = '0.47d'

# ------------------------------------------------------------------ 服务端闸门补丁
#
# 《梦江湖》单机版的"服务端"跑在本机进程里的原生 C++ 层：
#     DreamRivakes_Data\Plugins\RaceLogic_Release_x64.dll
# 它的武学 / 天赋数量上限判定**不认识本 MOD 的「心愿/专属不占数量上限」口径**，
# 只按原始条数拦 —— 于是出现"角色面板显示 x/y 是对的，用秘籍学习却被拒绝"。
# 下面 4 处把那几道闸门改成恒放行（其余逻辑一概不动），上限的最终裁定交回客户端。
#
# ★ 与「心愿/专属不占数量上限」是**同一个功能的两半**，所以共用开关
#   optimize.countrule：开关"关"时这里会把 DLL 还原成原版。
#
# ★ 本表与 patch_server.ps1 里的 $PATCHES 必须逐项一致（那份给玩家手动用）。
#   出包时 _build/build_zip.py 会核对，不一致直接拒绝出包。
$DLL_REL = 'DreamRivakes_Data\Plugins\RaceLogic_Release_x64.dll'
$BAK_DLL = 'RaceLogic_Release_x64.dll.orig'

# 文件内偏移, 原始字节(hex), 补丁字节(hex), 说明（VA 见 patch_server.ps1 头部注释）
$SRV_PATCHES = @(
    @{ Off = 0x723686; Orig = '7257'; New = 'EB57'; Note = '武学闸门1 @BeInstRole::AddMartial  jb→jmp' }
    @{ Off = 0x7236E7; Orig = '0F8294000000'; New = 'E99500000090'; Note = '武学闸门2 @BeInstRole::AddMartial  jb→jmp' }
    @{ Off = 0x729F7F; Orig = '7273'; New = 'EB73'; Note = '天赋闸门  @BeInstRole::CanAddGift  jb→jmp' }
    @{ Off = 0x479D07; Orig = '7507'; New = '9090'; Note = '心愿闸门  @CheckReplaceLearnedWishReward  jne→nop' }
)


$SRV_PATCHES_WISH = @(
    @{ Off = 0x479357; Orig = '837C2444000F8603010000'; New = 'E926E4AE00CCCCCCCCCCCC'; Note = '心愿补足：仅允许新增模板496..502、ready状态、模板请求' }
    @{ Off = 0xF67782; Orig = '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'; New = '837C2444000F87D51B51FF83BC24C800000002755A80BC24D00000000074508B8424C00000003DF001000072423DF6010000773B448BC0488B8424B0000000488B4008488B48588B94245000000041B101E8A8D162FF85C07415894424448BD0488B4C2448E8E47555FFE9711B51FFE96F1C51FF'; Legacy = @('837C2444000F87D51B51FF83BC24C800000002755A80BC24D00000000074508B8424C00000003DF001000072423DF0010000773B448BC0488B8424B0000000488B4008488B48588B94245000000041B101E8A8D162FF85C07415894424448BD0488B4C2448E8E47555FFE9711B51FFE96F1C51FF','837C2444000F87D51B51FF83BC24C800000002755A83BC24D00000000074508B8424C00000003DF001000072423DF6010000773B448BC0488B8424B0000000488B4008488B48588B94245000000041B101E8A8D162FF85C07415894424448BD0488B4C2448E8E47555FFE9711B51FFE96F1C51FF','837C2444000F87D51B51FF83BC24C800000002755A83BC24D00000000074508B8424C00000003DF001000072423DF0010000773B448BC0488B8424B0000000488B4008488B48588B94245000000041B101E8A8D162FF85C07415894424448BD0488B4C2448E8E47555FFE9711B51FFE96F1C51FF'); Note = '心愿补足116字节cave，复用原版创建与角色登记' }
)

$SRV_PATCHES_EX = @(
    @{ Off = 0x4E20E5; Orig = '0F8ED9000000'; New = 'E9DA00000090'; Note = '专属闸门  @BeMartialManager::AddMartial  jle→jmp  [放判定]' }
)

$SRV_PATCHES_CW = @(
    @{ Off = 0x533F23; Orig = '0F8440010000'; New = '909090909090'; Note = '迷宫跳过 H1 @0x180534a70  flag1==0 不再直接返回，继续走持刀判定（填 +0x2ec 缓存）' }
    @{ Off = 0x533F40; Orig = '0F8423010000'; New = '909090909090'; Note = '迷宫跳过 H0 @0x180534a70  非迷宫也不短路，继续走持刀判定（填 +0x2ec 缓存）' }
    @{ Off = 0x533F94; Orig = 'B001E9D3000000'; New = 'E9D00000009090'; Note = '迷宫跳过 H2 @0x180534a70  玩家持刀命中出口：跳返回 flag1 而非恒 1' }
    @{ Off = 0x53405C; Orig = 'B001EB0E'; New = 'EB0B9090'; Note = '迷宫跳过 H3 @0x180534a70  队友持刀命中出口：跳返回 flag1 而非恒 1' }
    @{ Off = 0x534065; Orig = '32C0EB05'; New = 'EB029090'; Note = '迷宫跳过 H4 @0x180534a70  持刀未命中出口：跳返回 flag1 而非恒 0' }

    @{ Off = 0x52CDE9; Orig = '0FB6098808'; New = '0FB6098808'; Legacy = @('E90BA9A300'); Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0xF676F9; Orig = '000000000000000000000000000000000000000000000000000000000000000000000000000000'; New = '0FB644243885C00F8581655CFFE992655CFF3D05500600740A2D12D206003D40030000C3909090'; Legacy = @('53488B5C24780FB60983BBEC02000000740C83C16484ED7405B9FF00000088085BE9CF565CFF90','53488B5C24780FB60983BBEC02000000740D83C16383F9FF7605B9FF00000088085BE9CE565CFF','53488B5C24780FB60983BBEC02000000740D83C16483F9FF7605B9FF00000088085BE9CE565CFF'); Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0x52DC7E; Orig = '0FB644243885C0'; New = 'E9769AA3009090'; Legacy = @('E990B231009090'); Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0x848F13; Orig = '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'; New = '488B54247083BAEC02000000740F83C0643DFF0000007E05B8FF00000089442420488B442470E9473ECEFF90'; Legacy = @('0FB644243885C00F85674DCEFFE9784DCEFF9090909090909090909090909090909090909090900000000000','E96F4DCEFF909090909090909090909090909090909090909090909090909090909090909090900000000000'); Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0x52CD7C; Orig = '89442420488B442470'; New = 'E992C1310090909090'; Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0x533F8D; Orig = '3D055006007507'; New = 'E87937A3007707'; Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
    @{ Off = 0x53403E; Orig = '3D05500600751B'; New = 'E8C836A300771B'; Note = 'CW v9: variant recognition and per-battle signed scoring; preserve victory-only recording' }
)

# ★ 共享基础项：.text 映射区（把末尾填充区纳入映射，供 cave 使用）
#
#   ★ 为什么单列一组（2026-10-02）：原本这条挂在「闯王刀强化」组里，只有它需要 cave。
#     新增的「角色动态品质」把 cave 写在 .text 更靠后的 0x180F68320 —— 同样依赖
#     这一条。若继续留在闯王刀组，玩家**单独关掉闯王刀**会让 VSZ 被还原，
#     那块内存不再被映射，动态品质的 cave 立刻变成不可执行页 ⇒ 启动必崩。
#     所以抽成独立组，由「闯王刀 或 动态品质」**任一需要就抬起**，两个都关才还原。
#
#   ★ 本表与 patch_server.ps1 里的 $PATCHES_VSZ 必须逐项一致。
$SRV_PATCHES_VSZ = @(
    @{ Off = 0x210; Orig = 'F972F600'; New = '0074F600'; Note = '.text VirtualSize 0xf672f9→0xf67400：把末尾填充区纳入映射，供闯王刀/动态品质的 cave 使用' }
)

# ★ 第三组：经验值平衡（对应开关 balance.exp）
#
#   ① 解除战斗经验的「等级压制」——
#      原版：等级差 =（我方等级 − 怪物等级）> 3 时，按 (等级差−3) 递减经验，
#      等级差够大时经验被算成负数再夹到 0 ⇒ 打低级怪完全白打。
#      这里把判定改成无条件跳过，等级差再大也照给。
#      0x539A82  file_off（= VA 0x18053A682，等级压制函数 0x18053A4D0 里的 jle→jmp，1 字节）
#   ② 与本 MOD 的「丹药吃开局奖励加成」是同一个功能的两半（那半边在 Lua 里），
#      所以共用开关 balance.exp。
#
#   ★ 本表与 patch_server.ps1 里的 $PATCHES_BAL 必须逐项一致。
$SRV_PATCHES_BAL = @(
    @{ Off = 0x539A82; Orig = '7E5F'; New = 'EB5F'; Note = '等级压制解除 @战斗经验结算 0x18053A4D0  jle→jmp [等级差再大也不扣经验]' }
)

# ★ 第四组：修复坏掉的作弊指令 CHET_ADDMARTIALEXP（对应开关 fix.chetmartialexp）
#
#   同一套 ID，CHET_ADDROLEMARTIAL（加武学）、CHET_ADDROLEEXP（加角色经验）都正常，
#   唯独这条**毫无反应且不报错**。
#   根因：handler `0x18060F450` 调 `0x180737470` 时把两个模式参数硬编码成 0
#   （判据0=武学ID 去比容器键、角色查找0=只认运行时实例ID），
#   而游戏自己的丹药走的是「判据=1 + 查找=1」。两条各改 1 字节 00→01 对齐丹药。
#   09-29 实测确认：修好后玩家在作弊面板手填这条指令能正常加武学经验。
#   ★ 归「修复mod」—— 指令坏了是原版的问题，跟平衡与否无关。
#   ★ 注意依赖：平衡mod 的「丹药补开局经验」就是靠这条指令落库的，
#     关掉本项 = 那条指令恢复原版的坏样子 = 丹药补量会一起失效（原版行为）。
#
#   ★ 本表与 patch_server.ps1 里的 $PATCHES_CHET 必须逐项一致。
$SRV_PATCHES_CHET = @(
    @{ Off = 0x60E934; Orig = 'C644242800'; New = 'C644242801'; Note = '修 CHET_ADDMARTIALEXP 判据 0→1 @0x18060F534 [武学ID 按静态配置ID匹配，与丹药一致]' }
    @{ Off = 0x60E939; Orig = 'C644242000'; New = 'C644242001'; Note = '修 CHET_ADDMARTIALEXP 角色查找 0→1 @0x18060F539 [支持玩家填的角色配置ID]' }
)

# ★ 第五组：无视装备穿戴限制（对应开关 optimize.equipnolimit）
#
#   全局跳过装备的穿戴限制：等级 / 门派 / 角色专属 / 精通属性，四路一起放。
#
#   ★ 必须打服务端的实测依据（2026-10-02）：
#     客户端那半边（Lua 钩子放行 ItemDataManager.CheckItemCondition）已完成并验证
#     —— 放行后 ★SendEquip 确实发出去了，但服务端**独立校验并静默驳回**：
#     无回包、无提示、穿不上。⇒ 只改客户端没用，服务端这道闸门必须一起放。
#     所以本组与客户端钩子是**同一个功能的两半**，共用开关 optimize.equipnolimit。
#
#   ★ 服务端判定函数：BeRoleManager::_ItemUseConditionCheck @0x180494FC0
#     依次查 时限(dueTime) / 等级(needLevel) / 门派(needClan) / 属性·精通(needAttrValue)。
#   ★ 装备链：BeInstRole::EquipItem 0x180723D00 → BeRoleManager::EquipItem 0x18047FEA0
#     → 0x1804945E0（普通装备）/ 0x180494000（物品类型 0xF 那一路）。
#   ★ 改法：两条路径里"调完条件检查后的 jne"各改 1 字节成 jmp ＝ 结果一律当通过；
#     条件检查函数照跑（只读 + 打日志），原址改、无绝对地址、不需要 cave。
#
#   ★ 本表与 patch_server.ps1 里的 $PATCHES_ENL 必须逐项一致。
$SRV_PATCHES_ENL = @(
    @{ Off = 0x493A96; Orig = '7507'; New = 'EB07'; Note = '穿戴限制闸门1 @0x180494696 装备主路径(0x1804945E0)  jne→jmp [条件检查失败也放行]' }
    @{ Off = 0x49350A; Orig = '7507'; New = 'EB07'; Note = '穿戴限制闸门2 @0x18049410A 类型0xF路径(0x180494000)  jne→jmp [同上]' }
)

# ★ 第六组：无视秘籍学习限制（对应开关 optimize.learnnolimit）
#
#   ★ 与第五组「无视装备穿戴限制」是**两个独立开关**（用户 2026-10-02 拍板）。
#
#   ★ 链路（服务端）：指令分发 → 0x180433030 → BeRoleManager::RoleLearnSecretBookMartial
#     0x180482460 → _ItemUseConditionCheck 0x180494FC0 → jne 判结果，失败即 return false。
#   ★ 客户端那半边（consult_hook.lua 的 HookLearnNoLimit）：CharacterUI「学习」按钮
#     → ItemDataManager:ItemUseCondition 的 **913 行秘籍分支** → 不满足就只弹
#     "不满足学习条件"，压根不发 SendRoleLearnSecretBookMartial。
#   ★ 为什么不能靠装备那个钩子：装备走 CheckItemCondition 四路，秘籍走**武学学习条件**
#     （MartialDataManager:CheckMartialLearnConditionByType），是两个不同分支。
#   ★ 与装备那半边同理：服务端**独立校验**，只改客户端会被静默驳回 ⇒ 两端都要放。
#
#   ★ 本表与 patch_server.ps1 里的 $PATCHES_LNL 必须逐项一致。
$SRV_PATCHES_LNL = @(
    @{ Off = 0x481B35; Orig = '7507'; New = 'EB07'; Note = '秘籍学习闸门 @0x180482735 RoleLearnSecretBookMartial  jne→jmp [条件检查失败也放行]' }
)

# ★ 第七组：角色动态品质（对应开关 optimize.dynrank）
#
#   需求（2026-10-02 用户定稿，方案 2）：角色品质随等级抬升 —— 按**游戏默认品质**为底，
#   等级超过默认品质对应的档位时，把品质提升到「等级档」；**只升不降**。
#     等级档 = min(7, 1 + floor(等级/5))   ⇒ 1-4白 / 5-9绿 / 10-14蓝 / 15-19紫 /
#                                            20-24橙 / 25-29金 / 30+暗金
#     原版五彩(8) / 三等暗金(9) 原样保留（它们在 7 之上，不会被压回去）。
#
#   ★ 注入点：RankGetter 0x35CF70（= VA 0x18035CF70）
#     反汇编实证：它是**唯一**读取角色品质字段 [obj+0x19C] 的 getter，有 **78 处**调用方。
#     （上层 BeRoleManager::GetRoleRankLevel 0x46FD90 只有 10 处调用 —— 但升级流程
#       BeInstRole::_AddLevel 是直接连低层 getter 的，只挂上层会出现"品质显示变了、
#       升级成长仍按旧品质算"。挂在 getter 上，显示 / 属性 / 成长 / 同步一次全覆盖。）
#     同一对象 +0x158 就是等级（0x4C0D00 读它，且与 _AddLevel 同上下文），两个偏移互证。
#
#   ★ 改法：入口 5 字节改 jmp，跳到 .text 末尾零区的 98 字节 cave。cave 只**读**内存、
#     只改返回值，不写任何对象字段、不动 rsp —— 最坏是某个值读偏，不会写坏存档。
#     护栏：原品质必须 1..9、等级必须 5..200，否则原样返回。
#   ★ 前置条件：cave 落在原版 .text VirtualSize 之外 ⇒ 必须 $SRV_PATCHES_VSZ 那条
#     （VSZ 抬到 0xf67400）已生效。安装器已把 VSZ 抽成共享基础项，任一 cave 功能开就抬。
#
#   ★ 本表与 patch_server.ps1 里的 $PATCHES_DYN 必须逐项一致。
$SRV_PATCHES_DYN = @(
    @{ Off = 0x35C370; Orig = '48894C2408'; New = 'E9ABB3C000'; Note = '动态品质入口跳板 @0x18035CF70 RankGetter 前5字节改 jmp cave(0x180F68320)  [跳转点]' }
    @{ Off = 0x35C375; Orig = '488B4424088B809C010000C3'; New = 'CCCCCCCCCCCCCCCCCCCCCCCC'; Note = '动态品质入口跳板残余 12字节原指令(mov rax,[rsp+8]; mov eax,[rax+0x19C]; ret)填入 int3 —— cave 已复刻同样的取值逻辑并自带 ret' }
    @{ Off = 0xF67720; Orig = '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'; New = '48894C24088B819C01000083F801725183F809774C8B915801000083FA05724181FAC8000000773941B80100000041FFC083FA0A722341FFC083FA0F721B41FFC083FA14721341FFC083FA19720B41FFC083FA1E720341FFC04139C076034489C0C3'; Note = '动态品质 cave (98B) 位于 .text 末尾零区 0x180F68320：品质 = max(原品质, min(7, 1+floor(等级/5)))；护栏 等级5..200、原品质1..9，越界原样返回 [cave 代码]' }
)



# ------------------------------------------------------------------ 功能开关
#
# ★ 设计要点（为什么长这样）：
#   · 玩家那份开关文件里**只有傻瓜格式**：分组名 + 「功能名:1」，1=开 0=关。
#     中文名对玩家最直观，不用记英文键。
#   · 中文名 **不直接喂给 Lua** —— consult_hook.lua 是 UTF-8 源码，而开关文件
#     按 GBK 落盘，Lua 里的中文字面量和文件字节对不上，键永远匹配不上。
#     所以由**安装器**把中文名翻译成 ASCII 键，写进运行时副本 features.txt，
#     Lua 只认 ASCII 键（见 consult_hook.lua 的 FeatOn）。
#   · 文件缺失 / 打开失败 / 某个功能没写 -> **一律当"开"**。
#     向后兼容早期的包（那时候还没有这个文件），也避免改坏一个字符就把功能全关掉。
#   · 能认两种写法：新的「功能名:1」和 v0.25 的「optimize.exclusive = 1」。
#     认不出的名字会被**原样打印出来**提示，不会静默按"没写"处理。
#   · 开关控制两层，两层必须一致才算"真关掉"：
#       ① 安装器层：关掉的功能不装；装过的从备份还原
#       ② 运行时层：把该功能的钩子整体短路（见 consult_hook.lua 的 FeatOn）
$SWITCH_NAME = 'MOD功能开关.txt'
# 运行时副本：MOD 的 Lua 脚本按这个**相对游戏目录**的路径去读它。
# ★ 必须是纯 ASCII 文件名 —— Lua 的 io.open 走 C 运行时, 中文路径在
#   GBK 系统上会按 ANSI 解码, 与 UTF-8 源码里的字符串对不上。
$SWITCH_REL = 'BepInEx\plugins\XiakeConsultFix\features.txt'
# 功能清单（中文功能名 -> 运行时 ASCII 键）。顺序就是文件里的顺序、也是打印顺序。
#   ★ 2026-10-02：顺序**照「暗影mod说明.txt」最上面那份 mod功能清单**排
#     （优化mod → 平衡mod → 修复mod）。改顺序必须同步 _build/gen_switch.py 的 GROUPS，
#     否则 e2e 的「运行时文件逐字节一致」会挂。
#
# ★ 为什么要做这层翻译：玩家那份开关文件是中文名 + GBK 落盘，而 consult_hook.lua
#   是 UTF-8 源码 —— Lua 里的中文字面量和文件里的字节对不上，直接读会永远匹配不上。
#   所以由安装器把「中文名:1」翻译成「optimize.exclusive=1」写进运行时副本，
#   Lua 只认 ASCII 键，两边都稳（玩家把开关文件另存成 UTF-8 也不影响）。
$FEAT_DEF = [ordered]@{
    '专属武学/专属天赋解禁' = 'optimize.exclusive'
    '指点队友武学' = 'optimize.teach'
    '装备随机词条' = 'optimize.randomequip'
    '角色换皮' = 'optimize.roleskin'
    '新增角色' = 'optimize.customroles'
    '心愿/专属不占数量上限' = 'optimize.countrule'
    '心愿补足与首次武学' = 'optimize.wishfill'
    '天赋随机池扩充' = 'optimize.clantalents'
    '心愿天赋随机池扩充' = 'optimize.wishtalents'
    '精通天赋强化' = 'optimize.giftmastery'
    '新增装备词条' = 'balance.nolimitgift'
    '请教/指点对非队友使用' = 'optimize.anynpc'
    '轮盘加速' = 'optimize.rollskip'
    '道具图标优化' = 'optimize.bookicon'
    '闯王军刀强化' = 'optimize.chuangwang'
    '其他界面优化' = 'optimize.favoralways'
    '新建角色词条优化' = 'optimize.giftpool'
    '装备白字属性完美' = 'optimize.staticmax'
    '角色动态品质' = 'optimize.dynrank'
    '残章掉落优化' = 'optimize.fragment'
    '不可收藏武学等级上限' = 'optimize.uncollectiblecap'
    '杂货商藏宝图补货' = 'optimize.shopmaps'
    '重铸优化' = 'optimize.recast'
    '双神器' = 'optimize.dualartifact'
    '迷宫移除战争迷雾' = 'optimize.mazenofog'
    '唯一奖励解锁' = 'optimize.uniquerewards'
    '迷宫自动拾取' = 'optimize.mazeautoloot'
    '迷宫扫荡' = 'optimize.mazesweep'
    '奥义优化' = 'optimize.aoyi'
    '结义/誓约优化' = 'optimize.relationship'
    '快速过月' = 'debug.fastmonth'
    '藏宝图掉落调整' = 'balance.treasurewood'
    '藏宝图调整2' = 'balance.treasurequality'
    '重铸优化2' = 'balance.recasttypes'
    '周目仓库带入点数上限' = 'balance.storagein'
    '请教减好感/指点加好感' = 'balance.favor'
    '学习秘籍消耗秘籍' = 'balance.bookconsume'
    '经验值平衡' = 'balance.exp'
    '副本带出1：强化门槛改为+20' = 'balance.outenhance'
    '副本带出2：仅保留指定传家宝' = 'balance.outheirloom'
    '副本带出3：所有稀有度武学' = 'balance.outmartial'
    '副本带出4：所有稀有度天书' = 'balance.outheaven'
    '副本带出5：所有稀有度材料' = 'balance.outmaterial'
    '副本带出6：金色装备取消品质带出' = 'balance.outgold'
    '副本带出7：暗金裂纹限制' = 'balance.outcrack'
    '铸剑无限连优化' = 'balance.taichain'
    '无视装备穿戴限制' = 'optimize.equipnolimit'
    '无视秘籍学习限制' = 'optimize.learnnolimit'
    '结义/誓约修复' = 'fix.relationship'
    '冒险手札漏发修复' = 'fix.adventure'
    '采集天赋修复' = 'fix.harvest'
    '玉鸣子的考验分支奖励' = 'fix.yumingzi'
    '武学经验指令修复' = 'fix.chetmartialexp'
    '缺失图标修复' = 'fix.itemicon'
    '武学添加/修改修复' = 'fix.martialjson'
    '铸剑无限连崩溃修复' = 'fix.taichain'
    '生灵涂炭修复' = 'fix.shenglingtutan'
    '调出官方作弊面板' = 'debug.cheatpanel'
}
# ★ 缺开关文件时也不能放开的键（与 gen_switch.py 的 DEFAULT_OFF 保持一致）。
#   否则"玩家直接把开关文件删了"会把调试功能顶成开。
$FEAT_DEFAULT_OFF = @('fix.shenglingtutan', 'balance.recasttypes', 'debug.cheatpanel', 'debug.fastmonth', 'optimize.equipnolimit', 'balance.outheaven', 'balance.outcrack')
# 反查表（ASCII 键 -> 中文名），打印清单与写运行时文件时用
$FEAT_NAME = @{}
foreach ($nk in $FEAT_DEF.Keys) { $FEAT_NAME[$FEAT_DEF[$nk]] = $nk }

# 读开关文件 -> 哈希表（**ASCII 键** -> $true/$false），并附带元信息键。
#   能认两种写法：① 新格式「功能名:1」 ② 老格式「optimize.exclusive = 1」
function Read-Switches([string]$path) {
    $sw = @{}
    foreach ($k in $FEAT_DEF.Values) { $sw[$k] = ($FEAT_DEFAULT_OFF -notcontains $k) }   # 默认：全开（调试项除外）
    $sw['balance.outcrackcount'] = 2
    $sw['optimize.mazeautolootinterval'] = 0.5
    $sw['__found'] = $false
    $sw['__seen'] = @{}
    $sw['__bad'] = @()      # 看懂了格式但认不出名字的行（多半是打错字）
    if (-not (Test-Path -LiteralPath $path)) { return $sw }
    $sw['__found'] = $true
    try {
        # 用 GBK 读（包内 .txt 按 GBK 落盘）。就算玩家另存成 UTF-8，
        # 中文名两种编码下字节不同 —— 所以这里读错会表现为"认不出该行"，
        # 下面会把这种行原样报出来，不会静默变成"没写=按开"。
        $txt = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::GetEncoding(936))
    }
    catch {
        $sw['__found'] = $false
        return $sw
    }
    foreach ($ln in ($txt -split "`r?`n")) {
        $interval = [regex]::Match($ln, '^\s*(迷宫自动拾取间隔|optimize\.mazeautolootinterval)\s*[:：=]\s*(.*?)\s*$')
        if ($interval.Success) {
            [double]$seconds=0
            if(-not [double]::TryParse($interval.Groups[2].Value,[Globalization.NumberStyles]::AllowDecimalPoint,[Globalization.CultureInfo]::InvariantCulture,[ref]$seconds) -or $seconds -le 0 -or [double]::IsInfinity($seconds)) {throw '迷宫自动拾取间隔必须是大于0的秒数，例如0.5'}
            $sw['optimize.mazeautolootinterval']=$seconds
            continue
        }
        $num = [regex]::Match($ln, '^\s*(副本带出7裂纹数配置|balance\.outcrackcount)\s*[:：=]\s*(\d+)\s*$')
        if ($num.Success) {
            $value=[int]$num.Groups[2].Value
            if ($value -gt 7) { throw '副本带出7裂纹数配置只能填 0..7' }
            $sw['balance.outcrackcount']=$value
            continue
        }

        $m = [regex]::Match($ln, '^\s*(.+?)\s*[:：=]\s*([01])\s*$')
        if (-not $m.Success) { continue }      # 没冒号/没值 = 分组标题或说明，跳过
        $name = $m.Groups[1].Value.Trim()
        $v = ($m.Groups[2].Value -eq '1')
        $key = $null
        if ($FEAT_DEF.Contains($name)) { $key = $FEAT_DEF[$name] }      # 新格式：中文名
        elseif ($FEAT_NAME.ContainsKey($name)) { $key = $name }          # 老格式：直接写 ASCII 键
        if ($key) {
            $sw[$key] = $v
            $sw['__seen'][$key] = $true
        }
        else {
            $sw['__bad'] += ($name + ' = ' + $m.Groups[2].Value)
        }
    }
    return $sw
}

# 把当前开关写成 MOD 运行时读的那份（纯 ASCII k=v）。
function Write-RuntimeSwitches([string]$dst, $sw) {
    $lines = @()
    foreach ($nk in $FEAT_DEF.Keys) {
        $key = $FEAT_DEF[$nk]
        if ($sw[$key]) { $lines += ($key + '=1') } else { $lines += ($key + '=0') }
    }
    $lines += ('balance.outcrackcount=' + $sw['balance.outcrackcount'])
    $lines += ('optimize.mazeautolootinterval=' + ([double]$sw['optimize.mazeautolootinterval']).ToString([Globalization.CultureInfo]::InvariantCulture))
    $text = ($lines -join "`r`n") + "`r`n"
    $enc = New-Object System.Text.ASCIIEncoding
    [System.IO.File]::WriteAllText($dst, $text, $enc)
}

. (Join-Path $PSScriptRoot 'saved_switches.ps1')


# 用备份把某张表还原成原版；内容已经一致就跳过（幂等，不白写盘）。
# 返回 'done'（写了）/ 'same'（本来就一样）/ 'nobak'（没有备份）。
function Restore-Table([string]$bakFile, [string]$dst, [string]$label) {
    if (-not (Test-Path -LiteralPath $bakFile)) { return 'nobak' }
    if (-not (Test-Path -LiteralPath $dst)) { return 'nobak' }
    $h1 = (Get-FileHash -LiteralPath $bakFile -Algorithm MD5).Hash
    $h2 = (Get-FileHash -LiteralPath $dst     -Algorithm MD5).Hash
    if ($h1 -eq $h2) { return 'same' }
    Copy-Item -LiteralPath $bakFile -Destination $dst -Force
    return 'done'
}


# ---------------------------------------------------------------- 服务端闸门补丁
# 用法说明见文件头的「服务端闸门补丁」一节。这里只做三件事：
#   读状态 → （必要时）备份 + 改 4 处字节 → 回读校验。任何"字节对不上"都当场停手。

function ConvertFrom-HexString([string]$hex) {
    $h = $hex -replace '\s', ''
    $out = New-Object byte[] ($h.Length / 2)
    for ($i = 0; $i -lt $out.Length; $i++) {
        $out[$i] = [Convert]::ToByte($h.Substring($i * 2, 2), 16)
    }
    return , $out
}

# 从 $buf 的 $off 起取 $n 字节，返回大写 hex 字符串（越界给空串）
function Get-HexStringAt([byte[]]$buf, [int]$off, [int]$n) {
    if ($off -lt 0 -or ($off + $n) -gt $buf.Length) { return '' }
    $sb = New-Object System.Text.StringBuilder
    for ($i = 0; $i -lt $n; $i++) { [void]$sb.Append($buf[$off + $i].ToString('X2')) }
    return $sb.ToString()
}

# 逐处判定当前 DLL 的状态。
#   'absent'  游戏目录里没有这个 DLL（测试用假目录 / 精简版）
#   'orig'    这组中每一处都是原版字节 —— 干净的、可以打
#   'patched' 这组中每一处都是补丁字节 —— 已经打过了
#   'partial' 一部分原版、一部分已打（比如从只打 3 处的旧版升上来）
#   'unknown' 有字节对不上（游戏版本不同，或被别的工具改过）—— 一律不动
#
# ★ $Patches 由调用方传入（$SRV_PATCHES 或 $SRV_PATCHES_CW）。
#   服务端补丁按功能分成两组、各受自己开关控制，所以不能写死引用某一张表。
function Get-ServerGateState([string]$dll, [array]$Patches) {
    if (-not (Test-Path -LiteralPath $dll)) { return @{ State = 'absent'; Items = @() } }
    $buf = [System.IO.File]::ReadAllBytes($dll)
    $items = @()
    $nOrig = 0; $nPatched = 0; $nUnknown = 0
    foreach ($p in $Patches) {
        $cur = Get-HexStringAt $buf $p.Off ($p.Orig.Length / 2)
        if ($cur -eq $p.Orig) { $s = 'orig'; $nOrig = $nOrig + 1 }
        elseif ($cur -eq $p.New) { $s = 'patched'; $nPatched = $nPatched + 1 }
        elseif ($p.ContainsKey('Legacy') -and (@($p.Legacy) -contains $cur)) { $s = 'legacy'; $nOrig = $nOrig + 1 }
        else { $s = 'unknown'; $nUnknown = $nUnknown + 1 }
        $items += [pscustomobject]@{ Off = $p.Off; St = $s; Cur = $cur; P = $p }
    }
    $st = 'partial'
    if ($nUnknown -gt 0) { $st = 'unknown' }
    elseif ($nPatched -eq $Patches.Count) { $st = 'patched' }
    elseif ($nOrig -eq $Patches.Count) { $st = 'orig' }
    return @{ State = $st; Items = $items }
}

# 打补丁。返回：done:<改了几处> / already / absent / unknown / error / nobak
#   ★ 只动"还是原版"的那几处；已经打过的原样留着 —— 这样从旧版（少一处）升上来
#     也能自动补齐，而不是非得先还原再重打。
function Invoke-ServerPatch([string]$Dir, [string]$BakDir, [array]$Patches) {
    $dll = Join-Path $Dir $DLL_REL
    $st = Get-ServerGateState $dll $Patches
    if ($st.State -eq 'absent') { return 'absent' }
    if ($st.State -eq 'unknown') { return 'unknown' }
    if ($st.State -eq 'patched') { return 'already' }

    # 备份原版（保留最早那份 —— 跟数据表的规矩一致）
    if (-not (Test-Path -LiteralPath $BakDir)) {
        New-Item -ItemType Directory -Force -Path $BakDir | Out-Null
    }
    $bakDll = Join-Path $BakDir $BAK_DLL
    if (-not (Test-Path -LiteralPath $bakDll)) {
        Copy-Item -LiteralPath $dll -Destination $bakDll -Force
    }

    foreach ($item in $st.Items) { if ($item.St -eq 'legacy') { Say ('      + 识别到旧版本补丁，将升级：0x' + $item.Off.ToString('X')) } }
    $buf = [System.IO.File]::ReadAllBytes($dll)
    $n = 0
    foreach ($p in $Patches) {
        $cur = Get-HexStringAt $buf $p.Off ($p.Orig.Length / 2)
        if ($cur -eq $p.New) { continue }            # 已经是补丁状态，跳过
        $new = ConvertFrom-HexString $p.New
        [Array]::Copy($new, 0, $buf, [int]$p.Off, $new.Length)
        $n = $n + 1
    }
    if ($n -eq 0) { return 'already' }
    [System.IO.File]::WriteAllBytes($dll, $buf)

    # 回读校验：写进去的每一处都必须真的是补丁字节
    $chk = [System.IO.File]::ReadAllBytes($dll)
    foreach ($p in $Patches) {
        if ((Get-HexStringAt $chk $p.Off ($p.New.Length / 2)) -ne $p.New) { return 'error' }
    }
    return ('done:' + $n)
}

# 还原成原版。
#   ★ 改成分组**逐处写回**，不再"拿备份整体覆盖 DLL"：
#     服务端补丁现在按功能分成两组（数量上限/心愿 与 闯王刀），各受自己的开关控制。
#     若继续整体覆盖，关掉其中一组会把另一组已装的补丁一起抹掉。
#   ★ 顺带不再依赖备份：备份丢了也能正常关闭功能（写回的是表里登记的原始字节）。
#   返回：done:<还原了几处> / same / unknown / nodll / error
function Restore-ServerPatch([string]$Dir, [array]$Patches) {
    $dll = Join-Path $Dir $DLL_REL
    if (-not (Test-Path -LiteralPath $dll)) { return 'nodll' }
    $st = Get-ServerGateState $dll $Patches
    if ($st.State -eq 'unknown') { return 'unknown' }
    if ($st.State -eq 'orig') { return 'same' }

    $buf = [System.IO.File]::ReadAllBytes($dll)
    $n = 0
    foreach ($p in $Patches) {
        $cur = Get-HexStringAt $buf $p.Off ($p.New.Length / 2)
        if ($cur -ne $p.New -and -not ($p.ContainsKey('Legacy') -and (@($p.Legacy) -contains $cur))) { continue }          # 本来就是原版字节，跳过
        $orig = ConvertFrom-HexString $p.Orig
        [Array]::Copy($orig, 0, $buf, [int]$p.Off, $orig.Length)
        $n = $n + 1
    }
    if ($n -eq 0) { return 'same' }
    [System.IO.File]::WriteAllBytes($dll, $buf)

    # 回读校验：每一处都必须真的回到了原始字节
    $chk = [System.IO.File]::ReadAllBytes($dll)
    foreach ($p in $Patches) {
        if ((Get-HexStringAt $chk $p.Off ($p.Orig.Length / 2)) -ne $p.Orig) { return 'error' }
    }
    return ('done:' + $n)
}

# 按开关装/卸**一组**服务端补丁，并打印这一组的结果。返回状态串给汇总用。
#   两组（数量上限/心愿、闯王刀）走的是同一套逻辑，只是补丁表和开关不同，
#   所以抽出来 —— 免得两组各写一遍、改一处忘另一处。
function Apply-ServerGroup([string]$Label, [string]$Dir, [string]$BakDir,
                           [array]$Patches, [bool]$On) {
    Say ('    · ' + $Label)
    if($SCRIPT:CLASSIC_INSTALL) {
        if($null -eq $SCRIPT:CLASSIC_PLAN) {throw 'Classic native preflight missing'}
        Say '      = 已纳入新版原生补丁预检与统一写入'
        if($On) {return 'already'} else {return 'off'}
    }
    if (-not $On) {
        $r = Restore-ServerPatch $Dir $Patches
        if ($r -like 'done:*') {
            Say ('      - 开关「关」—— 已把 {0} 处改回原版' -f ([string]$r).Split(':')[1])
            return 'off'
        }
        elseif ($r -eq 'same') { Say '      = 开关「关」—— 本来就是原版，无需还原'; return 'off' }
        elseif ($r -eq 'nodll') { Say '      ! 游戏目录里没有服务端 DLL，无需处理'; return 'no-dll' }
        elseif ($r -eq 'unknown') {
            Say '      ! 当前字节与本补丁预期不符，未改动'
            return 'unknown'
        }
        else { Say '      ! 还原失败'; return 'error' }
    }

    $r = Invoke-ServerPatch $Dir $BakDir $Patches
    if ($r -eq 'already') { Say '      = 之前已经打过，无需修改'; return 'already' }
    elseif ($r -like 'done:*') {
        Say ('      + 已写入 {0} 处' -f ([string]$r).Split(':')[1])
        return 'patched'
    }
    elseif ($r -eq 'absent') {
        Say '      ! 游戏目录里没有服务端 DLL，已跳过'
        Say ('        找的是：' + $DLL_REL)
        return 'no-dll'
    }
    elseif ($r -eq 'unknown') {
        Say '      ! 字节与本补丁预期不符，已跳过（不猜、不盲改）'
        Say '        常见原因：游戏版本不同，或 Steam 还原过 / 别的工具改过它。'
        $detail = Get-ServerGateState (Join-Path $Dir $DLL_REL) $Patches
        foreach ($item in $detail.Items) { if ($item.St -eq 'unknown') { Say ('        未识别位置 0x' + $item.Off.ToString('X') + ' 当前字节：' + $item.Cur) } }
        return 'unknown'
    }
    else {
        Say '      ! 写入后校验没通过，已跳过（其它功能不受影响）'
        Say '        需要时可手动还原：patch_server.ps1 -Restore'
        return 'error'
    }
}

# ------------------------------------------------------------------ 输出
#
# ★ 全过程同时落一份日志到包目录下的「安装日志.txt」。
#   双击 bat 时窗口关掉就什么都没了，用户遇到问题只能凭记忆描述；
#   有日志文件用户直接发过来就能定位。（脚本成功时日志也留着，无害。）
$SCRIPT:LOG_PATH = Join-Path $ROOT '安装日志.txt'
$SCRIPT:LOG = New-Object System.Collections.Generic.List[string]
# 服务端闸门补丁的最终状态（安装函数里赋值，"安装完成"汇总要用）
$SCRIPT:SRVSTATE = ''

function Write-Log {
    try {
        [System.IO.File]::WriteAllLines($SCRIPT:LOG_PATH, $SCRIPT:LOG.ToArray(),
            (New-Object System.Text.UTF8Encoding($true)))
    }
    catch { }
}

function Say([string]$m) {
    $SCRIPT:LOG.Add([string]$m)
    Write-Host $m
    Write-Log
}

function Fail([string]$m) {
    Say ''
    # ★ 这里必须是 Say ('...' + $m) —— 不能写成 Say '...' + $m。
    #   PowerShell 会把后一种解析成「Say 只收到前半句，+$m 被当成另一个参数丢掉」，
    #   于是所有错误原因全部被吃掉，只剩一个空的 [错误]。
    #   v1.2 就是这个样子，害得用户装了失败却看不到任何原因。
    Say ('[错误] ' + $m)
    Say ''
    Say ('本次没有成功。详细过程已保存到：' + $SCRIPT:LOG_PATH)
    exit 1
}

# ------------------------------------------------------------------ 定位游戏
function Get-SteamRoots {
    $roots = New-Object System.Collections.Generic.List[string]
    $keys = @('HKCU:\Software\Valve\Steam',
              'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam',
              'HKLM:\SOFTWARE\Valve\Steam')
    foreach ($k in $keys) {
        try {
            $v = Get-ItemProperty -Path $k -ErrorAction Stop
            foreach ($name in @('SteamPath', 'InstallPath')) {
                $property = $v.PSObject.Properties[$name]
                if ($property -and $property.Value) { $roots.Add([string]$property.Value) }
            }
        }
        catch { }
    }
    # Registry access may be unavailable; cover both Steam default locations,
    # including their additional libraries recorded in libraryfolders.vdf.
    foreach ($base in @($env:ProgramW6432, $env:ProgramFiles, ${env:ProgramFiles(x86)},
                        'C:\Program Files', 'C:\Program Files (x86)')) {
        if ($base) { $roots.Add((Join-Path $base 'Steam')) }
    }
    $all = New-Object System.Collections.Generic.List[string]
    $seen = @{}
    foreach ($r in $roots) {
        if ($seen[$r]) { continue }
        $seen[$r] = $true
        $all.Add($r)
        $vdf = Join-Path $r 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($ln in @(Get-Content -LiteralPath $vdf -Encoding UTF8 -ErrorAction SilentlyContinue)) {
                $m = [regex]::Match($ln, '"path"\s+"([^"]+)"')
                if ($m.Success) {
                    $all.Add(($m.Groups[1].Value -replace '\\\\', '\'))
                }
            }
        }
    }
    return $all
}

function Test-GameDir([string]$d) {
    if (-not $d) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $d 'DreamRivakes.exe'))) { return $false }
    return (Test-Path -LiteralPath (Join-Path $d 'TableData\Martial.bytes'))
}

function Test-GameRunning {
    # 游戏进程还在的时候不要动手改表：TableData 下的表可能被占用，写入会失败。
    # 而写入是在安装流程中途 —— 一旦失败，插件可能已经装好了，就会留下
    # 「天赋能学、武学学不了」这种半成品状态，用户根本看不出是安装没做完。
    # 所以宁可直接拦住，让用户先退出游戏。
    $ps = @(Get-Process -ErrorAction SilentlyContinue |
            Where-Object { $_.ProcessName -like 'DreamRivakes*' })
    return ($ps.Count -gt 0)
}

function Find-GameDir {
    $cands = New-Object System.Collections.Generic.List[string]
    foreach ($r in (Get-SteamRoots)) {
        $cands.Add((Join-Path $r 'steamapps\common\xiake'))
    }
    foreach ($drv in @('C', 'D', 'E', 'F', 'G')) {
        foreach ($sub in @('steam\steamapps\common\xiake',
                           'Steam\steamapps\common\xiake',
                           'SteamLibrary\steamapps\common\xiake',
                           'Program Files\Steam\steamapps\common\xiake',
                           'Program Files (x86)\Steam\steamapps\common\xiake')) {
            $cands.Add(($drv + ':\' + $sub))
        }
    }
    $seen = @{}
    foreach ($c in $cands) {
        if (-not $c -or $seen[$c]) { continue }
        $seen[$c] = $true
        if (Test-GameDir $c) { return $c }
    }
    return ''
}

# ------------------------------------------------- 从包的位置向上找游戏目录
#  正常：  xiake\梦江湖_暗影MOD合集_v1.2\install.ps1           -> 上面一层就是游戏目录
#  铺平：  xiake\install.ps1（有人把包里的东西全选铺进游戏目录）-> 自己就是游戏目录
#  嵌套：  xiake\梦江湖_暗影MOD合集_v1.2\梦江湖_暗影MOD合集_v1.2\install.ps1
#          （把解压出来的文件夹又解压/复制了一次）-> 要往上两层才是游戏目录
#  返回 @{ Dir = 游戏目录（没找到为空串）; Depth = 往上数了几层 }
#  层数不影响"能不能装"，只用来给针对性提示：嵌套了也能装，但要告诉玩家正确姿势。
function Find-GameDirUp([string]$start, [int]$maxDepth = 3) {
    $d = $start
    for ($i = 0; $i -le $maxDepth; $i++) {
        if (Test-GameDir $d) { return @{ Dir = $d; Depth = $i } }
        $p = Split-Path -Parent $d
        if (-not $p -or $p -eq $d) { break }
        $d = $p
    }
    return @{ Dir = ''; Depth = -1 }
}

# ------------------------------------------------------------------ 存档备份
#
# ★ 基础功能（不跟「MOD功能开关.txt」走，永远执行）：每次安装都**先把玩家存档
#   复制一份出去**，再动游戏目录里的任何文件。
#   装 MOD 有风险，但存档没了比 MOD 没装上严重一个量级 —— 所以这一步排在所有
#   写操作之前，并且**只增不删**：历次安装留下的备份一律保留，由玩家自己管理。
#
#   本作的存档就在游戏主目录里（不在 AppData / 不在 Steam userdata）：
#     Save.sav                                      当前进度（继续游戏读它）
#     Save.sav.check / Save.sav.checksave           它的校验件，缺了会判定存档损坏
#     SaveAI.sav                                    AI / 世界状态
#     SaveFile\<存档名>\                            手动存档槽
#                                                   Save.sav + SaveAI.sav + Image.png
#
#   不备份的东西（有意为之）：
#     · BeiFenData\  —— 游戏**自己**的时间戳快照目录，本来就在游戏目录里，
#                       备份它只是把我们的备份翻倍，没有额外保险。
#     · 游戏本体 / TableData  —— Steam「验证文件完整性」能整份恢复。
#                       （云存档对这类单机版不好用，所以存档才必须我们自己留。）
#
#   落点两处，同一时刻、同一内容：
#     ① <游戏目录>\存档备份\<日期_时间>\
#     ② <我的文档>\梦江湖存档备份\<日期_时间>\   ← 防玩家误删整个游戏目录
$SAVE_BAK_NAME = '存档备份'
$SAVE_BAK_DOCS = '梦江湖存档备份'
# 要备份的条目（相对游戏目录）。是目录的会整棵拷走。
$SAVE_ITEMS = @('Save.sav', 'Save.sav.check', 'Save.sav.checksave', 'SaveAI.sav', 'SaveFile')

# 把 $SAVE_ITEMS 里的东西整份拷进 $Dest，返回拷成功的文件数
function Copy-SaveSet([string]$Dir, [string]$Dest) {
    $n = 0
    New-Item -ItemType Directory -Force -Path $Dest | Out-Null
    foreach ($it in $SAVE_ITEMS) {
        $src = Join-Path $Dir $it
        if (-not (Test-Path -LiteralPath $src)) { continue }
        $to = Join-Path $Dest $it
        if (Test-Path -LiteralPath $src -PathType Container) {
            Copy-Item -LiteralPath $src -Destination $to -Recurse -Force
            $n += @(Get-ChildItem -LiteralPath $src -Recurse -File -Force).Count
        }
        else {
            Copy-Item -LiteralPath $src -Destination $to -Force
            $n += 1
        }
    }
    # First-choice persistence belongs to the same campaign as Save.sav.
    $wishStateDir = Join-Path $Dir 'BepInEx\plugins\XiakeConsultFix'
    if (Test-Path -LiteralPath $wishStateDir) {
        $wishStateBackup = Join-Path $Dest 'BepInEx\plugins\XiakeConsultFix'
        foreach ($stateFile in @(Get-ChildItem -LiteralPath $wishStateDir -File -Filter 'wish_first_*.json*')) {
            New-Item -ItemType Directory -Path $wishStateBackup -Force | Out-Null
            Copy-Item -LiteralPath $stateFile.FullName -Destination (Join-Path $wishStateBackup $stateFile.Name) -Force
            $n += 1
        }
    }
    return $n
}

# 备份存档，返回落点路径数组（可能为空 = 本来就没存档 / 备份失败）
function Backup-SaveData([string]$Dir, [string]$DocsRoot) {
    $found = @()
    foreach ($it in $SAVE_ITEMS) {
        if (Test-Path -LiteralPath (Join-Path $Dir $it)) { $found += $it }
    }
    if ($found.Count -eq 0) {
        Say '      游戏目录里没有存档，跳过'
        Say '      ※ 全新安装、还没进过游戏时会这样，属正常'
        return @()
    }

    # 文件夹名 = 安装时刻。★ 同一秒里连装两次会撞名，撞了就加 _2 / _3…
    #   （撞名时不加后缀的话，第二次会嵌进第一次的文件夹里，看着像丢了一份）
    $stamp = Get-Date -Format 'yyyy-MM-dd_HHmmss'
    $base = Join-Path $Dir $SAVE_BAK_NAME
    $dest1 = Join-Path $base $stamp
    $k = 1
    while (Test-Path -LiteralPath $dest1) {
        $k += 1
        $dest1 = Join-Path $base ($stamp + '_' + $k)
    }
    $leaf = Split-Path -Leaf $dest1

    # ② 的根目录：默认「我的文档」，取不到就退回 %USERPROFILE%\Documents
    if (-not $DocsRoot) {
        $DocsRoot = ''
        try { $DocsRoot = [Environment]::GetFolderPath('MyDocuments') } catch { $DocsRoot = '' }
        if (-not $DocsRoot) { $DocsRoot = Join-Path $env:USERPROFILE 'Documents' }
    }
    $dest2 = $null
    if (Test-Path -LiteralPath $DocsRoot -PathType Container) {
        $dest2 = Join-Path (Join-Path $DocsRoot $SAVE_BAK_DOCS) $leaf
    }
    else {
        Say ('      ! 找不到「我的文档」目录，只做游戏目录里的那一份（' + $DocsRoot + '）')
    }

    $dests = @()
    try {
        $n1 = Copy-SaveSet $Dir $dest1
        $dests += $dest1
        Say ('      + ' + $n1 + ' 个文件 -> ' + $SAVE_BAK_NAME + '\' + $leaf)
    }
    catch {
        Say ('      ! 存档备份失败：' + $_.Exception.Message)
        Say '        安装继续，但请自己先把游戏目录里的存档拷到别处再玩。'
        return @()
    }
    if ($dest2) {
        try {
            $n2 = Copy-SaveSet $Dir $dest2
            $dests += $dest2
            Say ('      + ' + $n2 + ' 个文件 -> ' + $DocsRoot + '\' + $SAVE_BAK_DOCS + '\' + $leaf)
        }
        catch {
            Say ('      ! 复制到「我的文档」失败（游戏目录里那份已经好了）：' + $_.Exception.Message)
        }
    }
    Say ('        原始文件：' + ($found -join '  '))
    Say '        ※ 只增不删，历次安装的备份都留着；要回档就把里面的文件拷回游戏目录。'
    return $dests
}

# ------------------------------------------------------------------ 安装
function Invoke-Install([string]$Dir) {
    . (Join-Path $INTERNAL 'game_build.ps1')
    $profile=Get-ShadowBuildContext $Dir @('legacy','classic')
    $SCRIPT:CLASSIC_INSTALL=($profile.Family -eq 'classic')
    $SCRIPT:BACKUP_NAME=$profile.BackupName
    if(-not $profile.LegacyFallback) {$SCRIPT:BACKUP_NAME_OLD=@()}
    # ★ 第 0 步：游戏必须完全退出。
    #   放在最前面 —— 后面每一步都要动游戏目录里的文件，等发现问题再回滚就晚了。
    if (Test-GameRunning) {
        Fail ("检测到《梦江湖》正在运行，安装已中止。`n" +
              "`n" +
              "  表数据（Martial.bytes / Behavior.bytes）只有游戏完全退出后才能安全写入，`n" +
              "  游戏运行时写入会失败，会留下「插件装上了、数据表却没打补丁」的半成品状态。`n" +
              "`n" +
              "  请这样做：`n" +
              "    1. 完全退出游戏 —— 退到桌面，不是退到标题界面；`n" +
              "       （存档目录就在游戏目录里，退出时不要直接结束进程，让它正常保存）`n" +
              "    2. 回到这个文件夹，重新双击 1-安装.bat")
    }

    # ---- 1) 读取功能开关 ----
    #   ★ 放在最前面：后面每一步装什么、还原什么，全看这份开关。
    Say '[1/8] 读取功能开关'
    $swPath = Join-Path $ROOT $SWITCH_NAME
    if ($UseLastConfig) {
        $sw = Read-LastInstallSwitches $Dir
        Sync-SwitchDocuments $Dir $sw -PackageOnly
        Say '      已读取上次成功安装配置；缺漏项采用当前版本默认值。'
    }
    else { $sw = Read-Switches $swPath }
    # ★ 必须存到 script 作用域：函数内的 $sw 出了函数就没了，
    #   而下面的"安装完成"汇总要用它。忘了这一步会在 Set-StrictMode 下直接报错。
    Reset-InstallResults
    $SCRIPT:REQUESTED_SW=$sw.Clone()
    $SCRIPT:SW = $sw
    if ($sw['__found']) {
        Say ('      文件：' + $SWITCH_NAME)
    }
    else {
        Say ('      ! 包目录里找不到「' + $SWITCH_NAME + '」')
        Say '        （老版本的包没有这个文件，不影响使用）'
        Say '        本次按"全部功能都开"处理。想要开关请重新解压新包。'
    }
    foreach ($nk in $FEAT_DEF.Keys) {
        $k = $FEAT_DEF[$nk]
        $mark = '[开]'
        if (-not $sw[$k]) { $mark = '[关]' }
        $note = ''
        if ($sw['__found'] -and -not $sw['__seen'].ContainsKey($k)) {
            $defaultLabel = if ($FEAT_DEFAULT_OFF -contains $k) { '关' } else { '开' }
            $note = '   (配置里没写，按默认=' + $defaultLabel + ')'
        }
        Say ('      ' + $mark + '  ' + $nk + $note)
    }
    foreach ($b in @($sw['__bad'])) {
        Say ('      ! 这行没看懂，已按"开"处理：' + $b)
    }
    if (@($sw['__bad']).Count -gt 0) {
        Say ('        功能名请照抄「' + $SWITCH_NAME + '」里的写法，只改冒号后面的 0 / 1。')
    }
    Say ''

    . (Join-Path $INTERNAL 'patch_editor_compat.ps1')
    $editorTakeoverPlan=$null
    try {$editorTakeoverPlan=Get-EditorTakeoverRestorePlan $Dir}
    catch {Add-InstallSkip @() $_.Exception.Message '编辑器原生接管（保留现状）' $false}
    . (Join-Path $INTERNAL 'patch_custom_martials.ps1')
    if(-not $SCRIPT:CLASSIC_INSTALL) {$null = Update-MartialJsonFix ([IO.File]::ReadAllBytes((Join-Path $Dir 'DreamRivakes_Data\Plugins\ClientDll.dll'))) ([bool]($sw['fix.martialjson'] -or $sw['fix.taichain'] -or $sw['balance.taichain'])) $INTERNAL}

    if($SCRIPT:CLASSIC_INSTALL) {
        . (Join-Path $INTERNAL 'classic_install_adapter.ps1')
        try {$SCRIPT:CLASSIC_PLAN=Get-ClassicInstallPlan $Dir $sw $INTERNAL $editorTakeoverPlan}
        catch {throw ('基础原生文件无法识别，安装尚未写入游戏文件：'+$_.Exception.Message)}
        $SCRIPT:NATIVE_PLAN_ISSUES=$SCRIPT:INSTALL_SKIPS.Count
    }

    # ---- 2) 备份存档（基础功能，不跟开关走）----
    #   ★ 必须排在所有写操作之前：后面要建备份目录、覆盖安装日志、写表、动
    #     BepInEx，中间出任何意外，都还有这份存档可以退回。
    Say '[2/8] 备份存档'
    $SCRIPT:SAVEBAK = Backup-SaveData $Dir $SaveBakDocs
    Say ''

    $bak = Join-Path $Dir $BACKUP_NAME
    $manifestPath = Join-Path $bak $MANIFEST_NAME
    $existDir = Join-Path $bak 'existing'

    if (Test-Path -LiteralPath $manifestPath) {
        Say '检测到这台机器上已经装过一次。'
        Say '继续将覆盖安装（原版备份不会被覆盖，仍是最早那份）。'
        Say '被关掉的功能如果上次装过，这次会被还原。'
        Say ''
    }

    New-Item -ItemType Directory -Force -Path $bak | Out-Null
    if ($null -ne $editorTakeoverPlan) {
        $editorTakeoverBackup = Invoke-EditorTakeoverRestore $editorTakeoverPlan $bak
        Say ('      + 后安装暗影 MOD 优先：已备份并撤销互斥编辑器原生会话，备份=' + $editorTakeoverBackup)
    }

    if($SCRIPT:CLASSIC_INSTALL) {
        $nativeBackup=Join-Path $bak $BAK_DLL
        if(-not (Test-Path -LiteralPath $nativeBackup)) {[IO.File]::WriteAllBytes($nativeBackup,$SCRIPT:CLASSIC_PLAN.Original)}
        elseif((Get-ShadowGameBuild ([IO.File]::ReadAllBytes($nativeBackup))).Family -ne 'classic') {throw 'Classic backup belongs to another game build'}
    }

    # ---- 3) 备份原表（三张：Martial = MOD1 用，Behavior = 冒险手札用，
    #         TaskReward = 玉鸣子的考验用。每张各自独立备份/还原）----
    Say '[3/8] 备份原文件'
    . (Join-Path $INTERNAL 'patch_maze_sweep.ps1')
    $sweepTagPath=Join-Path $Dir 'TableData\TaskTag.bytes'
    $sweepTagBackup=Join-Path $bak 'TaskTag.bytes.orig'
    if (-not (Test-Path -LiteralPath $sweepTagBackup)) {
        $cleanTags=Update-MazeSweepTags ([IO.File]::ReadAllBytes($sweepTagPath)) $false $INTERNAL
        [IO.File]::WriteAllBytes($sweepTagBackup,$cleanTags)
    }
    $recastPath=Join-Path $Dir 'TableData\ItemRecastAttrGen.bytes'
    $recastRangePath=Join-Path $Dir 'TableData\ItemBaseRecast.bytes'
    if($sw['optimize.recast'] -and -not (Test-Path -LiteralPath (Join-Path $bak 'ItemBaseRecast.bytes.orig'))) {Copy-Item -LiteralPath $recastRangePath -Destination (Join-Path $bak 'ItemBaseRecast.bytes.orig')}
    if($sw['optimize.recast'] -and -not (Test-Path -LiteralPath (Join-Path $bak 'ItemRecastAttrGen.bytes.orig'))) {Copy-Item -LiteralPath $recastPath -Destination (Join-Path $bak 'ItemRecastAttrGen.bytes.orig')}
    $shopPath=Join-Path $Dir 'TableData\Shop.bytes'
    $shopBackup=Join-Path $bak 'Shop.bytes.orig'
    if(-not (Test-Path -LiteralPath $shopBackup) -and $sw['optimize.shopmaps']) {
        Copy-Item -LiteralPath $shopPath -Destination $shopBackup
        Say '      + TableData\Shop.bytes -> 备份'
    }
    $tbl = Join-Path $Dir 'TableData\Martial.bytes'
    $tblBak = Join-Path $bak 'Martial.bytes.orig'
    if (Test-Path -LiteralPath $tblBak) {
        Say '      = Martial.bytes 已有原版备份，保留最早那份'
    }
    else {
        Copy-Item -LiteralPath $tbl -Destination $tblBak -Force
        Say '      + TableData\Martial.bytes  ->  备份'
    }

    $tblAdv = Join-Path $Dir 'TableData\Behavior.bytes'
    $tblAdvBak = Join-Path $bak 'Behavior.bytes.orig'
    $advReady = (Test-Path -LiteralPath $tblAdv)
    if (-not $advReady) {
        Say '      ! 找不到 TableData\Behavior.bytes —— MOD2（冒险手札修复）将跳过'
    }
    elseif (Test-Path -LiteralPath $tblAdvBak) {
        Say '      = Behavior.bytes 已有原版备份，保留最早那份'
    }
    else {
        Copy-Item -LiteralPath $tblAdv -Destination $tblAdvBak -Force
        Say '      + TableData\Behavior.bytes  ->  备份'
    }

    # 新建角色词条优化（RoleGiftpool.bytes）—— 同样只在首次安装时留一份原版
    $tblGp = Join-Path $Dir 'TableData\RoleGiftpool.bytes'
    $tblGpBak = Join-Path $bak 'RoleGiftpool.bytes.orig'
    $gpReady = (Test-Path -LiteralPath $tblGp)
    if (-not $gpReady) {
        Say '      ! 找不到 TableData\RoleGiftpool.bytes —— 新建角色词条优化将跳过'
    }
    elseif (Test-Path -LiteralPath $tblGpBak) {
        Say '      = RoleGiftpool.bytes 已有原版备份，保留最早那份'
    }
    else {
        Copy-Item -LiteralPath $tblGp -Destination $tblGpBak -Force
        Say '      + TableData\RoleGiftpool.bytes  ->  备份'
    }

    # 装备白字属性完美（ItemBaseStatic.bytes）—— 同样只在首次安装时留一份原版
    $tblSm = Join-Path $Dir 'TableData\ItemBaseStatic.bytes'
    $tblSmBak = Join-Path $bak 'ItemBaseStatic.bytes.orig'
    $smReady = (Test-Path -LiteralPath $tblSm)
    if (-not $smReady) {
        Say '      ! 找不到 TableData\ItemBaseStatic.bytes —— 装备白字属性完美将跳过'
    }
    elseif (Test-Path -LiteralPath $tblSmBak) {
        Say '      = ItemBaseStatic.bytes 已有原版备份，保留最早那份'
    }
    else {
        Copy-Item -LiteralPath $tblSm -Destination $tblSmBak -Force
        Say '      + TableData\ItemBaseStatic.bytes  ->  备份'
    }

    $tblYmz = Join-Path $Dir 'TableData\TaskReward.bytes'
    $tblYmzBak = Join-Path $bak 'TaskReward.bytes.orig'
    $ymzReady = (Test-Path -LiteralPath $tblYmz)
    if (-not $ymzReady) {
        Say '      ! 找不到 TableData\TaskReward.bytes —— 玉鸣子的考验修复将跳过'
    }
    elseif (Test-Path -LiteralPath $tblYmzBak) {
        Say '      = TaskReward.bytes 已有原版备份，保留最早那份'
    }
    else {
        Copy-Item -LiteralPath $tblYmz -Destination $tblYmzBak -Force
        Say '      + TableData\TaskReward.bytes  ->  备份'
    }

    # ---- 4) 部署插件运行环境（纯增量：已有 BepInEx 一律不覆盖） ----
    #
    # ★ 兼容性要点：winhttp.dll / doorstop_config.ini / BepInEx\core\ 是**公共
    #   基础设施**，别人的 MOD（尤其其它 BepInEx 插件）也在用。直接覆盖会把对方
    #   的 BepInEx 换版本、甚至搞坏他的插件。所以这里只补"缺的"，已存在的一律保留。
    Say ''
    Say '[4/8] 安装插件运行环境'
    $files = @(Get-ChildItem -LiteralPath $PAYLOAD -Recurse -File)
    $entries = New-Object System.Collections.Generic.List[object]
    $keptRuntime = 0
    $keptSkinImages = 0
    foreach ($f in $files) {
        $rel = $f.FullName.Substring($PAYLOAD.Length).TrimStart('\')
        $dst = Join-Path $Dir $rel

        # Existing skin images belong to the player; only install missing ones.
        $isSkinImage = ($rel -like 'mod\暗影mod\角色换图\*') -and
                       ($f.Extension.ToLowerInvariant() -in @('.png', '.jpg', '.jpeg', '.webp', '.bmp', '.tga', '.gif', '.dds', '.tif', '.tiff'))
        if ($isSkinImage -and (Test-Path -LiteralPath $dst)) {
            $keptSkinImages++
            continue
        }

        # 只有本 MOD 自己的两个文件才允许覆盖；其余（winhttp / doorstop /
        # core\* / BepInEx.cfg）都算公共运行环境，已存在就原样保留。
        # v0.23: 业务逻辑已外置成明文脚本 + 图标, 这两个也必须允许覆盖 ——
        #   否则第二次安装会因为"目标已存在"被跳过, 玩家改过/旧版的 lua 永远留着。
        $isOurs = ($rel -eq 'BepInEx\plugins\XiakeConsultFix.dll') -or
                  ($rel -eq 'BepInEx\config\XiakeConsultFix.txt') -or
                  ($rel -eq 'BepInEx\plugins\XiakeConsultFix\consult_hook.lua') -or
                  ($rel -eq 'BepInEx\plugins\XiakeConsultFix\clan_wish_rewards.json') -or
                  ($rel -eq 'BepInEx\plugins\XiakeConsultFix\wish_clan_sources.json') -or
                  ($rel -eq 'BepInEx\plugins\pointing-68x42-v1.png') -or
                  ($rel -eq 'TableData\RoleWishQuest.bytes') -or
                  ($rel -eq 'TableData\RoleWishReward.bytes') -or
                  ($rel -eq 'ModProject\GameProject\Mod_MJH\Json\RoleWishQuest_OneWish.json') -or
                  ($rel -eq 'ModProject\GameProject\Mod_MJH\Json\RoleWishReward_OneWish.json') -or
                  ($rel -eq 'ModProject\GameProject\Mod_MJH\Json\Language_OneWish.json') -or
                  ($rel -eq 'ModProject\GameProject\Mod_MJH\Json\Item_RandomEquip.json') -or   # v0.30 随机装备变体表（我们自己的，允许覆盖更新）
                  ($rel -eq 'ModProject\GameProject\Mod_MJH\Json\Gift_NoEquipLimit.json') -or   # 自创蓝条「无拘」Gift 90001（我们自己的，允许覆盖更新）
                  ($rel -eq 'ModProject\GameProject\Mod_MJH\Json\Language_NoEquipLimit.json') -or # 自创蓝条「无拘」文案（我们自己的，允许覆盖更新）
                  ($rel -like 'mod\暗影mod\角色换图\*')                                       # 角色换皮资源（已有图片在上面保留，只补缺失图片）
        if (-not $isOurs -and (Test-Path -LiteralPath $dst)) {
            $keptRuntime++
            continue
        }

        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
        $overwrote = $false
        if (Test-Path -LiteralPath $dst) {
            # ★ 关键：先判断目标文件是不是"就是我们自己上次装的那一份"
            #   （内容与包内文件完全一致）。
            #   是 → 直接覆盖，卸载时删掉它即可；
            #   不是 → 才当成"别人的文件"备份到 existing\，卸载时还原回去。
            #   少了这一步会出大问题：第二次安装会把我们**自己的**文件备份成
            #   existing\，于是卸载变成"还原到上次装的那一版"，插件永远卸不干净。
            $sameAsOurs = ((Get-FileHash -LiteralPath $dst -Algorithm MD5).Hash -eq
                           (Get-FileHash -LiteralPath $f.FullName -Algorithm MD5).Hash)
            if (-not $sameAsOurs) {
                $eb = Join-Path $existDir $rel
                New-Item -ItemType Directory -Force -Path (Split-Path -Parent $eb) | Out-Null
                # 已有备份就别动它 —— 保留最早那份"别人的原件"
                if (-not (Test-Path -LiteralPath $eb)) {
                    Copy-Item -LiteralPath $dst -Destination $eb -Force
                }
                $overwrote = $true
            }
        }
        Copy-Item -LiteralPath $f.FullName -Destination $dst -Force
        $entries.Add([pscustomobject]@{ rel = $rel; overwrote = $overwrote })
    }

    . (Join-Path $INTERNAL 'patch_custom_martials.ps1')
    $clientSkipped=@($SCRIPT:INSTALL_SKIPS | Where-Object {@($_.Keys | Where-Object {$_ -in @('fix.martialjson','fix.taichain','balance.taichain')}).Count -gt 0}).Count -gt 0
    if(-not $clientSkipped){
    Invoke-MartialJsonFix $Dir ([bool]($sw['fix.martialjson'] -or $sw['fix.taichain'] -or $sw['balance.taichain'])) $INTERNAL $bak
    Sync-CustomMartials $Dir $INTERNAL
    . (Join-Path $INTERNAL 'patch_tai_a_chain.ps1')
    Sync-TaiAChain $Dir ([bool]$sw['fix.taichain']) ([bool]$sw['balance.taichain']) $INTERNAL
    Say ('      + 铸剑无限连：崩溃修复=' + [int][bool]$sw['fix.taichain'] + '，2%概率优化=' + [int][bool]$sw['balance.taichain'])
    Say '      + 武学添加/修改修复已按开关应用，自定义武学定义已同步'

    }
    # 官方在 Main 初始化时加载配置，早于 Lua 插件保活；安装时先同步定义。
    # 不扫描示例子目录，仅处理约定的顶层文件，不触碰其他 MOD 文件。
    $customRoleSource = Join-Path $Dir 'mod\暗影mod\自定义角色'
    if (Test-Path -LiteralPath $customRoleSource) {
        foreach ($customFile in @(Get-ChildItem -LiteralPath $customRoleSource -File -Filter '*.json')) {
            if ($customFile.Name -notmatch '^(Role|Language|RoleAttr|RoleModel)_([A-Za-z0-9_-]+)\.json$') { continue }
            $customKind = $Matches[1]
            $customSuffix = $Matches[2]
            $null = Get-Content -LiteralPath $customFile.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            $customRel = 'ModProject\GameProject\Mod_MJH\Json\' + $customKind + '_ShadowCustom_' + $customSuffix + '.json'
            $customDst = Join-Path $Dir $customRel
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $customDst) | Out-Null
            $customOverwrote = $false
            if ((Test-Path -LiteralPath $customDst) -and
                ((Get-FileHash -LiteralPath $customDst -Algorithm SHA256).Hash -ne
                 (Get-FileHash -LiteralPath $customFile.FullName -Algorithm SHA256).Hash)) {
                $customBackup = Join-Path $existDir $customRel
                New-Item -ItemType Directory -Force -Path (Split-Path -Parent $customBackup) | Out-Null
                if (-not (Test-Path -LiteralPath $customBackup)) {
                    Copy-Item -LiteralPath $customDst -Destination $customBackup
                }
                $customOverwrote = $true
            }
            Copy-Item -LiteralPath $customFile.FullName -Destination $customDst -Force
            $entries.Add([pscustomobject]@{ rel = $customRel; overwrote = $customOverwrote })
        }
        Say '      + 自定义角色定义已同步至官方加载目录'
    }

    # ---- 4.5) 角色换皮：真实美术文件已在 mod\暗影mod\角色换图\（上面递归拷贝的产物），
    #   这里在资源根下建一个 junction 指过去，让立绘/头像的资源加载器能找到它们。
    #   注：zip 存不了 junction，所以安装时现建、卸载时现删。
    #   junction 只是"指针"，删它不会动目标（mod\暗影mod\角色换图）里的内容。
    Say ''
    Say '[4.5/8] 角色换皮：建立资源根 junction'
    $skinReal = Join-Path $Dir 'mod\暗影mod\角色换图'
    $skinLink = Join-Path $Dir 'ModProject\GameProject\Mod_MJH\Source\Draw\角色换图'
    if (-not (Test-Path -LiteralPath $skinReal)) {
        New-Item -ItemType Directory -Force -Path $skinReal | Out-Null
    }
    if (Test-Path -LiteralPath $skinLink) {
        $skinAttr = (Get-Item -LiteralPath $skinLink).Attributes
        if ($skinAttr -band [System.IO.FileAttributes]::ReparsePoint) {
            # ★ 拆 junction 走 .NET 的 RemoveDirectory 语义（recursive=false）：只删链接本身、
            #   不跟随目标。用 Remove-Item 的话 PowerShell 会认为"它还有子项"而弹交互确认，
            #   玩家按 Y 就顺着链接把 mod\暗影mod\角色换图 里的真素材删光。
            [System.IO.Directory]::Delete($skinLink, $false)   # 旧的 junction：只拆指针
        }
        else {
            # 旧的真实目录（v0.30 及更早的形态）。★ 该形态从未发布给玩家（用户 09-30 确认，
            #   一直在内测/自用），所以不需要做玩家数据迁移 —— 直接整体删。
            Remove-Item -LiteralPath $skinLink -Force -Recurse
        }
    }
    try {
        New-Item -ItemType Junction -Path $skinLink -Target $skinReal -Force | Out-Null
        Say ('      + junction: ' + $skinLink + '  ->  ' + $skinReal)
    }
    catch {
        Say ('      ! 建 junction 失败：' + $_.Exception.Message)
        Say '        立绘/头像换皮可能不生效；Spine/文档直接读真实路径，不受影响。'
    }

    Say ('      + 共写入 {0} 个文件（钩子插件 + 缺失的运行环境文件）' -f $entries.Count)
    if ($keptSkinImages -gt 0) { Say ('      = 保留已有角色换图 {0} 张，未覆盖' -f $keptSkinImages) }
    if ($keptRuntime -gt 0) {
        Say ('      = 检测到已有的 BepInEx 运行时，保留原有 {0} 个文件未覆盖' -f $keptRuntime)
        Say '        （这样不会砸掉别人 MOD 的运行环境）'
    }

    # 同名上游插件不再搬走 —— 本 MOD 的 GUID 与 Lua 全局名均已独立，可与之共存
    foreach ($n in @('XiakeMakeSecret.dll', 'XiakeMakeSecret.dll.off', 'XiakeMakeSecret.dll.bak_orig')) {
        $p = Join-Path $Dir ('BepInEx\plugins\' + $n)
        if (Test-Path -LiteralPath $p) {
            Say ('      = 检测到《武学纂书》插件 {0}' -f $n)
            Say '        （两者 GUID 不同，可同时运行；已原样保留，未做改动）'
        }
    }

    # 新版: 「指点」图标改名为 pointing-68x42-v1.png —— 把旧名的残留清掉。
    #   不清的话游戏目录里会永远躺着一个没人读的 png（hook 只读新名），
    #   而且它不在新清单里，卸载也不会带走它。
    foreach ($oldIcon in @('BepInEx\plugins\teach-hand-68x42.png')) {
        $p = Join-Path $Dir $oldIcon
        if (Test-Path -LiteralPath $p) {
            Remove-Item -LiteralPath $p -Force
            Say ('      - 清理旧版图标残留: ' + $oldIcon)
        }
    }

    # ---- 5) 专属解禁：保留资源，只放学习归属检查 ----
    Say ''
    Say '[5/8] 专属解禁 / 参悟数据修复'
    . $PATCHER
    $exclusiveBefore=[IO.File]::ReadAllBytes($tbl)
    try {
    $exData = [System.IO.File]::ReadAllBytes($tbl)
    if (-not (Test-ExclusiveSamples $exData)) {
        $exOriginal = Join-Path $ROOT 'repair_data\Martial.bytes'
        if (Test-Path -LiteralPath $tblBak) {
            if ((Test-ExclusiveSamples ([System.IO.File]::ReadAllBytes($tblBak)))) { $exOriginal = $tblBak }
        }
        if (-not (Test-ExclusiveSamples ([System.IO.File]::ReadAllBytes($exOriginal)))) { throw '没有可用的专属字段参考' }
        . (Join-Path $INTERNAL 'patch_editor_compat.ps1')
        $repairBytes = Repair-EditorMartialExclusive $exData ([IO.File]::ReadAllBytes($exOriginal))
        $repairBackup = Join-Path $bak ('Martial.before_exclusive_repair.' + (Get-Date -Format 'yyyyMMdd_HHmmss_fffffff') + '.bytes')
        [IO.File]::WriteAllBytes($repairBackup, $exData)
        [IO.File]::WriteAllBytes($tbl, $repairBytes)
        if (-not (Test-ExclusiveSamples ([IO.File]::ReadAllBytes($tbl)))) { throw '专属字段恢复写入校验失败' }
        Say '      + 仅恢复 Exclusive 专属字段，保留编辑器的其他武学改动' 
    }
    # Replace only a poisoned legacy backup; uninstall must not restore a cleared table.
    if ((Test-Path -LiteralPath $tblBak) -and -not (Test-ExclusiveSamples ([System.IO.File]::ReadAllBytes($tblBak)))) {
        Copy-Item -LiteralPath $tblBak -Destination ($tblBak + '.legacy_cleared') -Force
        Copy-Item -LiteralPath $tbl -Destination $tblBak -Force
    }
    $SCRIPT:SRVEXSTATE = Apply-ServerGroup '专属武学归属放行' $Dir $bak $SRV_PATCHES_EX ([bool]$sw['optimize.exclusive'])
    if ($SCRIPT:SRVEXSTATE -notin @('patched','already','off')) { throw ('专属归属补丁未应用：' + $SCRIPT:SRVEXSTATE) }

    } catch {[IO.File]::WriteAllBytes($tbl,$exclusiveBefore);$SCRIPT:SRVEXSTATE='unknown';Add-InstallSkip @('optimize.exclusive') $_.Exception.Message '专属解禁'}

    # ---- 5b) 优化mod 2：新建角色词条优化（随机池去掉橙以下的天赋）----
    #
    # 改的是 TableData\RoleGiftpool.bytes —— 原生/服务端读的天赋随机池
    # （Lua 侧全项目零引用，改 .bytes 才生效）。
    # 做法：新建角色池(GiftType=1) 里白/绿/蓝三档的 Weight 归零，让它们永远抽不中。
    # ★ 与 MOD2 同样姿态：失败/跳过**不让整个安装失败**。
    Say ''
    Say '[6/8] 优化mod 2 —— 新建角色词条优化（随机池去掉橙以下天赋）'
    $gpState = 'skipped'
    if (-not $sw['optimize.giftpool']) {
        $gpState = 'off'
        Say '      · 开关「关」—— 本功能不安装。'
        if (-not $gpReady) {
            Say '      ! 游戏目录里没有这张表，无需处理'
        }
        else {
            $rstG = Restore-Table $tblGpBak $tblGp 'RoleGiftpool.bytes'
            if ($rstG -eq 'done') { Say '      - 已把 TableData\RoleGiftpool.bytes 还原成原版（用最早那份备份）' }
            elseif ($rstG -eq 'same') { Say '      = TableData\RoleGiftpool.bytes 本来就是原版，无需还原' }
            else { Say '      = 没有本 MOD 的原版备份，保持现状不动' }
        }
    }
    elseif ($gpReady) {
        try {
            . $PATCHER_GP
            $gpData = [System.IO.File]::ReadAllBytes($tblGp)
            $gpSt = Get-GiftPoolState $gpData
            if ($gpSt.State -eq 'patched') {
                Say '      = 已经是优化后的状态，无需修改'
                $gpState = 'already'
            }
            elseif ($gpSt.State -eq 'original') {
                $gpRes = Apply-GiftPool $gpData
                [System.IO.File]::WriteAllBytes($tblGp, $gpRes.Bytes)
                Say ('      + 已把新建角色池里「白/绿/蓝」三档的权重归零（{0} 处）' -f $gpRes.Changed)
                Say '        = 权重 100(白×6) / 90(绿×2) / 70(蓝×2) -> 0，橙色及以上(橙7/金2/暗金14)保持原样'
                Say ('        ({0} 字节，长度未变)' -f $gpRes.Bytes.Length)
                $gpState = 'patched'
            }
            else {
                $gpState = 'skipped:' + $gpSt.State
                Say ('      ! 这张表的内容与预期不符（{0}），已跳过' -f $gpSt.State)
                Say '        其它功能不受影响。若你装过别的改 RoleGiftpool 表的 MOD，这是正常的。'
            }
        }
        catch {
            $gpState = 'error'
            Say ('      ! 处理 TableData\RoleGiftpool.bytes 时出错：' + $_.Exception.Message)
            Say '        已跳过本项，其它功能不受影响。'
        }
    }
    else {
        $gpState = 'skipped:nofile'
        Say '      ! 游戏目录里没有这张表，跳过'
    }

    # ---- 5c) 优化mod 3：装备白字属性完美（固定属性永远取上限）----
    #
    # 改的是 TableData\ItemBaseStatic.bytes —— 装备的**基础属性区间表**
    # （服务端/原生读的表，改 .bytes 才生效）。做法：每个品质档的左边界抬到右边界
    # （上界本身不动）⇒ 生成的装备白字直接就是原版上限，不用反复刷。
    # ★ 与上面两项同样姿态：失败/跳过**不让整个安装失败**。
    Say ''
    Say '[6/8] 优化mod 3 —— 装备白字属性完美（固定属性永远取上限）'
    $smState = 'skipped'
    if (-not $sw['optimize.staticmax']) {
        $smState = 'off'
        Say '      · 开关「关」—— 本功能不安装。'
        if (-not $smReady) {
            Say '      ! 游戏目录里没有这张表，无需处理'
        }
        else {
            $rstSm = Restore-Table $tblSmBak $tblSm 'ItemBaseStatic.bytes'
            if ($rstSm -eq 'done') { Say '      - 已把 TableData\ItemBaseStatic.bytes 还原成原版（用最早那份备份）' }
            elseif ($rstSm -eq 'same') { Say '      = TableData\ItemBaseStatic.bytes 本来就是原版，无需还原' }
            else { Say '      = 没有本 MOD 的原版备份，保持现状不动' }
        }
    }
    elseif ($smReady) {
        try {
            # ★ dot-source 必须显式传参：否则 PowerShell 会拿调用方同名变量当参数值
            . $PATCHER_SM -Path '' -Output ''
            $smData = [System.IO.File]::ReadAllBytes($tblSm)
            $smSt = Get-StaticMaxState $smData
            if ($smSt.State -eq 'patched') {
                Say '      = 已经是满值状态，无需修改'
                $smState = 'already'
            }
            elseif ($smSt.State -eq 'original' -or $smSt.State -eq 'mixed') {
                $smRes = Apply-StaticMax $smData
                [System.IO.File]::WriteAllBytes($tblSm, $smRes.Bytes)
                Say ('      + 已把 {0} 个属性区间改为取上限（共 {1} 个非零区间）' -f $smRes.Changed, $smRes.Total)
                Say '        = 装备白字（基础属性）不再随机，直接是原版区间的上限；上限本身与原版一致'
                Say ('        ({0} -> {1} 字节)' -f $smData.Length, $smRes.Bytes.Length)
                $smState = 'patched'
            }
            else {
                $smState = 'skipped:' + $smSt.State
                Say ('      ! 这张表的内容与预期不符（{0}），已跳过' -f $smSt.State)
                Say '        其它功能不受影响。若你装过别的改 ItemBaseStatic 表的 MOD，这是正常的。'
            }
        }
        catch {
            $smState = 'error'
            Say ('      ! 处理 TableData\ItemBaseStatic.bytes 时出错：' + $_.Exception.Message)
            Say '        已跳过本项，其它功能不受影响。'
        }
    }
    else {
        $smState = 'skipped:nofile'
        Say '      ! 游戏目录里没有这张表，跳过'
    }

    # ---- 6) MOD2：修复「冒险手札」漏发食材搜刮 ----
    #
    # ★ 这一项失败/跳过时**不让整个安装失败** —— MOD1 已经把环境装好了，
    #   为了一个独立的 bug 修复把整套回滚，对用户没有好处。
    # ★ 开关 fix.adventure 为「关」时：不装，并把表还原成原版。
    Say ''
    Say '[6/8] 修复mod 1 —— 修复冒险手札（食材搜刮）'
    $advState = 'skipped'
    if (-not $sw['fix.adventure']) {
        $advState = 'off'
        Say '      · 开关「关」—— 本功能不安装。'
        if (-not $advReady) {
            Say '      ! 游戏目录里没有这张表，无需处理'
        }
        else {
            $rst2 = Restore-Table $tblAdvBak $tblAdv 'Behavior.bytes'
            if ($rst2 -eq 'done') {
                Say '      - 已把 TableData\Behavior.bytes 还原成原版（用最早那份备份）'
            }
            elseif ($rst2 -eq 'same') {
                Say '      = TableData\Behavior.bytes 本来就是原版，无需还原'
            }
            else {
                Say '      = 没有本 MOD 的原版备份，保持现状不动'
            }
        }
    }
    elseif ($advReady) {
        . $PATCHER_ADV
        try {
            $advData = [System.IO.File]::ReadAllBytes($tblAdv)
            $advSt = Get-AdvState $advData
            if ($advSt.State -eq 'fixed') {
                Say '      = 已经是修复后的状态，无需修改'
                $advState = 'already'
            }
            elseif ($advSt.State -eq 'orig') {
                $advRes = Repair-AdventureGift $advData
                [System.IO.File]::WriteAllBytes($tblAdv, $advRes.Bytes)
                Say ("      + 已修复：Behavior {0} 的 Arg2 '530' -> '525'" -f $SCRIPT:ADV_ROW_ID)
                Say ('        ({0} 字节，长度未变)' -f $advRes.Bytes.Length)
                $advState = 'fixed'
            }
            else {
                $advState = 'skipped:' + $advSt.State
                Say ('      ! 这张表的内容与预期不符（{0}），已跳过 MOD2' -f (Get-AdvStateText $advSt.State))
                Say '        其它功能不受影响。若你装过别的改 Behavior 表的 MOD，这是正常的。'
            }
        }
        catch {
            $advState = 'error'
            Say '      ! MOD2 补丁未能应用，已跳过（其它功能不受影响）'
            Say ('        原因：' + $_.Exception.Message)
        }
    }
    else {
        $advState = 'no-table'
        Say '      ! 游戏目录里没有这张表，已跳过 MOD2'
    }

    # ---- 6b) 修复mod 2：玉鸣子的考验「分支奖励」缺失《列子诸考·空》----
    #
    # ★ 原版：Task 5558 的 TaskBranchRewards = {555801,555802,555803}，
    #   三条的 RewardArg1 分别指向 Drop 表里**根本不存在**的 5558491/2/3，
    #   于是额外奖励栏是空的。
    # ★ 只修第 3 条分支（555803 -> Drop 5558003 = 801080《列子诸考·空》）：
    #   五本残卷是同一套模板，每个任务段里只有"选对那条"的 drop 真实存在
    #   （材=5551005 / 仁=5552002 / 智=5556002 / 忠=5559002 / 空=5558003），
    #   5558 段唯一存在的就是 5558003，属于第 3 条分支。
    # ★ 第 1、2 条分支**保持原版不动** —— 原版就没给，MOD 不替官方补发。
    # ★ 与 MOD2 同样姿态：失败/跳过**不让整个安装失败**。
    Say ''
    Say '[6/8] 修复mod 2 —— 玉鸣子的考验分支奖励'
    $ymzState = 'skipped'
    if (-not $sw['fix.yumingzi']) {
        $ymzState = 'off'
        Say '      · 开关「关」—— 本功能不安装。'
        if (-not $ymzReady) {
            Say '      ! 游戏目录里没有这张表，无需处理'
        }
        else {
            $rst3 = Restore-Table $tblYmzBak $tblYmz 'TaskReward.bytes'
            if ($rst3 -eq 'done') { Say '      - 已把 TableData\TaskReward.bytes 还原成原版（用最早那份备份）' }
            elseif ($rst3 -eq 'same') { Say '      = TableData\TaskReward.bytes 本来就是原版，无需还原' }
            else { Say '      = 没有本 MOD 的原版备份，保持现状不动' }
        }
    }
    elseif ($ymzReady) {
        try {
            . $PATCHER_YMZ
            $ymzData = [System.IO.File]::ReadAllBytes($tblYmz)
            $ymzSt = Get-YmzState $ymzData

            # 装过旧版（三条分支都改成了 5558003）：先用原版备份还原，再按新方案打
            if ($ymzSt.State -eq 'legacy') {
                $rstOld = Restore-Table $tblYmzBak $tblYmz 'TaskReward.bytes'
                if ($rstOld -eq 'done') {
                    Say '      - 检测到旧版补丁（三条分支都给了《空》），已先用备份还原成原版'
                    $ymzData = [System.IO.File]::ReadAllBytes($tblYmz)
                    $ymzSt = Get-YmzState $ymzData
                }
                elseif ($rstOld -eq 'same') {
                    Say '      ! 原版备份本身也是旧版状态，无法自动还原：请先执行一次卸载再安装'
                }
                else {
                    Say '      ! 没有本 MOD 的原版备份，无法自动还原：请先执行一次卸载再安装'
                }
            }

            if ($ymzSt.State -eq 'fixed') {
                Say '      = 已经是修复后的状态，无需修改'
                $ymzState = 'already'
            }
            elseif ($ymzSt.State -eq 'orig') {
                $ymzRes = Repair-YumingziReward $ymzData
                [System.IO.File]::WriteAllBytes($tblYmz, $ymzRes.Bytes)
                Say ('      + 已修复：第 3 条分支（选对路线）的奖励 5558493 -> 5558003（{0} 处）' -f $ymzRes.Fixed)
                Say ('        = 801080《列子诸考·空》；第 1、2 条分支按原版保持不变')
                Say ('        ({0} 字节，长度未变)' -f $ymzRes.Bytes.Length)
                $ymzState = 'fixed'
            }
            else {
                $ymzState = 'skipped:' + $ymzSt.State
                Say ('      ! 这张表的内容与预期不符（{0}），已跳过' -f (Get-YmzStateText $ymzSt.State))
                Say '        其它功能不受影响。若你装过别的改 TaskReward 表的 MOD，这是正常的。'
            }
        }
        catch {
            $ymzState = 'error'
            Say '      ! 玉鸣子的考验补丁未能应用，已跳过（其它功能不受影响）'
            Say ('        原因：' + $_.Exception.Message)
        }
    }
    else {
        $ymzState = 'no-table'
        Say '      ! 游戏目录里没有这张表，已跳过'
    }

    # Native consult thresholds share the balance.favor switch.
    $probPath=Join-Path $Dir 'TableData\Probability.bytes'
    if (Test-Path -LiteralPath $probPath) {
        $probBackup=Join-Path $bak 'Probability.bytes.orig'
        if (-not (Test-Path -LiteralPath $probBackup)) { Copy-Item -LiteralPath $probPath -Destination $probBackup }
        . (Join-Path $INTERNAL 'patch_probability.ps1')
        $probBytes=Update-ConsultProbability ([IO.File]::ReadAllBytes($probPath)) ([bool]$sw['balance.favor'])
        [IO.File]::WriteAllBytes($probPath,$probBytes)
    }

    # ---- 7) 服务端补丁（原生 C++ 层）----
    #
    # ★ 为什么安装器要做这件事：数量上限的最终裁定在原生 C++ 层，它不认识本 MOD
    #   的「心愿/专属不占数量上限」口径，会按原始条数拦人 —— 于是出现
    #   "面板显示 x/y 是对的、学秘籍却被拒绝"。这里把那几处闸门改成恒放行。
    # ★ 按**功能分组**，各受自己的开关控制 —— 关掉其中一组不会误伤另一组：
    #     $SRV_PATCHES     数量上限 / 心愿重复领取  -> optimize.countrule
    #     $SRV_PATCHES_CW  闯王刀强化               -> optimize.chuangwang
    #     $SRV_PATCHES_BAL 经验值平衡               -> balance.exp
    #     $SRV_PATCHES_CHET 武学经验指令修复        -> fix.chetmartialexp
    #     $SRV_PATCHES_ENL 无视装备穿戴限制         -> optimize.equipnolimit
    #     $SRV_PATCHES_LNL 无视秘籍学习限制         -> optimize.learnnolimit
    #     $SRV_PATCHES_DYN 角色动态品质             -> optimize.dynrank
    #     $SRV_PATCHES_VSZ .text 映射区（共享基础项）-> 闯王刀 或 动态品质 任一开就抬
    # ★ 与 MOD2 同样的姿态：失败/跳过**不让整个安装失败**（环境原因多，比如
    #   游戏刚被 Steam 验证过完整性）。
    Say ''
    Say '[7/8] 服务端补丁（数量上限 / 心愿 / 闯王刀 / 等级压制 / 作弊指令 / 动态品质）'
    # ★ VSZ 是共享基础项，先打：闯王刀与动态品质的 cave 都落在原版 .text 末尾填充区，
    #   不把 VirtualSize 抬起来那块内存不会被映射。任一功能开就抬，两个都关才还原。
    #   刻意写成单行：反引号续行在长参数列表下容易因行尾空格失效，单行最稳
    foreach($module in @('patch_wish_candidate_store.ps1','patch_random_equip.ps1','patch_harvest_fix.ps1')) {. (Join-Path $INTERNAL $module)}
    if($SCRIPT:CLASSIC_INSTALL) {
        $dynOn=[bool]$sw['optimize.dynrank'];$cwOn=[bool]$sw['optimize.chuangwang']
        $srvState=if($sw['optimize.countrule']){'already'}else{'off'}
        $stateKeys=@{SRVWISHSTATE='optimize.wishfill';SRVCWSTATE='optimize.chuangwang';SRVBALSTATE='balance.exp';SRVCHETSTATE='fix.chetmartialexp';SRVENLSTATE='optimize.equipnolimit';SRVLNLSTATE='optimize.learnnolimit';SRVDYNSTATE='optimize.dynrank'}
        foreach($state in $stateKeys.Keys){$value=if($sw[$stateKeys[$state]]){'already'}else{'off'};Set-Variable -Scope Script -Name $state -Value $value}
        $SCRIPT:SRVVSZSTATE=if($sw['optimize.chuangwang'] -or $sw['optimize.dynrank'] -or $sw['optimize.wishfill']){'already'}else{'off'}
        Say '      = 新版原生补丁已完成预检，按功能开关统一应用'
    } else {
    . (Join-Path $INTERNAL 'patch_wish_candidate_store.ps1')
    $wishStoreDll=Join-Path $Dir $DLL_REL
    [IO.File]::WriteAllBytes($wishStoreDll,(Update-WishCandidateStore ([IO.File]::ReadAllBytes($wishStoreDll)) $false $INTERNAL))
    . (Join-Path $INTERNAL 'patch_random_equip.ps1')
    $randomDll=Join-Path $Dir $DLL_REL
    [IO.File]::WriteAllBytes($randomDll,(Update-RandomEquip ([IO.File]::ReadAllBytes($randomDll)) $false $INTERNAL))
    . (Join-Path $INTERNAL 'patch_harvest_fix.ps1')
    $harvestDll=Join-Path $Dir $DLL_REL
    [IO.File]::WriteAllBytes($harvestDll,(Update-HarvestFix ([IO.File]::ReadAllBytes($harvestDll)) $false $INTERNAL))
    $SCRIPT:SRVVSZSTATE = Apply-ServerGroup '.text 映射区（cave 共享基础项）' $Dir $bak $SRV_PATCHES_VSZ (([bool]$sw['optimize.chuangwang']) -or ([bool]$sw['optimize.dynrank']) -or ([bool]$sw['optimize.wishfill']))
    # ★★★ cave 一致性护栏（安全核心）：
    #   闯王刀与动态品质的 cave 都住在「映射区」里 —— 映射区没抬起来（VSZ 补丁没打上）
    #   而入口跳板打上了 = 入口跳进未映射内存 = **游戏一启动就崩**。
    #   所以规则是：映射区不就绪 ⇒ 这两个功能强制按「关」处理（把入口还原成原版）。
    #   宁可功能不生效，也绝不留下「跳板在、映射区不在」的半套状态。
    #   触发情形：0x210 处字节既不是原版也不是预期值（被别的工具改过 / 版本不同）。
    $vszRaised = ($SCRIPT:SRVVSZSTATE -eq 'patched' -or $SCRIPT:SRVVSZSTATE -eq 'already')
    $cwOn = ([bool]$sw['optimize.chuangwang']) -and $vszRaised
    $dynOn = ([bool]$sw['optimize.dynrank']) -and $vszRaised
    if (([bool]$sw['optimize.chuangwang']) -and -not $vszRaised) {
        Say '      ! 映射区补丁未就绪 —— 闯王刀强化本次自动不启用（防止启动崩溃）'
    }
    if (([bool]$sw['optimize.dynrank']) -and -not $vszRaised) {
        Say '      ! 映射区补丁未就绪 —— 角色动态品质本次自动不启用（防止启动崩溃）'
    }
    $wishOn = ([bool]$sw['optimize.wishfill']) -and $vszRaised
    $SCRIPT:SRVWISHSTATE = Apply-ServerGroup '心愿补足与首次武学' $Dir $bak $SRV_PATCHES_WISH $wishOn
    if ($wishOn -and $SCRIPT:SRVWISHSTATE -notin @('patched','already')) { Fail '心愿原生创建补丁未就绪，停止安装' }
    $srvState = Apply-ServerGroup '数量上限 / 心愿重复领取' $Dir $bak $SRV_PATCHES ([bool]$sw['optimize.countrule'])
    $SCRIPT:SRVCWSTATE = Apply-ServerGroup '闯王刀强化（迷宫跳过开放 + 持刀胜利积分 +100）' $Dir $bak $SRV_PATCHES_CW $cwOn
    $SCRIPT:SRVBALSTATE = Apply-ServerGroup '经验值平衡（解除等级压制）' $Dir $bak $SRV_PATCHES_BAL ([bool]$sw['balance.exp'])
    $SCRIPT:SRVCHETSTATE = Apply-ServerGroup '武学经验指令修复（CHET_ADDMARTIALEXP）' $Dir $bak $SRV_PATCHES_CHET ([bool]$sw['fix.chetmartialexp'])
    # Restore the original layout before the legacy equipment gate is applied.
    . (Join-Path $INTERNAL 'patch_dual_artifact.ps1')
    $dualDll=Join-Path $Dir 'DreamRivakes_Data\Plugins\RaceLogic_Release_x64.dll'
    if(Test-Path -LiteralPath $dualDll) {
        [byte[]]$dualBefore=[IO.File]::ReadAllBytes($dualDll)
        [byte[]]$dualBase=Update-DualArtifact $dualBefore $false $INTERNAL
        [IO.File]::WriteAllBytes($dualDll,$dualBase)
    }
    $SCRIPT:SRVENLSTATE = Apply-ServerGroup '无视装备穿戴限制（服务端闸门）' $Dir $bak $SRV_PATCHES_ENL ([bool]$sw['optimize.equipnolimit'])
    $SCRIPT:SRVLNLSTATE = Apply-ServerGroup '无视秘籍学习限制（服务端闸门）' $Dir $bak $SRV_PATCHES_LNL ([bool]$sw['optimize.learnnolimit'])
    $SCRIPT:SRVDYNSTATE = Apply-ServerGroup '角色动态品质（服务端 GetRoleRank）' $Dir $bak $SRV_PATCHES_DYN $dynOn
    }
    if ($srvState -eq 'patched' -or $SCRIPT:SRVCWSTATE -eq 'patched' -or $SCRIPT:SRVBALSTATE -eq 'patched' -or $SCRIPT:SRVCHETSTATE -eq 'patched' -or $SCRIPT:SRVENLSTATE -eq 'patched' -or $SCRIPT:SRVLNLSTATE -eq 'patched' -or $SCRIPT:SRVDYNSTATE -eq 'patched') {
        Say '      （Steam「验证文件完整性」会把它还原，之后重新装一次本 MOD 即可）'
    }

    # 安装完成时的汇总要显示它，所以存到 script 作用域
    $SCRIPT:SRVSTATE = $srvState


    # 原生回收清单与客户端预览采用相同的 OR 带出规则。
    . (Join-Path $INTERNAL 'patch_carryout.ps1')
    $carryDll=Join-Path $Dir $DLL_REL
    . (Join-Path $INTERNAL 'patch_staticmax_enhance.ps1')
    . (Join-Path $INTERNAL 'patch_dynrank_growth.ps1')
    . (Join-Path $INTERNAL 'patch_dynrank_recruit_level.ps1')
    . (Join-Path $INTERNAL 'patch_fragment.ps1')
    . (Join-Path $INTERNAL 'patch_clan_talents.ps1')
    . (Join-Path $INTERNAL 'patch_gift_mastery.ps1')
    $masteryPath=Join-Path $Dir 'TableData\Gift.bytes'
    $null=Invoke-OptionalInstallStep $Dir @('optimize.giftmastery') @('TableData\Gift.bytes') {
    $masteryData=Update-GiftMastery ([IO.File]::ReadAllBytes($masteryPath)) ([bool]$sw['optimize.giftmastery']) $INTERNAL
    [IO.File]::WriteAllBytes($masteryPath,$masteryData)

    } '精通天赋强化'
    . (Join-Path $INTERNAL 'patch_uncollectible_cap.ps1')
    . (Join-Path $INTERNAL 'patch_chongyang_reset.ps1')
    $fragmentItemPath=Join-Path $Dir 'TableData\Item.bytes'
    $null=Invoke-OptionalInstallStep $Dir @('optimize.fragment') @('TableData\Item.bytes') {
    $fragmentItems=Update-FragmentItemTable ([IO.File]::ReadAllBytes($fragmentItemPath)) ([bool]$sw['optimize.fragment'])
    [IO.File]::WriteAllBytes($fragmentItemPath,$fragmentItems)

    } '残章道具表'
    . (Join-Path $INTERNAL 'patch_maze_sweep.ps1')
    if($SCRIPT:CLASSIC_INSTALL) {
        if(-not (Test-ClassicNativeBytes ([IO.File]::ReadAllBytes($carryDll)) $SCRIPT:CLASSIC_PLAN.Input)) {throw 'Native DLL changed after classic preflight'}
        [byte[]]$carryData=$SCRIPT:CLASSIC_PLAN.Patched
    } else {
    [byte[]]$sweepBase=Update-MazeSweep ([IO.File]::ReadAllBytes($carryDll)) $false $INTERNAL
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-StaticMaxEnhance $sweepBase ([bool]$sw['optimize.staticmax']) $INTERNAL}
    }
    . (Join-Path $INTERNAL 'patch_recast_optimization.ps1')
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-RecastOptimization $carryData ([bool]$sw['optimize.recast']) $INTERNAL}
    . (Join-Path $INTERNAL 'patch_dual_artifact.ps1')
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-DualArtifact $carryData ([bool]$sw['optimize.dualartifact']) $INTERNAL ([bool]$sw['optimize.equipnolimit'])}
    . (Join-Path $INTERNAL 'patch_aoyi_optimization.ps1')
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-AoYiOptimization $carryData ([bool]$sw['optimize.aoyi']) $INTERNAL}
    if($sw['optimize.aoyi']) {Say '      + 奥义优化：首次可用回合后可重复释放，冷却1/2/2/3回合'}
    if($sw['optimize.dualartifact']) {Say '      + 双神器：可穿戴两件不同种类的神器'}
    try {
    [byte[]]$recastData=Update-RecastPercentPool ([IO.File]::ReadAllBytes($recastPath)) ([bool]$sw['optimize.recast'])
    [byte[]]$recastRanges=Update-RecastRanges ([IO.File]::ReadAllBytes($recastRangePath)) ([bool]$sw['optimize.recast']) $INTERNAL
    } catch {Add-InstallSkip @('optimize.recast') $_.Exception.Message '重铸优化';$recastData=[IO.File]::ReadAllBytes($recastPath);$recastRanges=[IO.File]::ReadAllBytes($recastRangePath)}
    if($sw['optimize.recast']) {Say '      + 重铸优化：开放百分比词条，同种百分比最多一条'}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-DynamicRankGrowth $carryData $dynOn $INTERNAL}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-DynamicRankRecruitLevel $carryData $dynOn $INTERNAL}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-ClanWishPool $carryData ([bool]$sw['optimize.wishtalents']) $INTERNAL}
    $null=Invoke-OptionalInstallStep $Dir @('optimize.clantalents','optimize.wishtalents') @('TableData\RoleGiftpool.bytes','TableData\RoleWishReward.bytes','TableData\RoleWishRewardPool.bytes') {
    foreach($name in @('RoleGiftpool','RoleWishReward','RoleWishRewardPool')) {
        $tablePath=Join-Path $Dir ('TableData\'+$name+'.bytes')
        $enabled=if($name -eq 'RoleGiftpool') {[bool]$sw['optimize.clantalents']} else {[bool]$sw['optimize.wishtalents']}
        $tableData=Update-ClanTalentTable ([IO.File]::ReadAllBytes($tablePath)) $name $enabled $INTERNAL
        [IO.File]::WriteAllBytes($tablePath,$tableData)
    }
    } '天赋与心愿随机池'
    Say '      + 天赋与心愿随机池已按开关应用'
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-ChongyangReset $carryData @{} (Join-Path $INTERNAL 'chongyang_reset.hex')}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-UncollectibleCap $carryData @{} (Join-Path $INTERNAL 'uncollectible_cap.hex')}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-Fragment $carryData @{} (Join-Path $INTERNAL 'fragment_code.hex')}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-CarryOut $carryData $sw (Join-Path $INTERNAL 'carryout_code.hex')}
    $null=Invoke-OptionalInstallStep $Dir @('optimize.mazesweep') @($sweepTagPath.Substring($Dir.TrimEnd('\').Length+1)) {
    $sweepTags=Update-MazeSweepTags ([IO.File]::ReadAllBytes($sweepTagPath)) ([bool]$sw['optimize.mazesweep']) $INTERNAL
    [IO.File]::WriteAllBytes($sweepTagPath,$sweepTags)
    } '迷宫扫荡标记'
    [byte[]]$fragmentPool=@()
    if($sw['optimize.fragment']) {$fragmentPool=Get-FragmentPool (Join-Path $Dir 'TableData')}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-Fragment $carryData $sw (Join-Path $INTERNAL 'fragment_code.hex') $fragmentPool}
    [byte[]]$capIds=@()
    if($sw['optimize.uncollectiblecap']) {$capIds=Get-UncollectibleCapIds (Join-Path $Dir 'TableData')}
    if($SCRIPT:CLASSIC_INSTALL -and $SCRIPT:INSTALL_SKIPS.Count -gt $SCRIPT:NATIVE_PLAN_ISSUES){
        $SCRIPT:CLASSIC_PLAN=Get-ClassicInstallPlan $Dir $sw $INTERNAL
        $carryData=$SCRIPT:CLASSIC_PLAN.Patched
    }
    if($SCRIPT:CLASSIC_INSTALL -and ((-not (Test-ClassicNativeBytes $fragmentPool $SCRIPT:CLASSIC_PLAN.FragmentPool)) -or (-not (Test-ClassicNativeBytes $capIds $SCRIPT:CLASSIC_PLAN.CapIds)))) {throw 'Fragment/cap tables changed after native preflight'}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-UncollectibleCap $carryData $sw (Join-Path $INTERNAL 'uncollectible_cap.hex') $capIds}
    $sweepOn=[bool]$sw['optimize.mazesweep']
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-MazeSweep $carryData $sweepOn $INTERNAL}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-HarvestFix $carryData ([bool]$sw['fix.harvest']) $INTERNAL}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-RandomEquip $carryData ([bool]$sw['optimize.randomequip']) $INTERNAL ([bool]$sw['balance.nolimitgift'])}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-WishCandidateStore $carryData ([bool]$sw['optimize.wishfill']) $INTERNAL}
    if($sw['optimize.randomequip']){Say '      + 装备随机词条：原生来源替换与制造额外奖励'}
    if($sw['fix.harvest']){Say '      + 采集天赋修复：拾取药材、矿物、食材时触发额外收益'}
    $sweepReady=Join-Path $Dir 'BepInEx\plugins\XiakeConsultFix\maze_sweep_test.ready'
    if($sweepOn){[IO.File]::WriteAllText($sweepReady,'maze-sweep-native-v2',[Text.UTF8Encoding]::new($false));Say '      + 迷宫扫荡：指定角色对话，每个迷宫每月一次'}
    elseif(Test-Path -LiteralPath $sweepReady){Remove-Item -LiteralPath $sweepReady}
    [IO.File]::WriteAllBytes($carryDll,$carryData)
    [IO.File]::WriteAllBytes($recastPath,$recastData)
    [IO.File]::WriteAllBytes($recastRangePath,$recastRanges)
    . (Join-Path $INTERNAL 'patch_recast_types.ps1')
    $typePaths=@('TableData\Item.bytes','TableData\ItemRecastAttrGen.bytes',($bak.Substring($Dir.TrimEnd('\').Length+1)+'\recast_type_pools_state.json'))
    $itemJsonDir=Join-Path $Dir 'ModProject\GameProject\Mod_MJH\Json'
    if(Test-Path -LiteralPath $itemJsonDir){foreach($f in (Get-ChildItem -LiteralPath $itemJsonDir -Filter 'Item_*.json' -File)){$typePaths+=$f.FullName.Substring($Dir.TrimEnd('\').Length+1)}}
    $null=Invoke-OptionalInstallStep $Dir @('balance.recasttypes') $typePaths {
        Invoke-RecastTypePools $Dir ([bool]$sw['balance.recasttypes']) $bak
    } '重铸优化2'
    if($sw['balance.recasttypes']) {Say '      + 重铸优化2：按装备部位区分重铸词条'}
    Say '      + 副本带出规则已应用（任一条件满足即可带出）'
    if($sw['optimize.fragment']) {Say ('      + 残章随机池 '+($fragmentPool.Length/8)+' 项，收藏补充与情缘残章已应用')}
    if($sw['optimize.uncollectiblecap']) {Say ('      + 不可收藏武学上限目标 '+($capIds.Length/4)+' 项（保留成就加成及已有等级）')}

    . (Join-Path $INTERNAL 'patch_unique_rewards.ps1')
    . (Join-Path $INTERNAL 'patch_treasure_wood.ps1')
    $null=Invoke-OptionalInstallStep $Dir @('balance.treasurewood','balance.treasurequality') @('TableData\Drop.bytes') {
    Set-TreasureWoodInGame $Dir $bak ([bool]$sw['balance.treasurewood'])
    Set-TreasureQualityInGame $Dir $bak ([bool]$sw['balance.treasurequality'])
    if($sw['balance.treasurequality']){Say '      + 藏宝图调整2：品质上限+1，已到暗金则下限+1'}
    if($sw['balance.treasurewood']){Say '      + 藏宝图掉落调整：普通紫图保持原版，橙图、金图和闯王不掉落两种木材'}

    } '藏宝图掉落调整'
    $null=Invoke-OptionalInstallStep $Dir @('optimize.uniquerewards') @('TableData\StoryDiffDrop.bytes') {
    Set-UniqueRewardsInGame $Dir $bak ([bool]$sw['optimize.uniquerewards'])
    if($sw['optimize.uniquerewards']){Say '      + 唯一奖励解锁'}


    } '唯一奖励解锁'
    # ---- 8) 写运行时开关副本 + 记录清单 ----
    . (Join-Path $INTERNAL 'patch_shop_maps.ps1')
    $null=Invoke-OptionalInstallStep $Dir @('optimize.shopmaps') @('TableData\Shop.bytes') {
    [byte[]]$shopData=Update-ShopMaps ([IO.File]::ReadAllBytes($shopPath)) ([bool]$sw['optimize.shopmaps'])
    $shopData=Update-RandomEquipShops $shopData ([bool]$sw['optimize.randomequip']) $INTERNAL
    [IO.File]::WriteAllBytes($shopPath,$shopData)
    Remove-LegacyShopMapsClientConfig $Dir
    if($sw['optimize.shopmaps']) {Say '      + 城市杂货商：普通藏宝图每月10张，高级藏宝图每月1张'}

    } '商店商品（含随机暗金商品）'
    # ★ 这个副本是给 MOD 的 Lua 脚本读的（consult_hook.lua 启动时 io.open）。
    #   必须在插件文件之后写 —— 它就在 plugins\XiakeConsultFix\ 里。
    #   ★ 内容是**安装器现算的 ASCII k=v**（不是把中文那份拷过去）：
    #     Lua 是 UTF-8 源码，读 GBK 中文名会匹配不上，所以在这里翻译一次。
    #   ★ 文件名刻意用纯 ASCII 的 features.txt：Lua 的 io.open 走 C 运行时，
    #     中文路径在 GBK 系统上会按 ANSI 解码，跟 UTF-8 源码里的字符串对不上。
    Say ''
    Say '[8/8] 写运行时开关 + 记录安装清单'
    $swDst = Join-Path $Dir $SWITCH_REL
    if ($sw['__found'] -or $SCRIPT:INSTALL_SKIPS.Count -gt 0) {
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $swDst) | Out-Null
        Write-RuntimeSwitches $swDst $sw
        Say ('      + ' + $SWITCH_REL + '  (' + (Get-Item -LiteralPath $swDst).Length + ' 字节)')
    }
    else {
        # 没开关文件 = 运行时按"全开"处理；把可能残留的旧副本删掉，
        # 否则旧的开关会继续生效，造成"我明明全开了它却还是关着"。
        if (Test-Path -LiteralPath $swDst) {
            Remove-Item -LiteralPath $swDst -Force
            Say '      - 已移除旧的运行时开关副本（移除后 = 全部功能开）'
        }
        else {
            Say '      = 无需写运行时开关'
        }
    }
    $entries.Add([pscustomobject]@{ rel = $SWITCH_REL; overwrote = $false })

    # ★ 合并上一次的清单。
    #   场景：第一次装的时候补齐了 BepInEx\core\ 里的若干文件；第二次装的时候
    #   这些文件已经存在、于是被"已存在就跳过"的规则略过，本轮清单里就没有它们了。
    #   若直接覆盖写清单，卸载时这些文件就会被漏掉、残留在游戏目录里。
    #   这里把"上次登记为【我们装进去的】(overwrote=false)、且内容仍与包内一致"
    #   的项补回来。
    $reused = 0
    if (Test-Path -LiteralPath $manifestPath) {
        try {
            $oldMan = ([System.IO.File]::ReadAllText($manifestPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json)
            $have = @{}
            foreach ($e in $entries) { $have[[string]$e.rel] = $true }
            foreach ($e in @($oldMan.files)) {
                $rel = [string]$e.rel
                if (-not $rel) { continue }
                if ($have[$rel]) { continue }
                if ($e.overwrote) { continue }   # 别人的东西，本来就不该由我们删
                $dst = Join-Path $Dir $rel
                if (-not (Test-Path -LiteralPath $dst)) { continue }
                $pkgFile = Join-Path $PAYLOAD $rel
                if (-not (Test-Path -LiteralPath $pkgFile)) { continue }
                $same = ((Get-FileHash -LiteralPath $dst -Algorithm MD5).Hash -eq
                         (Get-FileHash -LiteralPath $pkgFile -Algorithm MD5).Hash)
                if ($same) {
                    $entries.Add([pscustomobject]@{ rel = $rel; overwrote = $false })
                    $reused = $reused + 1
                }
            }
            if ($reused -gt 0) {
                Say ('      = 沿用上次的记录 {0} 项（上次装进去、这次已存在的文件）' -f $reused)
            }
        }
        catch {
            Say '      ! 上一次的清单读取失败，本次不合并（不影响安装本身）'
        }
    }

    # 清单里只留"干净"的开关快照（$sw 里的 __found/__seen 是内部用的）
    #   ★ 键用 ASCII 的运行时键（不是中文名）—— Lua 侧、日志、以后排查都按它对齐。
    $featMap = [ordered]@{}
    foreach ($nk in $FEAT_DEF.Keys) {
        $k = $FEAT_DEF[$nk]
        $featMap[$k] = $sw[$k]
    }

    # Record final installed contents, after all generated table synchronization.
    foreach ($installedEntry in $entries) {
        $installedPath = Join-Path $Dir $installedEntry.rel
        if (Test-Path -LiteralPath $installedPath -PathType Leaf) {
            $installedEntry | Add-Member -NotePropertyName installedSHA256 -NotePropertyValue (Get-FileHash -LiteralPath $installedPath -Algorithm SHA256).Hash -Force
        }
    }
    $man = [pscustomobject]@{
        mod         = $MOD_NAME
        version     = $MOD_VER
        gameBuild   = $profile.ID
        installed   = (Get-Date).ToString('s')
        gameDir     = $Dir
        table       = 'TableData\Martial.bytes'
        tableBak    = 'Martial.bytes.orig'
        tableInstalledSHA256 = (Get-FileHash -LiteralPath $tbl -Algorithm SHA256).Hash
        tableAdv    = 'TableData\Behavior.bytes'
        tableAdvBak = 'Behavior.bytes.orig'
        advState    = $advState
        tableYmz    = 'TableData\TaskReward.bytes'
        tableYmzBak = 'TaskReward.bytes.orig'
        ymzState    = $ymzState
        tableGp     = 'TableData\RoleGiftpool.bytes'
        tableGpBak  = 'RoleGiftpool.bytes.orig'
        gpState     = $gpState
        tableSm     = 'TableData\ItemBaseStatic.bytes'
        tableSmBak  = 'ItemBaseStatic.bytes.orig'
        smState     = $smState
        # 服务端闸门补丁（原生 DLL）—— 卸载时靠这几个字段还原
        serverDll   = $DLL_REL
        serverDllBak = $BAK_DLL
        srvState    = $srvState
        switchFile  = $SWITCH_REL
        # 本次生效的开关（诊断用：以后用户报"某个功能没装"时，一眼看出是开关关着）
        skipped     = $SCRIPT:INSTALL_SKIPS.ToArray()
        nativePreserved = [bool]($SCRIPT:CLASSIC_INSTALL -and $SCRIPT:CLASSIC_PLAN.NativePreserved)
        features    = $featMap
        files       = $entries
    }
    $json = $man | ConvertTo-Json -Depth 5
    [System.IO.File]::WriteAllText($manifestPath, $json, (New-Object System.Text.UTF8Encoding($false)))
    Say '      + 清单已写入备份目录'

    # ---- 收尾自检 ----
    #   不信任前几步的返回值，Behavior 表从磁盘读回核验；Martial 未修改时复用抽查结果。
    #   防的是"写的时候看着成功、落地却是另一种状态"（杀毒回滚、云同步覆盖…）。
    #   这一步通过，才说明真的装好了。
    Say ''
    Say '[自检] 核对安装结果'
    Say '      = 专属数据已通过重阳神剑、江晖剑抽查（恢复时核对写入文件）'

    if ($advReady) {
        . $PATCHER_ADV
        $chkAdv = [System.IO.File]::ReadAllBytes($tblAdv)
        $stAdv = Get-AdvState $chkAdv
        if ($sw['fix.adventure']) {
            if ($stAdv.State -eq 'fixed') {
                Say '      = Behavior.bytes 已是修复状态（食材搜刮 L5 已补上）'
            }
            elseif ($stAdv.State -eq 'orig') {
                # 本步开头要么写成功、要么本来就已修复，读回来却又变原版 = 被回滚了
                Fail '自检失败：Behavior.bytes 又变回原版（仍在漏发食材搜刮）了。'
            }
            else {
                Say ('      = Behavior.bytes 状态：' + (Get-AdvStateText $stAdv.State) + '（MOD2 按设计跳过）')
            }
        }
        else {
            if ($stAdv.State -eq 'orig') {
                Say '      = Behavior.bytes 保持原版（开关「关」）'
            }
            elseif ($stAdv.State -eq 'fixed') {
                Say '      ! 开关「关」但 Behavior.bytes 仍是修复状态 —— 多半是别的 MOD 改的，本 MOD 没碰它'
            }
            else {
                Say ('      = Behavior.bytes 状态：' + (Get-AdvStateText $stAdv.State))
            }
        }
    }

    if ($gpReady) {
        . $PATCHER_GP
        $chkGp = [System.IO.File]::ReadAllBytes($tblGp)
        $stGp = Get-GiftPoolState $chkGp
        if ($sw['optimize.giftpool']) {
            if ($stGp.State -eq 'patched') {
                Say '      = RoleGiftpool.bytes 已是优化状态（新建角色池白/绿/蓝三档权重已归零）'
            }
            elseif ($gpState -eq 'patched' -or $gpState -eq 'already') {
                Fail ('自检失败：RoleGiftpool.bytes 状态为「' + $stGp.State + '」，权重没能归零。')
            }
            else {
                Say ('      = RoleGiftpool.bytes 状态：' + $stGp.State + '（按设计跳过）')
            }
        }
        else {
            if ($stGp.State -eq 'original') {
                Say '      = RoleGiftpool.bytes 保持原版（开关「关」）'
            }
            elseif ($stGp.State -eq 'patched') {
                Say '      ! 开关「关」但 RoleGiftpool.bytes 仍是优化状态 —— 多半是别的 MOD 改的，本 MOD 没碰它'
            }
            else {
                Say ('      = RoleGiftpool.bytes 状态：' + $stGp.State)
            }
        }
    }

    if ($smReady) {
        . $PATCHER_SM -Path '' -Output ''
        $chkSm = [System.IO.File]::ReadAllBytes($tblSm)
        $stSm = Get-StaticMaxState $chkSm
        if ($sw['optimize.staticmax']) {
            if ($stSm.State -eq 'patched') {
                Say ('      = ItemBaseStatic.bytes 已是满值状态（{0} 个属性区间全部取上限）' -f $stSm.Total)
            }
            elseif ($smState -eq 'patched' -or $smState -eq 'already') {
                Fail ('自检失败：ItemBaseStatic.bytes 状态为「' + $stSm.State + '」，属性区间没能取到上限。')
            }
            else {
                Say ('      = ItemBaseStatic.bytes 状态：' + $stSm.State + '（按设计跳过）')
            }
        }
        else {
            if ($stSm.State -eq 'original') {
                Say '      = ItemBaseStatic.bytes 保持原版（开关「关」）'
            }
            elseif ($stSm.State -eq 'patched') {
                Say '      ! 开关「关」但 ItemBaseStatic.bytes 仍是满值状态 —— 多半是别的 MOD 改的，本 MOD 没碰它'
            }
            else {
                Say ('      = ItemBaseStatic.bytes 状态：' + $stSm.State)
            }
        }
    }

    if ($ymzReady) {
        . $PATCHER_YMZ
        $chkYmz = [System.IO.File]::ReadAllBytes($tblYmz)
        $stYmz = Get-YmzState $chkYmz
        if ($sw['fix.yumingzi']) {
            if ($stYmz.State -eq 'fixed') {
                Say '      = TaskReward.bytes 已是修复状态（第 3 条分支的奖励已指向 5558003 =《列子诸考·空》）'
            }
            elseif ($ymzState -eq 'fixed' -or $ymzState -eq 'already') {
                # 安装阶段说修好了，自检却不是 fixed —— 这不该发生
                Fail ('自检失败：TaskReward.bytes 状态为「' + (Get-YmzStateText $stYmz.State) + '」，分支奖励没能修好。')
            }
            else {
                Say ('      = TaskReward.bytes 状态：' + (Get-YmzStateText $stYmz.State) + '（按设计跳过）')
            }
        }
        else {
            if ($stYmz.State -eq 'orig') {
                Say '      = TaskReward.bytes 保持原版（开关「关」）'
            }
            elseif ($stYmz.State -eq 'fixed') {
                Say '      ! 开关「关」但 TaskReward.bytes 仍是修复状态 —— 多半是别的 MOD 改的，本 MOD 没碰它'
            }
            else {
                Say ('      = TaskReward.bytes 状态：' + (Get-YmzStateText $stYmz.State))
            }
        }
    }

    if($SCRIPT:CLASSIC_INSTALL) {
        if(-not (Test-ClassicNativeBytes ([IO.File]::ReadAllBytes((Join-Path $Dir $DLL_REL))) $SCRIPT:CLASSIC_PLAN.Patched)) {throw 'Classic native write verification failed'}
        Say '      = 新版原生补丁回读一致'
    } else {
    # 服务端补丁：读回来确认真的写进去了（各组分别复核）
    foreach ($g in @(
        @{ N = '心愿补足'; P = $SRV_PATCHES_WISH; S = $SCRIPT:SRVWISHSTATE },
        @{ N = '专属归属放行'; P = $SRV_PATCHES_EX; S = $SCRIPT:SRVEXSTATE },
        @{ N = '数量上限 / 心愿'; P = $SRV_PATCHES;    S = $srvState },
        @{ N = '闯王刀强化';      P = $SRV_PATCHES_CW; S = $SCRIPT:SRVCWSTATE },
        @{ N = '经验值平衡';      P = $SRV_PATCHES_BAL; S = $SCRIPT:SRVBALSTATE },
        @{ N = '武学经验指令修复'; P = $SRV_PATCHES_CHET; S = $SCRIPT:SRVCHETSTATE },
        @{ N = '无视装备穿戴限制'; P = $SRV_PATCHES_ENL; S = $SCRIPT:SRVENLSTATE },
        @{ N = '无视秘籍学习限制'; P = $SRV_PATCHES_LNL; S = $SCRIPT:SRVLNLSTATE },
        @{ N = '角色动态品质';    P = $SRV_PATCHES_DYN; S = $SCRIPT:SRVDYNSTATE },
        @{ N = '.text 映射区';    P = $SRV_PATCHES_VSZ; S = $SCRIPT:SRVVSZSTATE })) {
        if ($g.S -eq 'patched' -or $g.S -eq 'already') {
            $chkSrv = Get-ServerGateState (Join-Path $Dir $DLL_REL) $g.P
            if ($chkSrv.State -eq 'patched') {
                Say ('      = 服务端「{0}」{1} 处均已写入' -f $g.N, $g.P.Count)
            }
            else {
                Say ('      ! 服务端「{0}」读回来是「{1}」，与刚才写入的结果不符' -f $g.N, $chkSrv.State)
                Say '        多半是写完之后又被别的程序还原了（杀毒 / 云同步）。重装一次即可。'
            }
        }
    }

    # ★★★ cave 一致性终检（兜底安全线，任何路径都要过这一关）：
    #   映射区（VSZ）没抬起来 ⇒ 闯王刀 / 动态品质 的 cave 入口**必须**是原版字节。
    #   入口在而映射区不在 = 游戏一启动就崩。正常流程上面的护栏已保证走不到这里；
    #   这一道防的是极端残留：还原中途失败 / 杀毒软件还原一半 / 其它工具改过。
    #   能修就修（把入口还原成原版），修不动就明确报错停在这里 —— 绝不静默放行
    #   一个会让游戏崩溃的状态。
    $chkDllPath = Join-Path $Dir $DLL_REL
    if (Test-Path -LiteralPath $chkDllPath) {
        $vszFinal = (Get-ServerGateState $chkDllPath $SRV_PATCHES_VSZ).State
        if ($vszFinal -ne 'patched') {
            foreach ($cg in @(@{ N = '闯王刀强化'; P = $SRV_PATCHES_CW },
                              @{ N = '角色动态品质'; P = $SRV_PATCHES_DYN },
                              @{ N = '心愿补足'; P = $SRV_PATCHES_WISH })) {
                $cst = (Get-ServerGateState $chkDllPath $cg.P).State
                if ($cst -ne 'orig') {
                    Say ('      ! 一致性护栏：映射区未抬起但「' + $cg.N + '」入口是「' + $cst + '」—— 正在强制还原入口')
                    $fr = Restore-ServerPatch $Dir $cg.P
                    if ($fr -like 'done:*' -or $fr -eq 'same') {
                        Say ('      + 已把「' + $cg.N + '」入口还原成原版字节（本功能本次不生效）')
                    }
                    else {
                        Fail ('无法把「' + $cg.N + '」还原成原版字节（当前状态 ' + $cst + '）。' + "`n" +
                              '  保留这个状态启动游戏会崩溃。请运行 patch_server.ps1 -Restore 整份还原后再试。')
                    }
                }
            }
        }
        elseif ($vszFinal -eq 'patched') {
            Say '      = cave 一致性：映射区已抬起，闯王刀 / 动态品质入口状态匹配'
        }
    }

    }

    # v0.23: 三件套自检 —— 少了外置脚本, DLL 虽然还在但只剩引导器
    Say ('      = 插件三件套')
    foreach ($r in @('BepInEx\plugins\XiakeConsultFix.dll',
                     'BepInEx\plugins\XiakeConsultFix\consult_hook.lua',
                     'BepInEx\plugins\pointing-68x42-v1.png',
                     'ModProject\GameProject\Mod_MJH\Json\Item_RandomEquip.json',
                     'ModProject\GameProject\Mod_MJH\Json\Gift_NoEquipLimit.json',
                     'ModProject\GameProject\Mod_MJH\Json\Language_NoEquipLimit.json'
)) {
        $pf = Join-Path $Dir $r
        if (Test-Path -LiteralPath $pf) {
            Say ('        OK  ' + $r + '  ' + (Get-Item -LiteralPath $pf).Length + ' 字节')
        }
        else {
            Fail ('自检失败：缺少 ' + $r + '。请重新解压安装包再装一次。')
        }
    }

    # 运行时开关副本是否落地（MOD 靠它决定开哪些功能）
    if ($sw['__found']) {
        if (Test-Path -LiteralPath $swDst) {
            Say ('        OK  ' + $SWITCH_REL)
        }
        else {
            Fail ('自检失败：没写进 ' + $SWITCH_REL + '，功能开关不会生效。请重新解压安装包再装一次。')
        }
    }

    return $bak
}

# ------------------------------------------------------------------ 卸载
function Invoke-Uninstall([string]$Dir) {
    . (Join-Path $INTERNAL 'game_build.ps1')
    $profile=Get-ShadowBuildContext $Dir @('legacy','classic')
    $SCRIPT:CLASSIC_INSTALL=($profile.Family -eq 'classic')
    $SCRIPT:BACKUP_NAME=$profile.BackupName
    if(-not $profile.LegacyFallback) {$SCRIPT:BACKUP_NAME_OLD=@()}
    # 卸载同样要写游戏目录里的表，所以同样要求游戏已退出。
    if (Test-GameRunning) {
        Fail ("检测到《梦江湖》正在运行，卸载已中止。`n" +
              "  表文件被游戏占用时无法还原。请完全退出游戏后，重新双击 2-卸载.bat。")
    }

    if($SCRIPT:CLASSIC_INSTALL) {
        . (Join-Path $INTERNAL 'patch_classic_bundle.ps1')
        . (Join-Path $INTERNAL 'classic_install_adapter.ps1')
        $SCRIPT:CLASSIC_PLAN=Update-ClassicNativeBundle ([IO.File]::ReadAllBytes((Join-Path $Dir $DLL_REL))) @{} $INTERNAL -BestEffort
        foreach($issue in $SCRIPT:CLASSIC_PLAN.Skipped){Say ('      ! 部分原生组件未还原：'+$issue.Reason)}
    }

    $probPath=Join-Path $Dir 'TableData\Probability.bytes'
    if (Test-Path -LiteralPath $probPath) {
        . (Join-Path $INTERNAL 'patch_probability.ps1')
        $probBytes=Update-ConsultProbability ([IO.File]::ReadAllBytes($probPath)) $false
        [IO.File]::WriteAllBytes($probPath,$probBytes)
    }


    $carryDll=Join-Path $Dir $DLL_REL
    if(Test-Path -LiteralPath $carryDll) {
        . (Join-Path $INTERNAL 'patch_staticmax_enhance.ps1')
        . (Join-Path $INTERNAL 'patch_dynrank_growth.ps1')
        . (Join-Path $INTERNAL 'patch_dynrank_recruit_level.ps1')
        . (Join-Path $INTERNAL 'patch_carryout.ps1')
        . (Join-Path $INTERNAL 'patch_fragment.ps1')
        . (Join-Path $INTERNAL 'patch_clan_talents.ps1')
        . (Join-Path $INTERNAL 'patch_gift_mastery.ps1')
        $masteryPath=Join-Path $Dir 'TableData\Gift.bytes'
        if(Test-Path -LiteralPath $masteryPath) {
            $masteryData=Update-GiftMastery ([IO.File]::ReadAllBytes($masteryPath)) $false $INTERNAL
            [IO.File]::WriteAllBytes($masteryPath,$masteryData)
        }
        . (Join-Path $INTERNAL 'patch_uncollectible_cap.ps1')
        . (Join-Path $INTERNAL 'patch_chongyang_reset.ps1')
    $fragmentItemPath=Join-Path $Dir 'TableData\Item.bytes'
    if(Test-Path -LiteralPath $fragmentItemPath) {
        $fragmentItems=Update-FragmentItemTable ([IO.File]::ReadAllBytes($fragmentItemPath)) $false
        [IO.File]::WriteAllBytes($fragmentItemPath,$fragmentItems)
    }
    . (Join-Path $INTERNAL 'patch_maze_sweep.ps1')
    . (Join-Path $INTERNAL 'patch_harvest_fix.ps1')
    . (Join-Path $INTERNAL 'patch_random_equip.ps1')
    . (Join-Path $INTERNAL 'patch_wish_candidate_store.ps1')
    if($SCRIPT:CLASSIC_INSTALL) {
        [byte[]]$carryData=$SCRIPT:CLASSIC_PLAN.Patched
    } else {
    [byte[]]$wishBase=Update-WishCandidateStore ([IO.File]::ReadAllBytes($carryDll)) $false $INTERNAL
    [byte[]]$randomBase=Update-RandomEquip $wishBase $false $INTERNAL
    [byte[]]$harvestBase=Update-HarvestFix $randomBase $false $INTERNAL
    [byte[]]$sweepBase=Update-MazeSweep $harvestBase $false $INTERNAL
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-StaticMaxEnhance $sweepBase $false $INTERNAL}
    }
    . (Join-Path $INTERNAL 'patch_recast_optimization.ps1')
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-RecastOptimization $carryData $false $INTERNAL}
    . (Join-Path $INTERNAL 'patch_dual_artifact.ps1')
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-DualArtifact $carryData $false $INTERNAL}
    . (Join-Path $INTERNAL 'patch_aoyi_optimization.ps1')
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-AoYiOptimization $carryData $false $INTERNAL}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-DynamicRankGrowth $carryData $false $INTERNAL}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-DynamicRankRecruitLevel $carryData $false $INTERNAL}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-ClanWishPool $carryData $false $INTERNAL}
    foreach($name in @('RoleGiftpool','RoleWishReward','RoleWishRewardPool')) {
        $tablePath=Join-Path $Dir ('TableData\'+$name+'.bytes')
        if(Test-Path -LiteralPath $tablePath) {
            $tableData=Update-ClanTalentTable ([IO.File]::ReadAllBytes($tablePath)) $name $false $INTERNAL
            [IO.File]::WriteAllBytes($tablePath,$tableData)
        }
    }
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-ChongyangReset $carryData @{} (Join-Path $INTERNAL 'chongyang_reset.hex')}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-UncollectibleCap $carryData @{} (Join-Path $INTERNAL 'uncollectible_cap.hex')}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-Fragment $carryData @{} (Join-Path $INTERNAL 'fragment_code.hex')}
    if(-not $SCRIPT:CLASSIC_INSTALL) {$carryData=Update-CarryOut $carryData @{} (Join-Path $INTERNAL 'carryout_code.hex')}
        [IO.File]::WriteAllBytes($carryDll,$carryData)
    $sweepTagPath=Join-Path $Dir 'TableData\TaskTag.bytes'
    if(Test-Path -LiteralPath $sweepTagPath){[IO.File]::WriteAllBytes($sweepTagPath,(Update-MazeSweepTags ([IO.File]::ReadAllBytes($sweepTagPath)) $false $INTERNAL))}
    $sweepReady=Join-Path $Dir 'BepInEx\plugins\XiakeConsultFix\maze_sweep_test.ready'
    if(Test-Path -LiteralPath $sweepReady){Remove-Item -LiteralPath $sweepReady}

    }

    # 备份目录名改过两次（v1.0 单 MOD 版 -> v1.1 合集版 -> v1.2 暗影版），
    # 这里按"新名优先、再逐个试旧名"的顺序找。
    $bak = Join-Path $Dir $BACKUP_NAME
    if (-not (Test-Path -LiteralPath (Join-Path $bak $MANIFEST_NAME))) {
        foreach ($oldName in $BACKUP_NAME_OLD) {
            $old = Join-Path $Dir $oldName
            if (Test-Path -LiteralPath (Join-Path $old $MANIFEST_NAME)) {
                Say ('（检测到旧版留下的备份目录 ' + $oldName + '，按它来卸载）')
                $bak = $old
                break
            }
        }
    }
    $manifestPath = Join-Path $bak $MANIFEST_NAME
    if (-not (Test-Path -LiteralPath $manifestPath)) {
        Fail ('找不到安装清单，无法自动卸载：' + $manifestPath + "`n" +
              '（如果这台机器上没装过本 MOD，请确认游戏目录是否正确）')
    }
    $man = [System.IO.File]::ReadAllText($manifestPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
    $existDir = Join-Path $bak 'existing'

    . (Join-Path $INTERNAL 'patch_recast_types.ps1')
    Invoke-RecastTypePools $Dir $false $bak
    . (Join-Path $INTERNAL 'patch_recast_optimization.ps1')
    $recastPath=Join-Path $Dir 'TableData\ItemRecastAttrGen.bytes'
    if(Test-Path -LiteralPath $recastPath) {[IO.File]::WriteAllBytes($recastPath,(Update-RecastPercentPool ([IO.File]::ReadAllBytes($recastPath)) $false))}
    $recastRangePath=Join-Path $Dir 'TableData\ItemBaseRecast.bytes'
    if(Test-Path -LiteralPath $recastRangePath) {[IO.File]::WriteAllBytes($recastRangePath,(Update-RecastRanges ([IO.File]::ReadAllBytes($recastRangePath)) $false $INTERNAL))}
    . (Join-Path $INTERNAL 'patch_custom_martials.ps1')
    Invoke-MartialJsonFix $Dir $false $INTERNAL $bak
    . (Join-Path $INTERNAL 'patch_tai_a_chain.ps1')
    Sync-TaiAChain $Dir $false $false $INTERNAL

    # ---- 1) 还原原版文件（数据表 / 服务端 DLL）----
    Say '[1/3] 还原原版文件（数据表 / 服务端 DLL）'
    . (Join-Path $INTERNAL 'patch_unique_rewards.ps1')
    . (Join-Path $INTERNAL 'patch_treasure_wood.ps1')
    Set-TreasureWoodInGame $Dir $bak $false
    Set-UniqueRewardsInGame $Dir $bak $false
    . (Join-Path $INTERNAL 'patch_shop_maps.ps1')
    $shopPath=Join-Path $Dir 'TableData\Shop.bytes'
    if(Test-Path -LiteralPath $shopPath) {
        [byte[]]$shopData=Update-ShopMaps ([IO.File]::ReadAllBytes($shopPath)) $false
        $shopData=Update-RandomEquipShops $shopData $false $INTERNAL
        [IO.File]::WriteAllBytes($shopPath,$shopData)
        Remove-LegacyShopMapsClientConfig $Dir
        Say '      + 城市杂货商藏宝图配置已还原'
    }
    $tblBak = Join-Path $bak $man.tableBak
    $tbl = Join-Path $Dir $man.table
    if (Test-Path -LiteralPath $tblBak) {
        $installedHash = if ($null -ne $man.PSObject.Properties['tableInstalledSHA256']) { [string]$man.tableInstalledSHA256 } else { '' }
        $currentHash = if (Test-Path -LiteralPath $tbl) { (Get-FileHash -LiteralPath $tbl -Algorithm SHA256).Hash } else { '' }
        if ($installedHash -and $currentHash -eq $installedHash) {
            Copy-Item -LiteralPath $tblBak -Destination $tbl -Force
            Say '      + TableData\Martial.bytes 已还原'
        } else {
            Say '      = 保留后续编辑的 Martial.bytes（旧清单无校验值时也不整表回退）'
        }
    }
    else {
        Say ('      ! 找不到原版备份，跳过（请检查 ' + $tblBak + '）')
    }

    # MOD2 的 Behavior.bytes —— v1.0 的清单里没有这几个字段，所以要探测着读
    $advRel = $null
    $advBakName = $null
    if ($null -ne $man.PSObject.Properties['tableAdv']) { $advRel = [string]$man.tableAdv }
    if ($null -ne $man.PSObject.Properties['tableAdvBak']) { $advBakName = [string]$man.tableAdvBak }
    if ($advRel -and $advBakName) {
        $advBak = Join-Path $bak $advBakName
        $advDst = Join-Path $Dir $advRel
        if (Test-Path -LiteralPath $advBak) {
            Copy-Item -LiteralPath $advBak -Destination $advDst -Force
            Say '      + TableData\Behavior.bytes 已还原'
        }
        else {
            Say ('      ! 找不到原版备份，跳过（请检查 ' + $advBak + '）')
        }
    }

    # 新建角色词条优化用到的 RoleGiftpool.bytes —— 同样是探测着读（老清单没有这个字段）
    $gpRel = $null
    $gpBakName = $null
    if ($null -ne $man.PSObject.Properties['tableGp']) { $gpRel = [string]$man.tableGp }
    if ($null -ne $man.PSObject.Properties['tableGpBak']) { $gpBakName = [string]$man.tableGpBak }
    if ($gpRel -and $gpBakName) {
        $gpBakU = Join-Path $bak $gpBakName
        $gpDst = Join-Path $Dir $gpRel
        if (Test-Path -LiteralPath $gpBakU) {
            Copy-Item -LiteralPath $gpBakU -Destination $gpDst -Force
            Say '      + TableData\RoleGiftpool.bytes 已还原'
        }
        else {
            Say ('      ! 找不到原版备份，跳过（请检查 ' + $gpBakU + '）')
        }
    }

    # 装备白字属性完美用到的 ItemBaseStatic.bytes —— 同样是探测着读（老清单没有这个字段）
    $smRel = $null
    $smBakName = $null
    if ($null -ne $man.PSObject.Properties['tableSm']) { $smRel = [string]$man.tableSm }
    if ($null -ne $man.PSObject.Properties['tableSmBak']) { $smBakName = [string]$man.tableSmBak }
    if ($smRel -and $smBakName) {
        $smBakU = Join-Path $bak $smBakName
        $smDst = Join-Path $Dir $smRel
        if (Test-Path -LiteralPath $smBakU) {
            Copy-Item -LiteralPath $smBakU -Destination $smDst -Force
            Say '      + TableData\ItemBaseStatic.bytes 已还原'
        }
        else {
            Say ('      ! 找不到原版备份，跳过（请检查 ' + $smBakU + '）')
        }
    }

    # 玉鸣子的考验用到的 TaskReward.bytes —— 同样是探测着读（老清单没有这个字段）
    $ymzRel = $null
    $ymzBakName = $null
    if ($null -ne $man.PSObject.Properties['tableYmz']) { $ymzRel = [string]$man.tableYmz }
    if ($null -ne $man.PSObject.Properties['tableYmzBak']) { $ymzBakName = [string]$man.tableYmzBak }
    if ($ymzRel -and $ymzBakName) {
        $ymzBak2 = Join-Path $bak $ymzBakName
        $ymzDst = Join-Path $Dir $ymzRel
        if (Test-Path -LiteralPath $ymzBak2) {
            Copy-Item -LiteralPath $ymzBak2 -Destination $ymzDst -Force
            Say '      + TableData\TaskReward.bytes 已还原'
        }
        else {
            Say ('      ! 找不到原版备份，跳过（请检查 ' + $ymzBak2 + '）')
        }
    }

    # 服务端 DLL —— 安装器会改它（服务端闸门补丁），这里还原。
    #   清单里没这个字段 = 早期版本装的，探测着跳过即可。
    $srvRel = $null
    if ($null -ne $man.PSObject.Properties['serverDll']) { $srvRel = [string]$man.serverDll }
    if ($srvRel -and -not $SCRIPT:CLASSIC_INSTALL) {
        # ★ 两组**分开**还原，不要合并成一张表再传：
        #   合并后只要有一处字节对不上（例如测试用的假 DLL 没有 cave 那么大、
        #   或玩家换过游戏版本），整组会被判成 unknown 而全部跳过，
        #   连本来能正常还原的那一组也跟着不还原了。分组调用才能互不影响。
        $srvGroups = @(
            @{ N = '心愿补足'; P = $SRV_PATCHES_WISH },
            @{ N = '专属归属放行'; P = $SRV_PATCHES_EX },
            @{ N = '数量上限 / 心愿'; P = $SRV_PATCHES },
            @{ N = '闯王刀强化';      P = $SRV_PATCHES_CW },
            @{ N = '经验值平衡';      P = $SRV_PATCHES_BAL },
            @{ N = '武学经验指令修复'; P = $SRV_PATCHES_CHET },
            @{ N = '无视装备穿戴限制'; P = $SRV_PATCHES_ENL },
            @{ N = '无视秘籍学习限制'; P = $SRV_PATCHES_LNL },
            @{ N = '角色动态品质';    P = $SRV_PATCHES_DYN },
            # ★ VSZ 放最后还：先把各组 cave 撤掉，再降映射区
            @{ N = '.text 映射区';    P = $SRV_PATCHES_VSZ })
        foreach ($g in $srvGroups) {
            $rs = Restore-ServerPatch $Dir $g.P
            if ($rs -like 'done:*') {
                # ★ -f 必须和 Say(...) 同一条语句：换行会结束语句，把 -f 变成新的一句
                Say ('      + 服务端 DLL 已还原「{0}」{1} 处（RaceLogic_Release_x64.dll）' -f $g.N, ([string]$rs).Split(':')[1])
            }
            elseif ($rs -eq 'same')    { Say ('      = 服务端 DLL「{0}」本来就是原版' -f $g.N) }
            elseif ($rs -eq 'unknown') { Say ('      ! 服务端 DLL「{0}」字节与预期不符，未改动（不猜、不盲改）' -f $g.N) }
            elseif ($rs -eq 'error')   { Say ('      ! 服务端 DLL「{0}」还原后校验没通过，请手动检查' -f $g.N) }
            else                       { Say '      ! 游戏目录里没有服务端 DLL，跳过' }
        }
    }

    # ---- 2) 回退文件 ----
    Say ''
    Say '[2/3] 移除插件文件'
    $n = 0
    foreach ($e in @($man.files)) {
        $dst = Join-Path $Dir $e.rel
        if ($null -ne $e.PSObject.Properties['installedSHA256'] -and (Test-Path -LiteralPath $dst -PathType Leaf)) {
            if ((Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash -ne [string]$e.installedSHA256) {
                Say ('      = 保留最后写入的外部版本: ' + $e.rel)
                continue
            }
        }
        if ($e.overwrote) {
            $eb = Join-Path $existDir $e.rel
            if (Test-Path -LiteralPath $eb) {
                # 自愈：早期版本可能在 existing\ 里误存了"我们自己装的"那一份。
                # 判断依据 = 它跟包内同名文件一模一样 —— 那就不是别人的东西，
                # 直接删掉，别还原回去（否则插件会残留）。
                $pkgFile = Join-Path $PAYLOAD $e.rel
                $isOurOwn = $false
                if (Test-Path -LiteralPath $pkgFile) {
                    $isOurOwn = ((Get-FileHash -LiteralPath $eb -Algorithm MD5).Hash -eq
                                 (Get-FileHash -LiteralPath $pkgFile -Algorithm MD5).Hash)
                }
                if ($isOurOwn) {
                    if (Test-Path -LiteralPath $dst) { Remove-Item -LiteralPath $dst -Force }
                }
                else {
                    Copy-Item -LiteralPath $eb -Destination $dst -Force
                }
                $n = $n + 1
            }
        }
        else {
            if (Test-Path -LiteralPath $dst) {
                Remove-Item -LiteralPath $dst -Force
                $n = $n + 1
            }
        }
    }
    Say ('      + 处理 {0} 个文件' -f $n)

    # ---- 2.2) 角色换皮 junction：拆指针（不碰 mod\暗影mod\角色换图 里的内容）----
    $skinLink = Join-Path $Dir 'ModProject\GameProject\Mod_MJH\Source\Draw\角色换图'
    if (Test-Path -LiteralPath $skinLink) {
        $skinAttr = (Get-Item -LiteralPath $skinLink).Attributes
        if ($skinAttr -band [System.IO.FileAttributes]::ReparsePoint) {
            # ★ 同 4.5 段：只删链接本身（.NET 不递归）。别用 Remove-Item —— 它会弹交互确认，
            #   玩家按 Y 就顺着链接把 mod\暗影mod\角色换图 里的真素材删光。
            [System.IO.Directory]::Delete($skinLink, $false)
            Say '      - 删除角色换皮 junction（ModProject\...\Source\Draw\角色换图）'
        }
        else {
            # 旧的真实目录（v0.30 及更早的形态，从未发布给玩家）：直接整体删。
            Remove-Item -LiteralPath $skinLink -Force -Recurse
            Say '      - 删除角色换皮旧目录（ModProject\...\Source\Draw\角色换图）'
        }
    }
    # 收走空的 mod\暗影mod\角色换图 / mod\暗影mod（绝不动游戏官方的 mod\ 目录）
    foreach ($d in @('mod\暗影mod\角色换图', 'mod\暗影mod')) {
        $p = Join-Path $Dir $d
        if (-not (Test-Path -LiteralPath $p)) { continue }
        $left = @(Get-ChildItem -LiteralPath $p -Force)
        if ($left.Count -eq 0) {
            Remove-Item -LiteralPath $p -Force
            Say ('      - 删除空目录 ' + $d)
        }
    }

    # 恢复被挪走的上游插件
    $legacyDir = Join-Path $bak 'legacy'
    if (Test-Path -LiteralPath $legacyDir) {
        foreach ($f in @(Get-ChildItem -LiteralPath $legacyDir -File)) {
            $dst = Join-Path $Dir ('BepInEx\plugins\' + $f.Name)
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
            Move-Item -LiteralPath $f.FullName -Destination $dst -Force
            Say ('      ~ 已还原上游插件 {0}' -f $f.Name)
        }
    }

    # ---- 2.5) 收回本 MOD 自己建的目录 ----
    #   v0.23 起多了一层 plugins\XiakeConsultFix（放外置脚本 + 运行时开关副本）。
    #   里面的文件在上面第 2 步已经删掉，这里把空壳本身也收走 —— 否则
    #   plugins / BepInEx 会因为"目录非空"被判成还有别人在用，卸载完就留一堆垃圾。
    #   ★ 保险起见，先把运行时开关副本（features.txt）点名删掉：它若残留，
    #     下次"没装 MOD 却有开关文件"会让排查变得莫名其妙。
    $swDst = Join-Path $Dir $SWITCH_REL
    if (Test-Path -LiteralPath $swDst) {
        Remove-Item -LiteralPath $swDst -Force
        Say ('      - 删除运行时开关 ' + $SWITCH_REL)
    }
    # ★ secret_book_icons 也是本 MOD 建的（道具图标优化）。它若留着空壳，
    #   下面第 3 步会把 BepInEx\plugins 判成"还有内容"，整棵 BepInEx 就收不回去，
    #   卸载完在游戏目录里留一堆垃圾（e2e 的「BepInEx 目录已被收回」就是卡在这）。
    foreach ($d in @('BepInEx\plugins\XiakeConsultFix',
                     'BepInEx\plugins\secret_book_icons')) {
        $p = Join-Path $Dir $d
        if (-not (Test-Path -LiteralPath $p)) { continue }
        $left = @(Get-ChildItem -LiteralPath $p -Force)
        if ($left.Count -eq 0) {
            Remove-Item -LiteralPath $p -Force
            Say ('      - 删除本 MOD 的目录 {0}' -f $d)
        }
        else {
            Say ('      = 保留 {0}（里面还有 {1} 项，可能是你自己加的）' -f $d, $left.Count)
        }
    }

    # ---- 3) 清理空目录 ----
    Say ''
    Say '[3/3] 清理空目录'
    foreach ($d in @('BepInEx\core', 'BepInEx\plugins', 'BepInEx\config', 'BepInEx')) {
        $p = Join-Path $Dir $d
        if (-not (Test-Path -LiteralPath $p)) { continue }
        $left = @(Get-ChildItem -LiteralPath $p -Force)
        if ($left.Count -eq 0) {
            Remove-Item -LiteralPath $p -Force
            Say ('      - 删除空目录 {0}' -f $d)
        }
        else {
            Say ('      = 保留 {0}（还有 {1} 项其它内容）' -f $d, $left.Count)
        }
    }

    return $bak
}

# ------------------------------------------------------------------ 主流程
Say '============================================================'
if ($Uninstall) { Say ('  梦江湖 · {0}  ——  卸载并还原' -f $MOD_NAME) }
else { Say ('  梦江湖 · {0}  ——  一键安装' -f $MOD_NAME) }
Say '============================================================'
Say ''

if (-not (Test-Path -LiteralPath $PAYLOAD)) { Fail ('安装包不完整，缺少 payload 目录：' + $PAYLOAD) }
if (-not (Test-Path -LiteralPath $PATCHER)) { Fail ('安装包不完整，缺少 patch_table.ps1') }
if (-not (Test-Path -LiteralPath (Join-Path $INTERNAL 'patch_probability.ps1'))) { Fail '安装包缺少 patch_probability.ps1' }
foreach($carryFile in @('install_results.ps1','patch_treasure_quality.ps1','treasure_quality_table.cs','patch_treasure_wood.ps1','treasure_wood_table.cs','patch_wish_candidate_store.ps1','wish_candidate_store_native.cs','wish_candidate_store_layout.json','unique_rewards_table.cs','patch_unique_rewards.ps1','patch_random_equip.ps1','random_equip_native.cs','random_equip_layout.json','random_equip_layout_nolimit.json','patch_harvest_fix.ps1','harvest_fix_native.cs','harvest_fix_layout.json','patch_aoyi_optimization.ps1','aoyi_optimization_layout.json','patch_maze_sweep.ps1','maze_sweep_native.cs','maze_sweep_code.hex','maze_sweep_layout.json','patch_tai_a_chain.ps1','tai_a_chain_tables.json','patch_custom_martials.ps1','custom_martial_schema.json','martial_json_upsert_layout.json','martial_json_upsert.hex','martial_json_upsert_original.hex','patch_dual_artifact.ps1','dual_artifact_layout.json','dual_artifact_0_original.hex','dual_artifact_0_patched.hex','dual_artifact_1_original.hex','dual_artifact_1_patched.hex','dual_artifact_1_nolimit.hex','dual_artifact_1_legacy_patched.hex','dual_artifact_1_legacy_nolimit.hex','dual_artifact_2_original.hex','dual_artifact_2_patched.hex','patch_recast_optimization.ps1','recast_optimization.hex','recast_optimization_original.hex','patch_gift_mastery.ps1','gift_mastery_tables.json','patch_clan_talents.ps1','clan_talent_tables.json','clan_wish_pool.hex','clan_wish_pool_original.hex','clan_wish_pool_legacy.hex','patch_dynrank_growth.ps1','dynrank_growth.hex','dynrank_growth_original.hex','dynrank_growth_addexp.hex','dynrank_growth_addrole.hex','dynrank_growth_legacy.hex','dynrank_growth_attack_legacy.hex','patch_dynrank_recruit_level.ps1','dynrank_recruit_level.hex','dynrank_recruit_level_original.hex','patch_staticmax_enhance.ps1','staticmax_enhance.hex','staticmax_enhance_original.hex','patch_fragment_items.ps1','fragment_extra_items.json','patch_carryout.ps1','carryout_code.hex','carryout_code_legacy.hex','patch_fragment.ps1','fragment_code.hex','patch_uncollectible_cap.ps1','uncollectible_cap.hex')) { if(-not (Test-Path -LiteralPath (Join-Path $INTERNAL $carryFile))) {Fail ('安装包缺少 '+$carryFile)} }
if (-not (Test-Path -LiteralPath $PATCHER_ADV)) { Fail '安装包不完整，缺少 patch_behavior.ps1' }
if (-not (Test-Path -LiteralPath $PATCHER_YMZ)) { Fail '安装包不完整，缺少 patch_taskreward.ps1' }
if (-not (Test-Path -LiteralPath $PATCHER_SM)) { Fail '安装包不完整，缺少 patch_item_static_max.ps1' }

# ------------------------------------------------------------ 定位游戏目录
# 本包的姿势是「解压到游戏主目录里再运行」，所以先看自己站在哪：
#   ① 命令行显式指定了路径                      -> 用它
#   ② 自己就在游戏目录里 / 上面几层是游戏目录   -> 自动认出来
#      （第 ② 条顺带覆盖"解压时多套了一层文件夹"这个最常见的坑）
#   ③ 都不是 -> 说清正确姿势，再兜底自动查找
$pkgName = Split-Path -Leaf $ROOT

if ($GameDir -ne '') {
    if (-not (Test-GameDir $GameDir)) {
        Fail ('指定的目录不像梦江湖游戏目录：' + "`n    " + $GameDir + "`n" +
              '（该目录下应同时有 DreamRivakes.exe 和 TableData\Martial.bytes）')
    }
}
else {
    $hit = Find-GameDirUp $ROOT 3

    if ($hit.Dir -ne '') {
        $GameDir = $hit.Dir

        if ($hit.Depth -eq 0) {
            # 包里的东西被全选铺进了游戏目录
            Say '（提示：包里这些文件被直接铺在了游戏目录里）'
            Say ('        也可以，但更推荐保留一层文件夹：<游戏主目录>\' + $pkgName + '\')
            Say ''
        }
        elseif ($hit.Depth -ge 2) {
            # ★ 最常见的坑：解压出来的文件夹又被解压 / 复制了一次
            Say ('（提示：检测到解压时多套了 ' + ($hit.Depth - 1) + ' 层文件夹）')
            Say ('        已自动向上找到游戏目录：' + $GameDir)
            Say ('        当前包目录：' + $ROOT)
            Say ('        建议整理成：' + $GameDir + '\' + $pkgName + '\install.ps1')
            Say '        也就是把里层那个同名文件夹提上来，删掉多余的空壳文件夹。'
            Say '        （本次仍可继续安装，功能不受影响）'
            Say ''
        }
        else {
            Say ('  已认出游戏目录（本包就放在它里面）：' + $GameDir)
            Say ''
        }
    }
    else {
        Say '没有把本包放在游戏主目录里 —— 安装器不知道到底该装到哪。'
        Say ''
        Say '正确姿势：把压缩包解压到【游戏主目录】里。游戏主目录就是那个'
        Say '          含有 DreamRivakes.exe 和 TableData 文件夹的 xiake 目录，'
        Say ('          解压后应该是：  <游戏主目录>\' + $pkgName + '\')
        Say ''
        $up = Split-Path -Parent $ROOT
        if ($up -and (Test-GameDir (Join-Path $up 'xiake'))) {
            Say '检测到：你把它解压到了游戏主目录的【外面一层】。'
            Say ('  现在在：' + $ROOT)
            Say ('  应该放：' + (Join-Path $up 'xiake'))
            Say ''
        }
        if ($NoSearch) {
            Say ''
            Say '（本次不自动查找游戏目录，到此为止）'
            Fail '未找到游戏目录。'
        }
        Say '正在尝试自动查找游戏目录 ...'
        $GameDir = Find-GameDir
        if ($GameDir -eq '') {
            Say ''
            Say '自动查找也失败了。请按上面的说明把包解压到游戏主目录里再运行，'
            Say '或者把游戏主目录（含 DreamRivakes.exe）拖到 1-安装.bat 上。'
            Fail '未找到游戏目录。'
        }
        Say ('  找到：' + $GameDir)
        Say '  （这次可以继续，但下次请把包放到游戏主目录里，免得装错地方）'
    }
}

Say ''
Say ('游戏目录：' + $GameDir)
Say ''

if ($Uninstall) {
    $bak = Invoke-Uninstall $GameDir
    Say ''
    Say '============================================================'
    Say '  卸载完成，游戏已回到安装前的状态。'
    Say ('  备份目录保留在：' + $bak)
    Say '  （确认没问题后可以手动删掉它）'
    Say '============================================================'
}
else {
    $bak = Invoke-Install $GameDir
    Sync-SwitchDocuments $GameDir $SCRIPT:REQUESTED_SW
    Save-LastInstallSwitches $GameDir $SCRIPT:REQUESTED_SW
    Say ''
    Say '============================================================'
    if($SCRIPT:INSTALL_SKIPS.Count -gt 0){Say '  安装完成（部分功能/组件已跳过）'}else{Say '  安装完成！'}
    Write-InstallResultSummary $GameDir
    Say ''
    Say '  本次实际生效的功能（跳过项已关闭，仅影响本次运行配置）：'
    $featLine = @()
    foreach ($nk in $FEAT_DEF.Keys) {
        $k = $FEAT_DEF[$nk]
        if ($SCRIPT:SW[$k]) { $featLine += ('        [开] ' + $nk) }
        else { $featLine += ('        [关] ' + $nk) }
    }
    foreach ($l in $featLine) { Say $l }
    Say '    想改开关：打开包里的「MOD功能开关.txt」-> 只改冒号后面的 0 / 1 -> 保存 ->'
    Say '              重新双击一次 1-安装.bat（关掉的功能会被自动卸载并还原）。'
    Say ''
    if ($SCRIPT:SRVSTATE -eq 'patched' -or $SCRIPT:SRVSTATE -eq 'already') {
        Say '  服务端闸门补丁：已放开（数量上限 / 心愿奖励重复领取）'
        Say '    ⚠ Steam「验证文件完整性」会把它还原 —— 之后重新装一次本 MOD 即可。'
    }
    elseif ($SCRIPT:SRVSTATE -eq 'unknown') {
        Say '  服务端闸门补丁：跳过（DLL 字节与预期不符，见上面 [7/8] 段）'
        Say '    —— 数量上限仍由游戏原生层判定，满额时学秘籍可能仍被拒。'
    }
    elseif ($SCRIPT:SRVSTATE -eq 'no-dll') {
        Say '  服务端闸门补丁：跳过（游戏目录里没找到服务端 DLL）'
    }
    if ($SCRIPT:SRVBALSTATE -eq 'patched' -or $SCRIPT:SRVBALSTATE -eq 'already') {
        Say '  经验值平衡：已放开（等级压制已解除 —— 打低级怪不再按等级差扣经验；CHET_ADDMARTIALEXP 已修复）'
    }
    elseif ($SCRIPT:SRVBALSTATE -eq 'unknown') {
        Say '  经验值平衡：跳过（DLL 字节与预期不符，见上面 [7/8] 段）'
    }
    elseif ($SCRIPT:SRVBALSTATE -eq 'no-dll') {
        Say '  经验值平衡：跳过（游戏目录里没找到服务端 DLL）'
    }
    if ($SCRIPT:SRVDYNSTATE -eq 'patched' -or $SCRIPT:SRVDYNSTATE -eq 'already') {
        Say '  角色动态品质：已放开（角色品质随等级抬升，只升不降）'
        if ($SCRIPT:SRVVSZSTATE -ne 'patched' -and $SCRIPT:SRVVSZSTATE -ne 'already') {
            Say '    ⚠ 但共享的 .text 映射区没能抬起 —— 启动前请重装一次，否则可能启动失败。'
        }
    }
    elseif ($SCRIPT:SRVDYNSTATE -eq 'unknown') {
        Say '  角色动态品质：跳过（DLL 字节与预期不符，见上面 [7/8] 段）'
    }
    elseif ($SCRIPT:SRVDYNSTATE -eq 'no-dll') {
        Say '  角色动态品质：跳过（游戏目录里没找到服务端 DLL）'
    }
    Say ''
    Say '  接下来请：'
    Say '    1. 如果游戏正开着，先完全退出（表数据只在启动时读取）'
    Say '    2. 重新启动游戏'
    Say '    3. 优化mod：进入任意副本，找任意 NPC 请教武学/天赋 ——'
    Say '       原本学不了的专属武学、专属天赋现在应该能请教、也能学会了'
    Say '    4. 优化mod：NPC 交互面板上多一个「指点」按钮，可以把自己会的'
    Say '       武学/天赋教给这个人；不在队伍里的人物也能请教 / 指点'
    Say '    5. 修复mod：新开一局用掉开局送的「冒险手札」，9 类冒险'
    Say '       天赋应该全部到 5 级（含原来漏掉的食材搜刮）'
    Say '       ※ 已经用掉手札的老存档不会补发，需新开档或找别的途径'
    Say ''
    Say '  想撤销：双击同目录下的 2-卸载.bat'
    Say '  ★ 这个解压出来的文件夹别急着删 —— 卸载脚本还要用它。'
    Say ('  原版表备份：' + $bak)
    Say '    （还原原版用的，确认没问题后可以自己删掉）'
    Say ''
    if (@($SCRIPT:SAVEBAK).Count -gt 0) {
        Say '  存档备份（★ 每次安装都自动做一份，别删）：'
        foreach ($p in @($SCRIPT:SAVEBAK)) { Say ('    ' + $p) }
        Say '    回档方法：把某个时间点文件夹里的内容拷回游戏目录，覆盖同名文件。'
        Say '    旧备份不会自动清理，历次安装的都留着，自己挑一份用。'
    }
    else {
        Say '  存档备份：本次没做成（见上面 [2/8] 段的原因）。'
        Say '    存档全没了的话，Steam 的云存档对这类单机版没什么用。'
    }
    Say '============================================================'
}
Say ''
