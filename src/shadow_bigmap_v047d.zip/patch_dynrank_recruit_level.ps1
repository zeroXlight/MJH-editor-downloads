function Update-DynamicRankRecruitLevel([byte[]]$Data,[bool]$Enabled,[string]$ResourceDir) {
    . (Join-Path $ResourceDir 'game_build.ps1')
    if((Get-ShadowGameBuild $Data).Family -eq 'classic') {
        . (Join-Path $ResourceDir 'patch_equal_layout.ps1')
        return ,(Update-ShadowEqualLayout $Data $Enabled (Get-ShadowNativeLayoutPath $Data $ResourceDir 'dynrank_recruit_level_layout.json'))
    }
    $offset=0x475377;$size=0x40
    if($Data.Length -lt ($offset+$size)){throw 'Unsupported recruitment level DLL'}
    $names=@('dynrank_recruit_level_original.hex','dynrank_recruit_level.hex')
    $expected=@('8C3090C5838BDE4B3E32F1149758093362F9730894BB860FB0FD57829A1BC567','A88CCEC14C87A74ED8E1550D20F03E1D4D2199F7C54382AFBD0EF5414058CCEE')
    $codes=@();$sha=[Security.Cryptography.SHA256]::Create()
    try {
        foreach($name in $names){
            $hex=[IO.File]::ReadAllText((Join-Path $ResourceDir $name)).Trim()
            if($hex -notmatch '^[0-9A-F]+$' -or $hex.Length -ne 2*$size){throw 'Invalid recruitment level resource'}
            [byte[]]$code=New-Object byte[] $size
            for($i=0;$i -lt $size;$i++){$code[$i]=[Convert]::ToByte($hex.Substring(2*$i,2),16)}
            $codes+=,$code
        }
        for($i=0;$i -lt 2;$i++){
            if([BitConverter]::ToString($sha.ComputeHash($codes[$i])).Replace('-','') -ne $expected[$i]){throw 'Recruitment level resource hash differs'}
        }
        $current=[BitConverter]::ToString($sha.ComputeHash($Data,$offset,$size)).Replace('-','')
        if($current -notin $expected){throw 'Unknown recruitment level transfer; refused dynamic rank patch'}
        [byte[]]$out=$Data.Clone();$index=0;if($Enabled){$index=1}
        $codes[$index].CopyTo($out,$offset)
        return ,$out
    }finally{$sha.Dispose()}
}
