using System;
using System.IO;

public static class ShadowNativeBytes {
 static int Digit(char c){if(c>='0'&&c<='9')return c-'0';if(c>='A'&&c<='F')return c-'A'+10;if(c>='a'&&c<='f')return c-'a'+10;throw new InvalidDataException("Invalid native hexadecimal byte");}
 public static byte[] Hex(string value){
  if(value==null||(value.Length&1)!=0)throw new InvalidDataException("Invalid native hexadecimal length");
  byte[] result=new byte[value.Length/2];
  for(int i=0;i<result.Length;i++)result[i]=(byte)((Digit(value[2*i])<<4)|Digit(value[2*i+1]));
  return result;
 }
}
