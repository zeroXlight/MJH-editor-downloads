﻿# Reuse the bounded protobuf reader; no fragment feature needs to be enabled.
. (Join-Path $PSScriptRoot 'patch_fragment.ps1')
function Set-ShopMapRow([byte[]]$Row,$Changes) {
    $out=New-Object 'System.Collections.Generic.List[byte]';$cursor=0;$seen=@{}
    foreach($f in (Read-FragmentFields $Row 0 $Row.Length)) {
        if($Changes.ContainsKey($f.F)) {
            if($f.W -ne 0 -or $seen.ContainsKey($f.F)) {throw 'Invalid Shop numeric field'}
            $out.Add([byte]($f.F*8));Add-FragmentExtraVar $out ([long]$Changes[$f.F]);$seen[$f.F]=$true
        } else {$out.AddRange([byte[]]$Row[$cursor..($f.End-1)])}
        $cursor=$f.End
    }
    if($seen.Count -ne $Changes.Count) {throw 'Missing Shop target field'}
    return ,$out.ToArray()
}
function Update-ShopMaps([byte[]]$Data,[bool]$Enabled) {
    $targets=@{53=@(5,27);88=@(12,26);124=@(17,25);182=@(24,28);218=@(30,21)}
    $rows=@{};$keys=@{};$top=Read-FragmentFields $Data 0 $Data.Length
    foreach($f in $top) {
        if($f.F -eq 1 -and $f.W -eq 0) {
            if($keys.ContainsKey($f.V)) {throw 'Duplicate Shop key'};$keys[$f.V]=$true
        } elseif($f.F -eq 2 -and $f.W -eq 2) {
            $r=@{}
            foreach($v in (Read-FragmentFields $Data $f.Start $f.End)) {
                if($v.W -eq 0) {if($r.ContainsKey($v.F)) {throw 'Duplicate Shop field'};$r[$v.F]=$v.V}
            }
            if(-not $r.ContainsKey(1) -or $rows.ContainsKey($r[1])) {throw 'Invalid Shop BaseID'}
            $rows[$r[1]]=@{Field=$f;Values=$r;Bytes=[byte[]]$Data[$f.Start..($f.End-1)]}
        }
    }
    if($keys.Count -ne $rows.Count) {throw ('Shop key/row count differs: keys='+$keys.Count+' rows='+$rows.Count)}
    foreach($id in $rows.Keys) {if(-not $keys.ContainsKey($id)) {throw 'Shop row has no key'}}
    $extra=@{};$replacement=@{}
    foreach($id in $targets.Keys) {
        if(-not $rows.ContainsKey([long]$id)) {throw ('Missing city treasure-map row: '+$id)}
        $r=$rows[[long]$id];$v=$r.Values
        if($v[2] -ne $targets[$id][0] -or $v[4] -ne 9403 -or $v[5] -notin @(1,10) -or $v[7] -ne 1 -or $v[10] -ne $targets[$id][1]) {throw ('Unsupported city treasure-map row: '+$id)}
        $extraId=[long](900000+$id)
        [byte[]]$advanced=Set-ShopMapRow $r.Bytes @{1=$extraId;4=9401;5=1}
        if($rows.ContainsKey($extraId) -and [BitConverter]::ToString($rows[$extraId].Bytes) -ne [BitConverter]::ToString($advanced)) {throw ('Advanced map Shop ID occupied or altered: '+$extraId)}
        $extra[$extraId]=$advanced
        $replacement[[long]$id]=Set-ShopMapRow $r.Bytes @{5=$(if($Enabled) {10} else {1})}
    }
    $out=New-Object 'System.Collections.Generic.List[byte]';$cursor=0
    foreach($f in $top) {
        $skip=$false
        if($f.F -eq 1 -and $f.W -eq 0 -and $extra.ContainsKey($f.V)) {$skip=-not $Enabled}
        if($f.F -eq 2 -and $f.W -eq 2) {
            $p=$f.Start;[void](Read-FragmentVar $Data ([ref]$p) $f.End);$id=Read-FragmentVar $Data ([ref]$p) $f.End
            if($extra.ContainsKey($id)) {$skip=-not $Enabled}
            elseif($replacement.ContainsKey($id)) {
                [byte[]]$row=$replacement[$id]
                $out.Add(18);Add-FragmentExtraVar $out $row.Length;$out.AddRange($row);$skip=$true
            }
        }
        if(-not $skip) {$out.AddRange([byte[]]$Data[$cursor..($f.End-1)])}
        $cursor=$f.End
    }
    if($Enabled) {foreach($id in ($extra.Keys | Sort-Object)) {
        if($rows.ContainsKey($id)) {continue}
        $out.Add(8);Add-FragmentExtraVar $out $id
        [byte[]]$row=$extra[$id];$out.Add(18);Add-FragmentExtraVar $out $row.Length;$out.AddRange($row)
    }}
    return ,$out.ToArray()
}

# A regular save does not load workshop JSON. Lua supplies client Shop rows on
# table access. Remove only our obsolete, unreleased JSON trial on any install.
function Remove-LegacyShopMapsClientConfig([string]$GameDir) {
    $path=Join-Path $GameDir 'ModProject\GameProject\Mod_MJH\Json\Shop_ShadowMaps.json'
    if(Test-Path -LiteralPath $path) {Remove-Item -LiteralPath $path -Force}
}
