﻿# Reforge type pools use the native Item.RecastAttrGenID path. No new DLL hook.
. (Join-Path $PSScriptRoot 'patch_recast_optimization.ps1')
function Get-RecastTypePool([int]$Type) {
    switch($Type) {
        3 {return 1900000611} # clothes
        4 {return 1900000612} # shoes
        5 {return 1900000613} # ornaments
        14 {return 1900000614} # artifacts
    }
    if($Type -in @(8,9,10,11,12,13,18,19,27,28,29,30)) {return 1900000615}
    return 0
}
function Test-RecastTypeAttribute([int]$Pool,[int]$Attr) {
    $attack=@(19,22,23,24,25,26,27,28,29,30,31,32,36,37,38,39,40,41,45,47,49,70,100,145)
    $defense=@(17,20,33,34,35,42,43,44,46,48,50,53,56,57,58,59,60,61,64,71,89,97,98,101,103,387)
    if($Attr -eq 65 -and $Pool -ne 1900000612) {return $false}
    if($Pool -in @(1900000613,1900000615) -and $Attr -in $defense) {return $false}
    if($Pool -in @(1900000611,1900000612) -and $Attr -in $attack) {return $false}
    if($Pool -in @(1900000612,1900000613,1900000614) -and $Attr -in @(19,20,145)) {return $false}
    return $true
}
function New-RecastTypePool([byte[]]$DefaultRow,[int]$Pool) {
    $out=New-Object 'System.Collections.Generic.List[byte]';$cursor=0
    foreach($f in (Read-FragmentFields $DefaultRow 0 $DefaultRow.Length)) {
        if($f.F -eq 1 -and $f.W -eq 0) {
            $out.Add(8);Add-FragmentExtraVar $out $Pool
        } elseif($f.F -eq 10 -and $f.W -eq 2) {
            $values=@{};foreach($v in (Read-FragmentFields $DefaultRow $f.Start $f.End)) {$values[$v.F]=$v.V}
            if(Test-RecastTypeAttribute $Pool ([int]$values[1])) {$out.AddRange([byte[]]$DefaultRow[$cursor..($f.End-1)])}
            else {
                $entry=New-Object 'System.Collections.Generic.List[byte]'
                $entry.Add(8);Add-FragmentExtraVar $entry $values[1]
                $out.Add(82);Add-FragmentExtraVar $out $entry.Count;$out.AddRange($entry.ToArray())
            }
        } else {$out.AddRange([byte[]]$DefaultRow[$cursor..($f.End-1)])}
        $cursor=$f.End
    }
    return ,$out.ToArray()
}
function Update-RecastTypePoolTable([byte[]]$Data,[bool]$Enabled,[hashtable]$Owned) {
    $top=Read-FragmentFields $Data 0 $Data.Length
    $default=$null;$existing=@{};$usable=@{};$removed=@{}
    foreach($f in $top) {
        if($f.F -ne 2 -or $f.W -ne 2) {continue}
        $id=@((Read-FragmentFields $Data $f.Start $f.End)|Where-Object {$_.F -eq 1 -and $_.W -eq 0})
        if($id.Count -ne 1) {throw 'Invalid reforge pool ID'}
        if($existing.ContainsKey([int]$id[0].V)) {throw 'Duplicate reforge pool ID'}
        $existing[[int]$id[0].V]=[byte[]]$Data[$f.Start..($f.End-1)]
        if($id[0].V -eq 1) {$default=$existing[1]}
    }
    if(-not $default) {throw 'Missing default reforge pool'}
    $wanted=@{}
    foreach($id in 1900000611..1900000615) {
        $key=[string]$id
        if($existing.ContainsKey($id)) {
            $hex=[BitConverter]::ToString($existing[$id]).Replace('-','')
            if(-not $Owned.ContainsKey($key) -or $Owned[$key] -ne $hex) {
                # A collision or later external edit is not ours to overwrite.
                continue
            }
            if(-not $Enabled) {$removed[$id]=$true;$Owned.Remove($key);continue}
        } elseif(-not $Enabled) {$Owned.Remove($key);continue}
        if($Enabled) {
            $wanted[$id]=New-RecastTypePool $default $id
            $Owned[$key]=[BitConverter]::ToString($wanted[$id]).Replace('-','')
            $usable[$id]=$true
        }
    }
    $out=New-Object 'System.Collections.Generic.List[byte]';$cursor=0
    foreach($f in $top) {
        $drop=$false
        if($f.F -eq 1 -and $f.W -eq 0 -and $removed.ContainsKey([int]$f.V)) {$drop=$true}
        if($f.F -eq 2 -and $f.W -eq 2) {
            $id=@((Read-FragmentFields $Data $f.Start $f.End)|Where-Object {$_.F -eq 1 -and $_.W -eq 0})[0].V
            if($removed.ContainsKey([int]$id)) {$drop=$true}
            elseif($wanted.ContainsKey([int]$id)) {
                [byte[]]$row=$wanted[[int]$id]
                $out.Add(18);Add-FragmentExtraVar $out $row.Length;$out.AddRange($row);$drop=$true
            }
        }
        if(-not $drop) {$out.AddRange([byte[]]$Data[$cursor..($f.End-1)])}
        $cursor=$f.End
    }
    foreach($id in ($wanted.Keys|Sort-Object)) {
        if($existing.ContainsKey($id)) {continue}
        $out.Add(8);Add-FragmentExtraVar $out $id
        [byte[]]$row=$wanted[$id];$out.Add(18);Add-FragmentExtraVar $out $row.Length;$out.AddRange($row)
    }
    return @{Data=$out.ToArray();Usable=$usable;Removed=$removed}
}
function Update-RecastTypeItems([byte[]]$Data,[bool]$Enabled,[hashtable]$Usable,[hashtable]$Removed) {
    if(-not ('ShadowRecastTypeItems' -as [type])) {Add-Type -Path (Join-Path $PSScriptRoot 'recast_types_table.cs')}
    return ,([ShadowRecastTypeItems]::Update($Data,$Enabled,[int[]]@($Usable.Keys),[int[]]@($Removed.Keys)))
}
function Invoke-RecastTypePools([string]$GameDir,[bool]$Enabled,[string]$BackupDir) {
    $statePath=Join-Path $BackupDir 'recast_type_pools_state.json';$owned=@{}
    if(Test-Path -LiteralPath $statePath) {
        $state=[IO.File]::ReadAllText($statePath,[Text.Encoding]::UTF8)|ConvertFrom-Json
        foreach($p in $state.PSObject.Properties) {$owned[$p.Name]=$p.Value}
    }
    if(-not $Enabled -and $owned.Count -eq 0) {return}
    $poolPath=Join-Path $GameDir 'TableData\ItemRecastAttrGen.bytes'
    [byte[]]$poolBytes=[IO.File]::ReadAllBytes($poolPath)
    $result=Update-RecastTypePoolTable $poolBytes $Enabled $owned
    $itemPath=Join-Path $GameDir 'TableData\Item.bytes'
    [byte[]]$itemBytes=[IO.File]::ReadAllBytes($itemPath)
    [byte[]]$newItem=Update-RecastTypeItems $itemBytes $Enabled $result.Usable $result.Removed
    if($Enabled) {
        $backup=Join-Path $BackupDir 'Item_recast_types.bytes.orig'
        if(-not (Test-Path -LiteralPath $backup)) {[IO.File]::WriteAllBytes($backup,$itemBytes)}
    }
    # Official JSON overrides bytes, including our random variants and editor items.
    # Change only the default/owned pool reference, preserving every other field.
    $jsonDir=Join-Path $GameDir 'ModProject\GameProject\Mod_MJH\Json'
    $jsonWrites=@{}
    if(Test-Path -LiteralPath $jsonDir) {
        foreach($file in (Get-ChildItem -LiteralPath $jsonDir -Filter 'Item_*.json' -File)) {
            $text=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
            $updated=[ShadowRecastTypeItems]::UpdateJson($text,$Enabled,[int[]]@($result.Usable.Keys),[int[]]@($result.Removed.Keys))
            $changed=$updated -cne $text
            if($changed) {
                $backupFolder=Join-Path $BackupDir 'recast_type_json';[void][IO.Directory]::CreateDirectory($backupFolder)
                $backup=Join-Path $backupFolder $file.Name
                if(-not (Test-Path -LiteralPath $backup)) {[IO.File]::WriteAllText($backup,$text,[Text.UTF8Encoding]::new($false))}
                $jsonWrites[$file.FullName]=$updated
            }
        }
    }
    [IO.File]::WriteAllBytes($poolPath,$result.Data)
    [IO.File]::WriteAllBytes($itemPath,$newItem)
    foreach($path in $jsonWrites.Keys) {[IO.File]::WriteAllText($path,$jsonWrites[$path],[Text.UTF8Encoding]::new($false))}
    [IO.File]::WriteAllText($statePath,($owned|ConvertTo-Json -Depth 3),[Text.UTF8Encoding]::new($false))
}
