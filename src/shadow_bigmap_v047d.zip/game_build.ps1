﻿# Build-family identification only. Each native patch still verifies its own code.
function Get-ShadowGameBuild([byte[]]$Data) {
    if ($Data.Length -lt 0x400) {throw 'Unsupported game DLL: truncated PE'}
    $pe=[BitConverter]::ToInt32($Data,0x3c)
    if ($pe -lt 0 -or $pe+24 -ge $Data.Length -or
        [BitConverter]::ToUInt32($Data,$pe) -ne 0x4550 -or
        [BitConverter]::ToUInt16($Data,$pe+4) -ne 0x8664) {throw 'Unsupported game DLL: invalid x64 PE'}
    $count=[BitConverter]::ToUInt16($Data,$pe+6)
    $table=$pe+24+[BitConverter]::ToUInt16($Data,$pe+20)
    if ($count -lt 7 -or $count -gt 32 -or $table+$count*40 -gt $Data.Length) {throw 'Unsupported game DLL: section table'}
    $rdata=$null
    for($i=0;$i -lt $count;$i++) {
        $p=$table+$i*40
        $name=[Text.Encoding]::ASCII.GetString($Data,$p,8).TrimEnd([char]0)
        if($name -eq '.rdata') {$rdata=@([BitConverter]::ToUInt32($Data,$p+12),[BitConverter]::ToUInt32($Data,$p+20))}
    }
    if($null -eq $rdata) {throw 'Unsupported game DLL: missing rdata'}
    if($rdata[0] -eq 0xf69000 -and $rdata[1] -eq 0xf67800) {
        return @{ID='25623503';Family='legacy';BackupName='_MOD备份_暗影MOD合集';LegacyFallback=$true}
    }
    if($rdata[0] -eq 0xf72000 -and $rdata[1] -eq 0xf70a00) {
        if([BitConverter]::ToUInt32($Data,$pe+8) -ne 0x6ae3edf7 -or
           [BitConverter]::ToUInt32($Data,$pe+24+4) -ne 0xf70600) {
            throw 'Unknown classic DLL build; do not reuse build_26315803 backups'
        }
        return @{ID='26315803';Family='classic';BackupName='_MOD备份_暗影MOD合集\build_26315803';LegacyFallback=$false}
    }
    throw 'Unsupported game DLL build; no files changed'
}

function Get-ShadowBuildContext([string]$GameDir,[string[]]$SupportedFamilies=@('legacy')) {
    $path=Join-Path $GameDir 'DreamRivakes_Data\Plugins\RaceLogic_Release_x64.dll'
    $profile=Get-ShadowGameBuild ([IO.File]::ReadAllBytes($path))
    if($SupportedFamilies -notcontains $profile.Family) {
        throw ('游戏构建 '+$profile.ID+' 尚未完成原生补丁适配，安装/卸载已在写入前停止。不要用旧包或旧原版备份覆盖新版游戏。')
    }
    return $profile
}

function Get-ShadowNativeLayoutPath([byte[]]$Data,[string]$ResourceDir,[string]$FileName) {
    $profile=Get-ShadowGameBuild $Data
    if($profile.Family -eq 'classic') {$ResourceDir=Join-Path $ResourceDir 'profiles\classic_26315803'}
    $path=Join-Path $ResourceDir $FileName
    if(-not (Test-Path -LiteralPath $path -PathType Leaf)) {throw ('Native resource not ported for build '+$profile.ID+': '+$FileName)}
    return $path
}
